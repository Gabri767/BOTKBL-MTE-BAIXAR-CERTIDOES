import pandas as pd
from botcity.web import WebBot, By
from botcity.core import DesktopBot, Backend
from botcity.web.util import element_as_select
from webdriver_manager.chrome import ChromeDriverManager
from config import *
import re

bot = WebBot()


# Classe padrão para o início do bot
class manipulate_browsers:

    @staticmethod
    def open_browser():
        try:
            bot.driver_path = (
                ChromeDriverManager()
                .install()
                .replace(f"/THIRD_PARTY_NOTICES.chromedriver", r"\chromedriver.exe")
            )
            # Configure se vai rodar em modo headless
            bot.headless = False
            bot.start_browser()
            status_process = "Navegador aberto com sucesso."
            bot.maximize_window()
            return status_process
        except Exception as e:
            status_process = f"Erro ao abrir o navegador: {str(e)}"

    @staticmethod
    def fazer_login_clicavel(name):
        credenciais_encriptadas = Orchestrator.get_asset_by_name(name)
        # Instancia o Desencriptador
        desencriptador = Desencriptador()

        try:
            # Obtem as credenciais desencriptadas, passando o dicionário correto
            credenciais = desencriptador.obter_credenciais(credenciais_encriptadas)
            # Usa as credenciais desencriptadas para login
            user_login = credenciais["username"]
            pswd_login = credenciais["password"]

        except Exception as e:
            status_portal = f"Erro ao desencriptar credenciais: {e}"
            log_status(
                bot_name=Constantes.NOME_AUTOMACAO,
                status_exec="in_progress",
                status_message=status_portal,
                local=local,
                level=logging.ERROR,
                access_token=Orchestrator.access_token,
            )

        max_attempts = 3
        attempts = 0
        status_portal = "Fução Login iniciado."
        local = "Fazer login do tipo clicável."

        while attempts < max_attempts:
            try:
                status_portal = ""
                seletores_js = ["#txtLogin", "#password_input", "#btnAcessar)"]
                querys_execute = [
                    Constantes.QUERY_JS_TYPE,
                    Constantes.QUERY_JS_TYPE,
                    Constantes.QUERY_JS_CLICK,
                ]
                replaces_valor = [user_login, pswd_login, ""]
                # cpf = bot.find_element('txtLogin', By.ID)
                # cpf.send_keys(Constantes.EMAIL_LOGIN)
                bot.execute_javascript(
                    f'document.querySelector("#txtLogin").value="{user_login}"'
                )
                ###Logins que envolvem campos de senha clicaveis
                page_source = bot.page_source()
                buttons = page_source.find_all("input", attrs={"type": "submit"})

                # Extract values and store in a list
                values = []
                button_ids = []
                for button in buttons:
                    value = button.get("value")
                    btn_id = button.get("name")
                    if value:
                        values.append(value)
                        button_ids.append(btn_id)

                for i in pswd_login:
                    for a, value in enumerate(values):
                        if i in value:
                            # print(f'O digito {i} esta no valor {a} que corresponde ao botão {button_ids[a]}')
                            seletor_js = f"#{button_ids[a]}"
                            query_execute = querys_execute[2]
                            query_execute = query_execute.replace(
                                "seletor_js_path", seletor_js
                            )
                            # print(query_execute)
                            bot.execute_javascript(query_execute)

                timeout = 0
                bot.execute_javascript('document.querySelector("#btnAcessar").click()')
                while timeout < 20000:
                    bot.wait(timeout)
                    tipo_log = "info"
                    elemento = bot.find_element(
                        '//*[@id="page-content-wrapper"]/div/div/div/div', By.XPATH
                    ).text
                    if not elemento:

                        if timeout >= 20000:
                            status_portal = "Tempo limite de 20s alcançado."
                            raise TimeoutError(status_portal)
                        timeout += 1000

                    status_portal = "Login realizado com sucesso."
                    break
                return status_portal

            except Exception as e:
                status_portal = f"{e}"

                attempts += 1
                status_portal = f"Tentativa {attempts}: {e}"
                if attempts == max_attempts:
                    status_portal = f"Falha ao preencher formulário. Número máximo de {max_attempts} tentativas excedido."
                    raise Exception(status_portal)

    @staticmethod
    def function_alterar_config_browser():
        partes = (bot.browser).split(".")
        navegador = partes[0]

        try:
            url_config = Constantes.URL_CONFIG
            # url_portal = Constantes.URL_PORTAL.replace('http','https')
            url_portal = Constantes.URL_SEGURA
            bot.browse(url_config)
            bot.maximize_window()
            bot.execute_javascript(Constantes.QUERY_JS_CONFIG1)
            bot.tab()
            bot.paste(url_portal, 300)
            bot.key_enter()

            url_config2 = Constantes.URL_CONFIG2

            if url_config2 is not None:
                url_config3 = Constantes.URL_CONFIG3
                bot.navigate_to(url_config2)
                bot.execute_javascript(Constantes.QUERY_JS_CONFIG2)
                bot.tab()
                bot.paste(url_portal)
                bot.key_enter()
                bot.navigate_to(url_config3)
                bot.execute_javascript(Constantes.QUERY_JS_CONFIG3)
                bot.back()
            status_funcao = "Alteração realizada com sucesso."

        except Exception as e:
            status_funcao = f"{e}"

        finally:
            return status_funcao


class mte_baixar_certidoes:
    @staticmethod
    def acessar_portal(url_portal):
        max_attempts = 3
        attempts = 0
        status_portal = ""

        url_portal = Orchestrator.get_asset_by_name(url_portal)["value_text"]
        while attempts < max_attempts:
            try:

                bot.browse(url_portal)
                elemento = bot.find_element(Constantes.CONSULTA_VALIDA1, By.ID)
                tipo_log = "info"
                if "Consultar Instrumentos" in elemento.text:
                    status_portal = "Portal aberto com sucesso."
                    break  # Exit loop if successful

                else:
                    raise Exception("Portal não está aberto")

            except Exception as e:
                attempts += 1
                status_portal = f"Tentativa {attempts}: {e}"
                tipo_log = "warning"
                if attempts == max_attempts:
                    ###inserir mensagem do heitor aqui
                    status_portal = "Falha ao abrir o portal após 3 tentativas. Tente novamente mais tarde."
                    tipo_log = "error"

            finally:
                print(status_portal)
                # gravar_satus(mensagem= status_portal, nivel= tipo_log)
        return status_portal

    def preencher_form_instr_colet(bot, By):
        print("Função Preencher Formulário Invocada")
        max_attempts = 3
        attempts = 0
        status_portal = ""
        nome_planilha = "Planilha.xlsx"  # já deixar preparado para possivel laço de repetição para obtenção de várias planilhas

        while attempts < max_attempts:
            try:
                opened_tabs = bot.get_tabs()
                pagina_atual = opened_tabs[0]
                elemento = bot.find_element(
                    "chkNRCNPJ", By.ID, visible=True, clickable=True
                )

                if not elemento:
                    status_portal = f"Erro: Elemento não idetificado: {elemento} "
                    raise AttributeError(status_portal)

                status_portal = "Marcando CNPJ."
                bot.execute_javascript('document.querySelector("#chkNRCNPJ").click()')
                dados = FileHandler.obter_dados_planilha(nome_planilha)
                num_itens = 0

                for i in range(len(dados["CNPJ Empregados"])):
                    cnpj = dados["CNPJ Empregados"][i]
                    sindicato_empreg = dados["Nome Empregados"][i]
                    sindicato_patron = dados["Nome Patronal"][i]
                    # num_solicitacao = dados['Numero da Solicitacao'][i]

                    elemento = bot.find_element(
                        "txtNRCNPJ", By.ID, visible=True, clickable=True
                    )
                    if not elemento:
                        status_portal = f"Erro: Elemento não idetificado: {elemento} "
                        raise AttributeError(status_portal)

                    if len(cnpj) < 14:
                        cnpj = cnpj.zfill | (14)

                    cnpj = (
                        f"{cnpj[:2]}.{cnpj[2:5]}.{cnpj[5:8]}/{cnpj[8:12]}-{cnpj[12:]}"
                    )

                    status_portal = f"Informando CNPJ: {cnpj}"
                    bot.execute_javascript(
                        f'document.getElementById("#txtNRCNPJ").value = "{cnpj}"'
                    )

                    print(status_portal)
                    # bot.paste(cnpj)
                    # gravar_satus(mensagem=status_portal)
                    elemento = bot.find_element(selector="cboTPRequerimento", by=By.ID)
                    if not elemento:
                        status_portal = f"Erro: Elemento não idetificado: {elemento} "
                        raise AttributeError(status_portal)

                    status_portal = "Selecionando 'Tipo de Convenção Coletiva'"
                    bot.execute_javascript(
                        f'document.getElementById("cboTPRequerimento").value = "{Constantes.TIPO_INSTR_COLET}"'
                    )
                    print(status_portal)
                    # gravar_satus(mensagem=status_portal)

                    # Selecionar - Vigência:
                    elemento = bot.find_element(selector="cboSTVigencia", by=By.ID)
                    if not elemento:
                        status_portal = f"Erro: Elemento não idetificado: {elemento} "
                        raise AttributeError(status_portal)

                    status_portal = "Selecionando 'Tipo Vigência'"
                    print(status_portal)
                    # gravar_satus(mensagem=status_portal)

                    bot.execute_javascript(
                        f'document.getElementById("cboSTVigencia").value = "{Constantes.TIPO_VIGENCIA}"'
                    )
                    status_portal = "Dados preenchidos com sucesso."
                    print(status_portal)
                    # gravar_satus(status_portal)
                    bot.wait(500)
                    bot.execute_javascript(
                        'document.querySelector("#btnPesquisar").click()'
                    )

                    elemento = bot.find_element(
                        "/html/body/div[5]/div[2]/table/tbody/tr/td[2]", By.XPATH
                    )
                    if elemento:
                        status_portal = f"Alerta: {elemento.text}"
                        # gravar_satus(mensagem=status_portal, nivel='warning')
                        print(status_portal)
                        bot.execute_javascript(
                            'document.querySelector("body > div:nth-child(5) > div.ui-dialog-buttonpane.ui-widget-content.ui-helper-clearfix > div > button").click()'
                        )
                        bot.execute_javascript(
                            'document.querySelector("#btnPesquisar").click()'
                        )

                    # Usar re.search para encontrar a primeira correspondência
                    html = str(bot.page_source())
                    divs = bot.find_elements(selector="grdInstrumentos", by=By.ID)

                    arr_divs = divs[0].text.split("Nº do Registro")
                    for str in arr_divs:
                        if (
                            sindicato_empreg.lower() in str.lower()
                            and sindicato_patron.lower() in str.lower()
                        ):
                            print(str)
                            vigencia = (
                                str.split("Vigência")[1]
                                .split("Partes")[0]
                                .replace("\n", "")
                                .strip()
                            )
                            num_solicitacao = (
                                str.split("Solicitação")[1]
                                .split("Tipo")[0]
                                .replace("\n", "")
                                .strip()
                            )
                            num_registro = (
                                str.split(" Nº da")[0].replace("\n", "").strip()
                            )
                            print(
                                f"Nº do Registro: {num_registro} - Vigência: {vigencia} - Nº Solicitação: {num_solicitacao}"
                            )

                    ###verificar se podem ocorrer mais de um caso para o mesmo cnpj***** se sim alterar a parte abaixo para atender essa necessidade, senão deixa com está.
                    print()

                    pattern = re.compile(rf"'{num_solicitacao}','(\d+)'")
                    match = pattern.search(html)
                    if match:
                        valor_dinamico = match.group(1)
                        status_portal = f"Valor dinâmico encontrado: {valor_dinamico}"

                    else:
                        status_portal = f"Alerta: Valor dinâmico não encontrado após o código {num_solicitacao}."
                        raise ValueError(status_portal)

                    # gravar_satus(mensagem= status_portal)
                    print(status_portal)

                    try:
                        query_js = f"document.querySelector(\"#btnDownload > a\").onclick(\"fDownload('{num_solicitacao}','{valor_dinamico}')\")"
                        status_portal = (
                            f"Baixando arquivo da solicitação: {num_solicitacao}."
                        )
                        print(status_portal)
                        # gravar_satus(mensagem= status_portal)
                        extensao_arq = ".doc"
                        status_portal, caminho_arquivo = (
                            FileHandler.fazer_download_docs(bot, extensao_arq, query_js)
                        )
                        caminho_destino = Path(
                            f"{Constantes.PATH_ARQUIVO_SAIDA}\{sindicato_empreg}"
                        )
                        # gravar_satus(status_portal)
                        print(status_portal)
                        FileHandler.verificar_criar_pasta(caminho_destino)
                        nome_arquivo = (
                            f'{num_solicitacao.replace("/","-")}{extensao_arq}'
                        )
                        status_portal = FileHandler.mover_e_renomear_arquivo(
                            caminho_arquivo, caminho_destino, novo_nome=nome_arquivo
                        )

                    except Exception as e:
                        status_portal = f"{e}"

                    finally:
                        print(status_portal)
                        # gravar_satus(status_portal)
                        opened_tabs = bot.get_tabs()
                        for tab in opened_tabs:
                            print(tab)
                            if tab != pagina_atual:
                                bot.activate_tab(tab)
                                bot.close_page()
                                print(f"Fechando pagina: {tab}")
                    print(status_portal)
                    # gravar_satus(mensagem=status_portal)
                    bot.activate_tab(pagina_atual)

                    elemento = bot.find_element('//*[@id="divBotoes"]', By.XPATH)
                    if not elemento:
                        status_portal = f"Erro: Elemento não idetificado: {elemento} "
                        raise AttributeError(status_portal)
                    bot.execute_javascript(
                        'document.querySelector("#btnFechar").click()'
                    )
                    num_itens += 1

                status_portal = f"Total de {num_itens} de {len(dados['CNPJ Empregados'])} itens percorridos."
                break

            except Exception as e:
                attempts += 1
                status_portal = f"Tentativa {attempts}: {e}"

                if attempts == max_attempts:
                    status_portal = f"Falha ao preencher formulário. Número máximo de {max_attempts} tentativas excedido."
                    raise Exception(status_portal)

            finally:
                if "falha" in status_portal.lower() or "erro" in status_portal.lower():
                    tipo_log = "error"
                elif "alerta" in status_portal.lower():
                    tipo_log = "warning"
                else:
                    tipo_log = "info"
                print(status_portal)
                # gravar_satus(mensagem = status_portal, nivel = tipo_log)

                elemento = bot.find_element('//*[@id="btnLimpar"]', By.XPATH)
                if not elemento:
                    status_portal = f"Erro: Elemento não idetificado: {elemento}. "
                    raise AttributeError(status_portal)

                bot.execute_javascript('document.querySelector("#btnLimpar").click()')
                if num_itens != len(dados["CNPJ Empregados"]):
                    status_portal = f"Execução de baixa concluída, porém nem todos os {len(dados['CNPJ Empregados'])}. Total de itens processados: {num_itens}!"
                status_portal = f"Exceução de baixa de dados concluída com sucesso. Todos os dados procurados foram encontrados!"

        return status_portal
