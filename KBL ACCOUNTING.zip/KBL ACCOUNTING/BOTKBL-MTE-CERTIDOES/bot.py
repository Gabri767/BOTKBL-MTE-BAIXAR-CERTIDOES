""""
PROJETO BAIXAR CERTIDÕES DO MTE (MINISTÉRIO DO TRABALHO)

ESSE PROJETO TEM POR DEFINIÇÃO:
1- ACESSAR UM ARQUIVO EXCEL QUE ESTARÁ UM DIRETÓRIO NA REDE DA KBL
SE EXISTIR ARQUIVO:
    2- OBTER OS DADOS DENTRO DE UMA SHEET DO EXCEL QUE CONTEM OS CNPJS VINCULADOS
        A: CNPJ
        B: CNPJ
        C: NOME

    3- DEPOIS ACESSAR O PORTAL http://www3.mte.gov.br/sistemas/mediador/ConsultarInstColetivo
    4- PARA CADA CONJUNTO DE DADOS OBTIDOS FAZER UM LAÇO DE REPETIÇÃO E PERCORRER OS DADOS DA SEGUINTE FORMA:
    5- CRIAR UMA NOVA SHEET PARA GRAVAR OS DADOS PROCESSADOS
    LAÇO FOR:
        5.1- SELECIONAR O TIPO DE PARTICPANTE 'CNPJ'
        5.2- INFORMAR O NÚMERO DO CNPJ
        5.3- SELECIONAR O TIPO DE CONVENÇÃO COLETIVA (TIPO DE INSTRUMENTO COLETIVO)
        5.4- ESCOLHER O TIPO DA VIGÊNCIA
        5.5- CLICAR EM PESQUISAR
        5.6- VERIFICAR SE O AS PARTES DO INSTRUMENTO SÃO AS MESMAS 
        5.7- SE AS PARTES FOREM IGUAIS, FAZER O DOWNLOAD DE UM ARQUIVO EM FORMATO WORD
        5.8- APÓS A CONCLUSÃO DO DOWNLOAD DO ARQUIVO MOVER ESTE ARQUIVO PARA UMA OUTRA PASTA DA REDE

    6- GRAVAR OS DADOS NA SHEET COM OS REGISTROS OBTIDOS
        A: CNPJ SINDICATO
        B: NOME DO SINDICATO
        C: CAMINHO DO ARQUIVO NA REDE
SENAO ENCERRAR A AUTOMAÇÃO

7. ENCERRAR AUTOMAÇAO

"""

from botcity.maestro import *
from config import *
from uteis.browsers_bot import manipulate_browsers, mte_baixar_certidoes


def main():
    # Configura os handlers de sinal para lidar com SIGTERM e SIGINT
    Signals.setup_signal_handlers()
    start_time = Constantes.HORA_INICIO
    start_time_str = start_time.strftime("%d/%b/%Y %H:%M:%S.%f")[:-3]
    bot_name = Constantes.NOME_AUTOMACAO
    status_exec = "in_progress"
    status_message = f"Iniciando automação {bot_name} em {start_time_str}."
    local = "Início"
    level_log = logging.INFO

    path_entrada = Constantes.PATH_ARQUIVO_ENTR
    path_saida = Constantes.PATH_ARQUIVO_SAIDA

    try:
        log_status(
            bot_name,
            status_exec,
            status_message,
            local,
            level=level_log,
            access_token=Orchestrator.access_token,
        )
        ### Bloco iniciando as dependências do bot
        try:

            status_message = manipulate_browsers.open_browser()
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )

            url_portal = Orchestrator.get_asset_by_name(Constantes.URL_PORTAL)[
                "value_text"
            ]

            status_message = manipulate_browsers.function_alterar_config_browser()

            status_message = mte_baixar_certidoes.acessar_portal(url_portal)

        except Exception as e:
            status_message = f"Erro ao processar: "
            raise Exception(status_message)

        ### Bloco de processamento do robô
        try:
            local = "Bloco de processamento das informações do robô"
            status_message = "Iniciando processamento de Atividades no MTE"
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )

            if "sucesso" in status_message:
                level_log = logging.INFO
            else:
                level_log = logging.WARNING

            status_exec = "success"
        except Exception as e:
            status_message = f"Erro durante o processamento: {str(e)}"
            level_log = logging.ERROR
            status_exec = "failure"

    except Exception as e:
        status_message = f"Erro ao obter token JWT: {str(e)}"
        level_log = logging.ERROR
        status_exec = "failure"

    finally:
        log_status(
            bot_name,
            status_exec,
            status_message,
            local,
            level=level_log,
            access_token=Orchestrator.access_token,
        )

        # Bloco de finalização do robô
        try:
            if "bot" in locals():
                status_message = "Finalizando processamento dos dados."
                bot.wait(3000)
                status_message = manipulate_browsers.close_browser()
                status_message = f"Status do processamento: {status_message}"

            status_message += f" | Finalizando automação {bot_name}."
            level_log = logging.INFO
            status_exec = "success"

        except Exception as e:
            status_message += (
                f" | Erro ao finalizar o bot {bot_name}, erro identificado: {str(e)}."
            )
            level_log = logging.ERROR
            status_exec = "failure"

        finally:
            tempo_final = Utils.tempo_decorrido(start_time)
            status_message += f" | Tempo total de execução: {tempo_final[1]} ({tempo_final[0]:.2f} segundos)."
            local = ""
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )

    return status_message


if __name__ == "__main__":
    try:
        status_bot = main()

    except Exception as e:
        from datetime import datetime

        now = datetime.now().strftime("%d/%b/%Y %H:%M:%S")
        log_status(
            bot_name=Constantes.NOME_AUTOMACAO,
            status_exec="failure",
            status_message=f"Erro na execução do bot: {str(e)} em {now}",
            local="final",
            level=logging.ERROR,
            access_token=Orchestrator.access_token,
        )
