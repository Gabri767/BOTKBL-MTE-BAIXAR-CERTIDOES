#!/bin/bash

zip -r "BotMTE_Certidoes.zip" * -x "BotMTE_Certidoes.zip"