import requests
from bs4 import BeautifulSoup

# URL da página que contém o HTML
url = 'http://www3.mte.gov.br/sistemas/mediador/ConsultarInstColetivo'

# Fazer a requisição para obter o conteúdo HTML da página
response = requests.get(url)
html_content = response.text

# Verificar se a string 'MR036167/2023' está no conteúdo HTML
if 'MR036167/2023' in html_content:
    print("'MR036167/2023' encontrado na página.")

    # Analisar o HTML com BeautifulSoup
    soup = BeautifulSoup(html_content, 'html.parser')

    # Encontrar o elemento com o ID 'bntDownload'
    btn_download = soup.find(id='bntDownload')

    # Obter o atributo 'onclick' desse elemento
    if btn_download and 'onclick' in btn_download.attrs:
        onclick_value = btn_download['onclick']
        print(f"Valor do atributo onclick: {onclick_value}")
    else:
        print("Elemento com ID 'bntDownload' não encontrado ou não contém atributo 'onclick'.")
else:
    print("'MR036167/2023' não encontrado na página.")
