import pandas as pd
from botcity.web import WebBot, By
from botcity.core import DesktopBot, Backend
from botcity.web.util import element_as_select
from webdriver_manager.chrome import ChromeDriverManager
from config import *
import re
import os

bot = WebBot()


# Classe padrão para o início do bot
class manipulate_browsers:

    @staticmethod
    def close_browser():
        bot.stop_browser()

    @staticmethod
    def open_browser():
        try:
            bot.driver_path = (
                ChromeDriverManager()
                .install()
                .replace(f"/THIRD_PARTY_NOTICES.chromedriver", rf"\chromedriver.exe")
            )
            # Configure se vai rodar em modo headless
            bot.headless = False
            bot.start_browser()
            status_process = "Navegador aberto com sucesso."
            bot.maximize_window()

            return status_process, bot
        except Exception as e:
            status_process = f"Erro ao abrir o navegador: {str(e)}"

    @staticmethod
    def fazer_login_clicavel(name):
        credenciais_encriptadas = Orchestrator.get_asset_by_name(name)
        # Instancia o Desencriptador
        desencriptador = Desencriptador()

        try:
            # Obtem as credenciais desencriptadas, passando o dicionário correto
            credenciais = desencriptador.obter_credenciais(credenciais_encriptadas)
            # Usa as credenciais desencriptadas para login
            user_login = credenciais["username"]
            pswd_login = credenciais["password"]

        except Exception as e:
            status_portal = f"Erro ao desencriptar credenciais: {e}"
            log_status(
                bot_name=Constantes.NOME_AUTOMACAO,
                status_exec="in_progress",
                status_message=status_portal,
                local=local,
                level=logging.ERROR,
                access_token=Orchestrator.access_token,
            )

        max_attempts = 3
        attempts = 0
        status_portal = "Fução Login iniciado."
        local = "Fazer login do tipo clicável."

        while attempts < max_attempts:
            try:
                status_portal = ""
                seletores_js = ["#txtLogin", "#password_input", "#btnAcessar)"]
                querys_execute = [
                    Constantes.QUERY_JS_TYPE,
                    Constantes.QUERY_JS_TYPE,
                    Constantes.QUERY_JS_CLICK,
                ]
                replaces_valor = [user_login, pswd_login, ""]
                # cpf = bot.find_element('txtLogin', By.ID)
                # cpf.send_keys(Constantes.EMAIL_LOGIN)
                bot.execute_javascript(
                    f'document.querySelector("#txtLogin").value="{user_login}"'
                )
                ###Logins que envolvem campos de senha clicaveis
                page_source = bot.page_source()
                buttons = page_source.find_all("input", attrs={"type": "submit"})

                # Extract values and store in a list
                values = []
                button_ids = []
                for button in buttons:
                    value = button.get("value")
                    btn_id = button.get("name")
                    if value:
                        values.append(value)
                        button_ids.append(btn_id)

                for i in pswd_login:
                    for a, value in enumerate(values):
                        if i in value:
                            # print(f'O digito {i} esta no valor {a} que corresponde ao botão {button_ids[a]}')
                            seletor_js = f"#{button_ids[a]}"
                            query_execute = querys_execute[2]
                            query_execute = query_execute.replace(
                                "seletor_js_path", seletor_js
                            )
                            # print(query_execute)
                            bot.execute_javascript(query_execute)

                timeout = 0
                bot.execute_javascript('document.querySelector("#btnAcessar").click()')
                while timeout < 20000:
                    bot.wait(timeout)
                    tipo_log = "info"
                    elemento = bot.find_element(
                        '//*[@id="page-content-wrapper"]/div/div/div/div', By.XPATH
                    ).text
                    if not elemento:

                        if timeout >= 20000:
                            status_portal = "Tempo limite de 20s alcançado."
                            raise TimeoutError(status_portal)
                        timeout += 1000

                    status_portal = "Login realizado com sucesso."
                    break
                return status_portal

            except Exception as e:
                status_portal = f"{e}"

                attempts += 1
                status_portal = f"Tentativa {attempts}: {e}"
                if attempts == max_attempts:
                    status_portal = f"Falha ao preencher formulário. Número máximo de {max_attempts} tentativas excedido."
                    raise Exception(status_portal)

    @staticmethod
    def function_alterar_config_browser():
        partes = (bot.browser).split(".")
        navegador = partes[0]

        try:
            url_config = Constantes.URL_CONFIG
            # url_portal = Constantes.URL_PORTAL.replace('http','https')
            url_portal = Constantes.URL_SEGURA
            bot.browse(url_config)
            bot.maximize_window()
            bot.execute_javascript(Constantes.QUERY_JS_CONFIG1)
            bot.tab()
            bot.paste(url_portal, 300)
            bot.key_enter()

            url_config2 = Constantes.URL_CONFIG2

            if url_config2 is not None:
                url_config3 = Constantes.URL_CONFIG3
                bot.navigate_to(url_config2)
                bot.execute_javascript(Constantes.QUERY_JS_CONFIG2)
                bot.tab()
                bot.paste(url_portal)
                bot.key_enter()
                bot.navigate_to(url_config3)
                bot.execute_javascript(Constantes.QUERY_JS_CONFIG3)
                bot.back()
            status_funcao = "Alteração realizada com sucesso."

        except Exception as e:
            status_funcao = f"{e}"

        finally:
            return status_funcao


class mte_baixar_certidoes:
    @staticmethod
    def acessar_portal(url_portal):
        max_attempts = 3
        attempts = 0
        status_portal = ""

        while attempts < max_attempts:
            try:

                bot.browse(url_portal)
                elemento = bot.find_element(Constantes.CONSULTA_VALIDA1, By.ID)
                tipo_log = "info"
                if "Consultar Instrumentos" in elemento.text:
                    status_portal = "Portal aberto com sucesso."
                    break  # Exit loop if successful

                else:
                    raise Exception("Portal não está aberto")

            except Exception as e:
                attempts += 1
                status_portal = f"Tentativa {attempts}: {e}"
                tipo_log = "warning"
                if attempts == max_attempts:
                    ###inserir mensagem do heitor aqui
                    status_portal = "Falha ao abrir o portal após 3 tentativas. Tente novamente mais tarde."
                    tipo_log = "error"

            finally:
                print(status_portal)
                # gravar_satus(mensagem= status_portal, nivel= tipo_log)
        return status_portal

    @staticmethod
    def preencher_form_instr_colet(caminho, diretorio, destino):
        print("Função Preencher Formulário Invocada")
        max_attempts = 3
        attempts = 0
        status_portal = ""

        while attempts < max_attempts:
            try:
                opened_tabs = bot.get_tabs()
                pagina_atual = opened_tabs[0]
                elemento = bot.find_element(
                    "chkNRCNPJ", By.ID, ensure_visible=True, ensure_clickable=True
                )

                if not elemento:
                    status_portal = f"Erro: Elemento não idetificado: {elemento} "
                    raise AttributeError(status_portal)

                status_portal = "Marcando CNPJ."
                bot.execute_javascript('document.querySelector("#chkNRCNPJ").click()')

                dados = FileHandler.obter_dados_planilha(caminho)
                num_itens = 0

                for i in range(len(dados["Sindicato Empregado"])):
                    ### inicio do laço for
                    cnpj = dados.iloc[i, 0]
                    sindicato_empreg = dados.iloc[i, 1]
                    nome_sindicato_emp = dados.iloc[i, 2]
                    
                    status_portal = preencher_pagina_inicial(cnpj)
                    status_portal
                    if 'sucesso' not in status_portal.lower():
                        raise Exception(status_portal)
                    
                    status_portal = validar_alerta()
                    if "nenhum registro encontrado" in status_portal.lower():
                        continue
                    else:
                        status_portal = obter_dados_convencao(cnpj, sindicato_empreg, nome_sindicato_emp,destino, diretorio, dados)
                   
                    # Aqui iniciar lógica para procurar o CNPJ e Sindicato correspondente.

                    
            except Exception as e:
                attempts += 1
                status_portal = f"Tentativa {attempts}: {e}"

                if attempts == max_attempts:
                    status_portal = f"Falha ao preencher formulário. Número máximo de {max_attempts} tentativas excedido."
                    raise Exception(status_portal)

            finally:
                if "falha" in status_portal.lower() or "erro" in status_portal.lower():
                    tipo_log = "error"
                elif "alerta" in status_portal.lower():
                    tipo_log = "warning"
                else:
                    tipo_log = "info"
                print(status_portal)
                
        else:
            print("status do portal não disponivel ou não foi definido")
            # gravar_satus(mensagem = status_portal, nivel = tipo_log)

            elemento = bot.find_element('//*[@id="btnLimpar', By.XPATH)
            if not elemento:
                status_portal = f"Erro: Elemento não idetificado: {elemento}. "
                raise AttributeError(status_portal)

            bot.execute_javascript('document.querySelector("#btnLimpar").click()')
            if num_itens != len(dados["CNPJ Empregados"]):
                status_portal = f"Execução de baixa concluída, porém nem todos os {len(dados['CNPJ Empregados'])}. Total de itens processados: {num_itens}!"
            status_portal = f"Exceução de baixa de dados concluída com sucesso. Todos os dados procurados foram encontrados!"

        return status_portal


@staticmethod
def gerar_nome_arquivo(nome_original):
    palavras = nome_original.split()  # Divide a string em palavras
    resultado = []

    for palavra in palavras:
        if len(palavra) > 4:
            # Se a palavra tiver mais de 4 caracteres, pega apenas os 4 primeiros
            resultado.append(palavra[:4])
        else:
            # Se a palavra tiver 4 caracteres ou menos, mantém a palavra original
            resultado.append(palavra)

    # Junta as palavras modificadas em uma string, separadas por underscore (ou qualquer outro separador desejado)
    return "_".join(resultado)


@staticmethod
def preencher_pagina_inicial(cnpj):
    try:
        elemento = bot.find_element(
            "txtNRCNPJ", By.ID, ensure_visible=True, ensure_clickable=True
        )
        if not elemento:
            status_portal = f"Erro: Elemento não idetificado: {elemento} "
            raise AttributeError(status_portal)

        if len(cnpj) <= 14:
            cnpj = f"{cnpj[:2]}.{cnpj[2:5]}.{cnpj[5:8]}/{cnpj[8:12]}-{cnpj[12:]}"

        status_portal = f"Informando CNPJ: {cnpj}"
        bot.execute_javascript(
            f'document.querySelector("#txtNRCNPJ").value = "{cnpj}"'
        )
        if elemento and hasattr(elemento, 'text'):
            status_portal= f"Alerta: {elemento.text}"
        print(status_portal)
        # bot.paste(cnpj)
        # gravar_satus(mensagem=status_portal)
        elemento = bot.find_element(selector="cboTPRequerimento", by=By.ID)
        if not elemento:
            status_portal = f"Erro: Elemento não idetificado: {elemento} "
            raise AttributeError(status_portal)

        status_portal = "Selecionando 'Tipo de Convenção Coletiva'"
        bot.execute_javascript(
            f'document.getElementById("cboTPRequerimento").value = "{Constantes.TIPO_INSTR_COLET}"'
        )

        print(status_portal)

        # gravar_satus(mensagem=status_portal)
        # Selecionar - Vigência:
        elemento = bot.find_element(selector="cboSTVigencia", by=By.ID)
        if not elemento:
            status_portal = f"Erro: Elemento não idetificado: {elemento} "
            raise AttributeError(status_portal)

        status_portal = "Selecionando 'Tipo Vigência'"
        print(status_portal)
        # gravar_satus(mensagem=status_portal)

        bot.execute_javascript(
            f'document.getElementById("cboSTVigencia").value = "{Constantes.TIPO_VIGENCIA}"'
        )
        status_portal = "Dados preenchidos com sucesso."
        print(status_portal)
        # gravar_satus(status_portal)
        bot.wait(500)
        bot.execute_javascript(
            'document.querySelector("#btnPesquisar").click()'
        )
        

    except Exception as e:
        status_portal = f"Erro ao preencher a página inicial: {str(e)}"
    finally:
        return status_portal

@staticmethod
def obter_dados_convencao(cnpj, sindicato_empreg, nome_sindicato_emp,destino, diretorio, dados):
    try:
        divs = bot.find_elements(selector="grdInstrumentos", by=By.ID)
        num_itens = 0
        status_portal = "Iniciando busca de dados da convenção coletiva." 
        
        if divs and len(divs)> 0:
            arr_divs = divs[0].text.split("Nº do Registro")

            linha = 2
            localizado = False
            nlinhas = bot.find_element(
                "#divFiltro > div > form > h2", By.CSS_SELECTOR
            )
            nlinhas = nlinhas.text.split(":")[1].split("Instrumento")[0].strip()
            for str in arr_divs:

                bot.execute_javascript(
                    f'document.querySelector("#grdInstrumentos > table > thead > tr:nth-child({linha}) > td > div > table > tbody > tr:nth-child(4) > td:nth-child(2) > span:nth-child(2) > a").click()'
                )

                tabs = bot.get_tabs()
                if len(tabs) > 0:
                    bot.activate_tab(tabs[1])
                    texto = bot.page_source().text

                if (
                    cnpj in texto
                    and sindicato_empreg in texto
                    and nome_sindicato_emp in texto
                ):
                    print("Texto encontrado.")
                    btn = bot.find_element(
                        f"/html/body/div[1]/form/input[2]", By.XPATH
                    )
                    btn.click()

                    arquivo = None
                    while True:

                        arquivo = bot.wait_for_new_file(
                            diretorio,
                            "*.doc*",
                        )

                        if arquivo:
                            localizado = True

                            novo_nome = nome_sindicato_emp  ## aqui voce vai tratar o nome do sindicato para ficar o padrão

                            complemento = (
                                texto.split("DATA DE REGISTRO NO MTE:")[0]
                                .split("NÚMERO DE REGISTRO NO MTE:")[1]
                                .strip()
                                .replace("/", "-")
                            )

                            # extensao = obter_extensao(arquivo)
                            extensao = FileHandler.obter_extensao(arquivo)
                            novo_nome = (
                                gerar_nome_arquivo(nome_sindicato_emp)
                                + "_"
                                + complemento
                                + extensao
                            )

                            status_portal = FileHandler.mover_e_renomear_arquivo(
                                arquivo, destino, novo_nome
                            )
                            print(status_portal)
                            break

                bot.close_page()
                if nlinhas != "1":
                    linha += 1

                if localizado:
                    btn = bot.find_element('//*[@id="btnFechar"]', By.XPATH)
                    btn.click()
                    num_itens += 1
                    break

                elif not localizado and nlinhas == "1":
                    print("Convensão não localizada.")
                    break


                ### fim do laço for


                if num_itens == len(dados["Sindicato Empregado"]):
                    status_portal = (
                        f"Todos os {num_itens} itens percorridos com sucesso."
                    )
                else:
                    status_portal = (
                        f"Somente {num_itens} foram processados corretamente."
                    )
                    #break
        
        # Lógica para obter os dados da convenção
        pass
    except Exception as e:
        status_portal = f"Erro ao obter os dados da convenção: {str(e)}"
    finally:
        return status_portal

def validar_alerta():
    try:
        elemento = bot.find_element(
            "/html/body/div[5]/div[2]/table/tbody/tr/td[2]", By.XPATH
        )
        if elemento:
            status_portal = elemento.text
            bot.execute_javascript('document.querySelector("body > div:nth-child(5) > div.ui-dialog-buttonpane.ui-widget-content.ui-helper-clearfix > div > button > span").click()')
            return status_portal
        
        return "Elemento não encontrado."    

    except Exception as e:
        status_portal = f"Erro ao validar alerta: {str(e)}"
    
        