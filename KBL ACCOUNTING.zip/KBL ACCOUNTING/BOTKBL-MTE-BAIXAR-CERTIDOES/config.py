# C:\Desenvolvimento\KBL-RPA\PYTHON\KBL ACCOUNTING\BOTKBL-HUBCOUNT-HUBALERTAS-DCTF\config.py
import os
import sys
import signal
import time
from datetime import datetime, timedelta
from pathlib import Path

# Adiciona o diretório bot_core ao sys.path para permitir importações de módulos dentro dele
sys_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.append(sys_path)
print(sys.path)

from bot_core.utils import Utils, Desencriptador, FileHandler
from bot_core.orchestrator import (
    get_jwt_token,
    get_asset_by_name,
    refresh_jwt_token,
    get_valid_access_token,
)
from bot_core.config_loader import ConfigLoader
from bot_core.log_manager import Logger, logging

config_loader = ConfigLoader()
logger = Logger.for_robot(config_loader)


class Constantes:
    # variáveis constantes,
    # NOME_USUARIO = ''
    # SENHA_USUARIO = ''
    UNIDADE_PADRAO = "PESSOAL"
    HORA_INICIO = datetime.now()
    NOME_AUTOMACAO = "BOTKBL-MTE-BAIXAR-CERTIDOES"

    # MENUS_PARA_BAIXAR = ['Nota fiscal eletrônica','Planilha de Taxa','Planilha de Serviço','Fatura']

    # Inserir aqui uma variável para receber a unidade Unimed do Orquestrador -- Goiânia
    PATH_RAIZ = Path(rf"C:\Automacao\MTE\{UNIDADE_PADRAO.upper()}")
    LOG_GERAL = Path(
        rf"C:\Automacao\Log_Execucao_{HORA_INICIO.strftime('%d_%m_%Y')}.txt"
    )
    LOG_ROBO = Path(
        rf"{PATH_RAIZ}\{HORA_INICIO.strftime('%m_%y')}\Execucao_{HORA_INICIO.strftime('%d_%m_%Y')}.txt"
    )

    # o path do projeto ou do arquivo poderão ser ajustados para a necessidade, tipo buscar um arquivo da rede
    PATH_PROJETO = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    PATH_ARQUIVO_ENTR = Path(rf"{PATH_PROJETO}\{NOME_AUTOMACAO}\arquivos\entrada")
    PATH_ARQUIVO_SAIDA = Path(rf"{PATH_PROJETO}\{NOME_AUTOMACAO}\arquivos\saida")

    # Para interações web informar as urls abaixo
    URL_CONFIG = f"chrome://settings/content/automaticDownloads"
    URL_CONFIG2 = f"chrome://settings/content/insecureContent"
    URL_CONFIG3 = (
        f"chrome://settings/content/siteDetails?site=http%3A%2F%2Fwww3.mte.gov.br"
    )
    URL_PORTAL = "URL-PORTAL MTE"
    URL_SEGURA = "www3.mte.gov.br"

    # ELEMENTOS FIXOS DO PORTAL
    CONSULTA_VALIDA1 = rf"conteudoTituloInterna"
    TIPO_INSTR_COLET = "convencao"  # constantes para tipo de acordo coletivo
    TIPO_VIGENCIA = "1"  # constantes para vigencia

    QUERY_JS_CONFIG1 = """
    document.querySelector("body > settings-ui")
        .shadowRoot.querySelector("#main")
        .shadowRoot.querySelector("settings-basic-page")
        .shadowRoot.querySelector("#basicPage > settings-section.expanded > settings-privacy-page")
        .shadowRoot.querySelector("#pages > settings-subpage > category-setting-exceptions")
        .shadowRoot.querySelector("site-list:nth-child(10)").shadowRoot.querySelector("#addSite").click()
    """
    QUERY_JS_CONFIG2 = """ document.querySelector("body > settings-ui").shadowRoot.querySelector("#main").shadowRoot.querySelector("settings-basic-page").shadowRoot.querySelector("#basicPage > settings-section.expanded > settings-privacy-page").shadowRoot.querySelector("#pages > settings-subpage > category-setting-exceptions").shadowRoot.querySelector("site-list:nth-child(10)").shadowRoot.querySelector("#addSite").click()"""

    QUERY_JS_CONFIG3 = """
    document.querySelector("body > settings-ui").shadowRoot.querySelector("#main")
        .shadowRoot.querySelector("settings-basic-page")
        .shadowRoot.querySelector("#basicPage > settings-section.expanded > settings-privacy-page")
        .shadowRoot.querySelector("#pages > settings-subpage > site-details")
        .shadowRoot.querySelector("div.list-frame > site-details-permission:nth-child(24)")
        .shadowRoot.querySelector("#permission").value = 'allow'
    """
    ENVIRONMENT = "DEV"  # DEV PARA PROJETOS EM DESENVOLVIMENTO, HML PARA PROJETOS EM HOMOLOGAÇÃO E PRD PARA PROJETOS EM PRODUÇÃO

    ####
    @classmethod
    def get_path_raiz(cls):
        return Path(f"C:/Automacao/{cls.UNIDADE_PADRAO}/{cls.NOME_AUTOMACAO}")

    @classmethod
    def get_log_geral(cls):
        return cls.LOG_GERAL

    @classmethod
    def get_encryption_key(cls):
        return cls.ENCRYPTION_KEY


class Orchestrator:
    """
    Classe responsável por interações com o Orquestrador.
    """

    # Inicializa tokens e define expiração inicial
    access_token, refresh_token, token_expiration_time = get_jwt_token(logger)
    expiration_buffer = timedelta(minutes=10)
    # token_expiration_time = datetime.now() + timedelta(hours=1)
    token_expiration_time = time.time() + 3600

    @classmethod
    def get_valid_access_token(cls):
        """Retorna um token válido, renovando se necessário."""
        if time.time() >= (
            cls.token_expiration_time - cls.expiration_buffer.total_seconds()
        ):
            cls.access_token, cls.refresh_token, cls.token_expiration_time = (
                get_valid_access_token(
                    cls.access_token,
                    cls.refresh_token,
                    cls.token_expiration_time,
                    logger,
                )
            )
        return cls.access_token

    @classmethod
    def get_asset_by_name(cls, asset_name):
        print(f"Buscando asset: {asset_name}")
        cls.get_valid_access_token()  # Verifica e renova o token antes de buscar o asset
        return get_asset_by_name(
            asset_name=asset_name,
            access_token=cls.access_token,
            refresh_token=cls.refresh_token,
            logger=logger,
        )


class RoboDesencriptador:
    def obter_credenciais(self, asset):
        desencriptador = Desencriptador()
        return desencriptador.obter_credenciais(asset)


class Signals:
    @staticmethod
    def signal_handler(signum, frame):
        from uteis.browsers_bot import manipulate_browsers

        # Função para lidar com sinais SIGTERM e SIGINT
        status_message = "Sinal recebido, finalizando o robô de forma controlada."
        print(status_message)
        try:
            if "bot" in locals():
                status_message = manipulate_browsers.close_browser(
                    Orchestrator.access_token
                )
                status_message = f"Status do processamento: {status_message}"
            status_message += f" | Finalizando automação {Constantes.NOME_AUTOMACAO}."
            log_status(
                Constantes.NOME_AUTOMACAO,
                "terminated",
                status_message,
                "final",
                nivel="warning",
            )
        except Exception as e:
            print(f"Erro ao finalizar o robô após sinal: {str(e)}")
        sys.exit(0)

    @staticmethod
    def setup_signal_handlers():
        """Função para registrar os sinais SIGTERM e SIGINT"""
        signal.signal(signal.SIGTERM, Signals.signal_handler)
        signal.signal(signal.SIGINT, Signals.signal_handler)


def log_status(bot_name, status_exec, status_message, local, level, access_token):
    logger.gravar_status(
        bot_name,
        status_exec,
        status_message,
        local,
        nivel=level,
        access_token=access_token,
        environment=Constantes.ENVIRONMENT,
    )
