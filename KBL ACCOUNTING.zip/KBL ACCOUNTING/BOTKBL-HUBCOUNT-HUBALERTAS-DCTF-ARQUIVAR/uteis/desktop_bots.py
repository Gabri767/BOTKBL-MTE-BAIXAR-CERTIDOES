import subprocess
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'bot_core')))

from pathlib import Path
from botcity.core import DesktopBot, Backend
from uteis.etl import *
from uteis.files_manipulation import *
from bot_core.utils import Utils





bot = DesktopBot()
backend = Backend
codigo = '16352'

class sistemas_dominio:
    


    ###Abrir o sistema domínio
    def abrir_sistema_dominio(app_path):
        #modulo = modulos[1]
        #app_run = [app_path,modulo]
        #subprocess.run(app_run)
        status_bot = 'Iniciando Sistema Domínio.'
        try:

            print(status_bot)
            iniciar_dominio = True
            bot.execute(app_path)
            
            while iniciar_dominio == True:
                bot.sleep(500)
                bot.connect_to_app(backend=backend.UIA, path=app_path)
                pop_up_window = bot.find_app_window(title_re="Conectando")
                
                print(pop_up_window)
                
                if not bot.find("nome_usuario", matching=0.97, waiting_time=10000):
                    Exception("Element 'nome_usuario' not found")
                
                bot.double_click_relative(161, 5)
                bot.type_keys(Constantes.EMAIL_LOGIN)

                if not bot.find("senha", matching=0.97, waiting_time=10000):
                    Exception("Element 'senha' not found!")
                
                bot.double_click_relative(155, 7)
                bot.type_keys(Constantes.SENHA_LOGIN)

                btn_dominio = bot.find_app_element(from_parent_window=pop_up_window, class_name="Button", 
                                                title="OK")

                btn_dominio.click()
                
                while bot.find("tela_login", matching=0.97, waiting_time=10000):
                    print("Aguardando tela de login fechar")

                if bot.find("pop-upaviso", matching=0.97, waiting_time=10000):
                    print('Tela atualiza apareceu')
                    bot.find("btn-sim", matching=0.97, waiting_time=10000)
                    bot.key_enter()
                    if bot.find("pop_up_assistente_atualiza", matching=0.97, waiting_time=10000):
                        status_bot = atualiza_dominio()
                        

                while bot.find("tela_aguardar", matching=0.97, waiting_time=10000):
                    print("Tela aguardar carregar fechar")
                    # #{image:"pop-upatencao"}

                    pop_up_atencao = bot.find("pop_up_atencao", matching=0.97, waiting_time=10000)
                    if pop_up_atencao:
                        
                        print('Tela atenção apareceu')
                        bot.key_enter()
                        status_bot = atualiza_dominio()
                        print(status_bot)
                    
                

                if not bot.connect_to_app(backend=backend.UIA, path=app_path):
                    iniciar_dominio = True
                
                status_bot = 'Executou até aqui: "ABRIR_SISTEMA_DOMINIO"'
                    
                print(status_bot)

                main_window = bot.find_app_window(title_re="Domínio ")
                print(main_window)
    
                iniciar_dominio = False
        
        except Exception as e:
            status_bot = str(e)
            print(status_bot)

        finally:
            return status_bot


def extrair_relatorio_balancete():
    print('Extrair Relatório Balancete iniciado')
    try:
        app_path = "Contabil.exe"
        bot.connect_to_app(backend=backend.UIA, path=app_path)
        main_window = bot.find_app_window(title_re="Domínio Contab", class_name="FNWND3190")
        if not bot.find("menu_dominio", matching=0.97, waiting_time=10000):
            Exception("Menu Dominio not found!")
        
        codigo_emp = codigo
        
        status_bot = selecionar_empresa_balancete(codigo_emp,app_path,main_window)

        modulo = 'Contabilidade'
        status_bot = selecinar_modulo(modulo,app_path,main_window)
        print(status_bot)
        


        
        
        bot.alt_r(wait=200)
        bot.type_key('b',interval=200)
        bot.key_enter(wait=200)
        '''    
        menu_click = bot.find_app_element(from_parent_window=main_window,title_re="Relatórios")
        menu_click.click()

        menu_click = bot.find_app_element(from_parent_window=main_window, title_re="Balancete")
        menu_click.click()
        '''
        painel_balancete = bot.find_app_element(from_parent_window=main_window, control_type="Window" , class_name = "FNWND3190", title_re = "Balancete")
        if not painel_balancete:
            raise Exception('Element not found.')
        
        #bot.find_app_element(from_parent_window=main_window, control_type="Pane" , class_name = "Pane")

        if not bot.find("btn_sub_geral", matching=0.97, waiting_time=10000):
            raise Exception("btn_sub_geral not found.")

        if not bot.find("btn_sub_geral_rel", matching=0.97, waiting_time=10000):
            raise Exception("btn_sub_geral_rel not found.")
        bot.click_relative(22, 15)
        
        print('Informando data de inicio do relatório')
        data_inicio = "01/07/2024"
        bot.tab()
        bot.type_keys(data_inicio)
        
        print('Informando data de fim do relatório')
        data_fim = "31/07/2024"
        bot.tab()
        bot.type_keys(data_fim)

        bot.tab()
        bot.type_key("1")

        print('Enviando Alt+o')
        bot.type_keys(['Alt','o'])

        if not bot.find("btn_sel_excel", matching=0.97, waiting_time=10000):
            Exception("Elelent 'btn_sel_excel' not found.")
        bot.click_relative(11, 13)
        
        # Finding element to type the name of file
        bot.find_app_element(from_parent_window=main_window, class_name="Edit", 
                                    title="File name:")
        # Typing the file name

        filename = rf'{Constantes.PATH_ARQUIVO_ENTR}\Balancete.xls'
        print(filename)
        bot.kb_type(filename)


        # Finding element to clicks on button save
        btn_save = bot.find_app_element(from_parent_window=main_window, class_name="Button", 
                                            title="Salvar")
        # Clicking on button save
        btn_save.click()

        popup_salvar = bot.find_app_element(from_parent_window=main_window, control_type="Window", title="Salvar")    
        if popup_salvar:
            print('Arquivo já Existe.')
            btn_continue = bot.find_app_element(from_parent_window=main_window, title="Sim", class_name="Button")
            # Performing some operations with the found element.
            btn_continue.click()
        else:
            print('Arquivo não existe.')



        bool_satate = False
        try:
            while bool_satate == False: 
                bool_satate = Utils.find_and_kill_process_by_name("EXCEL.EXE")
                bot.wait(5000)
                print(str(bool_satate))
        except:
            pass

        if not bot.find("btn_fechar_int", matching=0.97, waiting_time=10000):
            Exception('Element "btn_fechar_int" not found')
        bot.click_relative(40, 14)
        status_bot = rf'Balancete salvo em: {filename}'




        # Finding element to clicks on button save
        btn_fechar = bot.find_app_element(from_parent_window=main_window, class_name="Button", 
                                            title="Fechar")
        # Clicking on button save
        btn_fechar.click()



    except Exception as e:
        status_bot = str(e)
        print(status_bot)

    
    finally:
        return status_bot


###Exportar o arquivo
def exportar_relatorios(relatorios,caminho_salvar):
    pass


# #{image:"nome_usuario"}



###Importar arquivo
def importar_arquivos():
    pass


def atualiza_dominio():
    

    if bot.find("pop_up_assistente_atualiza", matching=0.97, waiting_time=10000):
        while bot.find("pop_up_assistente_atualiza", matching=0.97, waiting_time=2000):
            btn_avancar_ativo = bot.find("btn_avancar_active", matching=0.97, waiting_time=2000)
            btn_avancar_nao_ativo =  bot.find("btn_avancar_not_active", matching=0.97, waiting_time=2000)
            btn_atualizar_ativo = bot.find("btn_atualizar_nao_ativo", matching=0.97, waiting_time=2000)
            btn_atualizar_nao_ativo = bot.find("btn_atualizar_ativo", matching=0.97, waiting_time=2000)
            if btn_avancar_ativo or btn_avancar_nao_ativo or btn_atualizar_ativo or btn_atualizar_nao_ativo:
                bot.enter()
                print('Tecla enter enviada!')        
            print('Aguardando atualizar!')
            if bot.find("btn_concluir", matching=0.97, waiting_time=10000):
                bot.enter()
                print('Sistema Atualizado!')
    else:
        app_path = rf"C:\AtualizaDominio\Contabil\Baixar atualizacao v5.bat"
        bot.execute(app_path)
        status = 'Sistema domínio atualizado'
        atualiza_cmd = bot.connect_to_app(backend=Backend.UIA, path=app_path)
        while atualiza_cmd:
            status = atualiza_cmd.state
    
    return status



def selecinar_modulo(modulo,app_path,main_window):
    try:
        if str(modulo).lower() == 'contabilidade':
            print(modulo)
            bot.connect_to_app(backend=backend.UIA, path=app_path)
            
            if main_window:
                print('janela encontrada')
            
            if not bot.find("btn_dominio", matching=0.97, waiting_time=10000):
                Exception("Element btn_dominio not found")
            bot.click_relative(37, 13)
            
            if not bot.find("btn_contabilidade", matching=0.97, waiting_time=10000):
                Exception("Element 'btn_contabilidade' not found")
            bot.click_relative(47, 13)

            while bot.find("janela_dominio", matching=0.97, waiting_time=10000):
                print("Aguarde")
            
            status_local = f'Modulo {modulo} selecionado.'
            
    except Exception as e:

        status_local = str(e)
    
    finally:
        return status_local
    


def selecionar_empresa_balancete(codigo_emp,app_path,main_window):
    try:
        status_sel = f'Selecionar a empresa: {codigo_emp}.'


        if not main_window:
            raise
        janela_existe = 'True'
        bot.key_f8()

        # Searching for the main window.

        if not bot.find("radiobutton_codigo", matching=0.97, waiting_time=10000):
            raise Exception('Element "radiobutton_codigo" not found')
        bot.click_relative(20, 30)


        if not bot.find("edit_box_cod_emp", matching=0.97, waiting_time=10000):
            raise Exception('Element"edit_box_cod_emp" not found')
        bot.click_relative(30, 36)

        text_edit = bot.find_app_element(from_parent_window=main_window, control_type='Edit', class_name='Edit')
        text_edit.past(codigo_emp)
        bot.enter()
        
        
        while janela_existe==True:
            if not bot.find_app_element(from_parent_window=main_window, title_re='Troca de empresas'):
                status_sel = False
        
        status_sel = f'Empresa {codigo_emp} selecionada com sucesso.'

    except Exception as e:
        status_sel = f'Erro ao selcionar a emmpresa: {codigo_emp}. Motivo {e}.'
        
    
    finally:
        return status_sel