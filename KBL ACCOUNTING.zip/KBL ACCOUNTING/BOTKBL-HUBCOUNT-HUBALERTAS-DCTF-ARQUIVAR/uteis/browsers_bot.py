# Código do process_bot.py atualizado

from botcity.web import WebBot, Browser, By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from config import *


bot = WebBot()


# Classe padrão para o início do bot
class manipulate_browsers:

    @staticmethod
    def open_browser():
        try:
            bot.driver_path = (
                ChromeDriverManager()
                .install()
                .replace(f"/THIRD_PARTY_NOTICES.chromedriver",r"\chromedriver.exe")
            )
            bot.headless = False
            bot.start_browser()
            bot.maximize_window()
            status_process = "Navegador aberto com sucesso."
            return status_process, bot

        except Exception as e:
            raise
            

    @staticmethod
    def fazer_login_inputs(name):
        local = "Fazer Logins via Inputs"
        max_attempts = 3
        attempts = 0
        status_portal = "Fução Login iniciado."

        credenciais_encriptadas = Orchestrator.get_asset_by_name(name)
        # Instancia o Desencriptador
        desencriptador = Desencriptador()

        try:
            # Obtem as credenciais desencriptadas, passando o dicionário correto
            credenciais = desencriptador.obter_credenciais(credenciais_encriptadas)
            # Usa as credenciais desencriptadas para login
            user_login = credenciais["username"]
            pswd_login = credenciais["password"]

        except Exception as e:
            status_portal = f"Erro ao desencriptar credenciais: {e}"
            log_status(
                bot_name=Constantes.NOME_AUTOMACAO,
                status_exec="in_progress",
                status_message=status_portal,
                local=local,
                level=logging.ERROR,
                access_token=Orchestrator.access_token,
            )

        log_status(
            bot_name=Constantes.NOME_AUTOMACAO,
            status_exec="in_progress",
            status_message=status_portal,
            local=local,
            level=logging.INFO,
            access_token=Orchestrator.access_token,
        )

        while attempts < max_attempts:
            try:
                status_portal = ""
                seletores_js = [
                    "#ShowLoginForm > div:nth-child(2) > input",
                    "#ShowLoginForm > div:nth-child(3) > input",
                    "#ShowLoginForm > div:nth-child(4) > input",
                    "#ShowLoginForm > div.form-actions > button",
                ]  # alterar para os Ids dos campos
                querys_execute = [
                    Constantes.QUERY_JS_TYPE,
                    Constantes.QUERY_JS_TYPE,
                    Constantes.QUERY_JS_TYPE,
                    Constantes.QUERY_JS_CLICK,
                ]

                ###Logins com inputs de usuario e senha padrão
                replaces_valor = ["kbl", user_login, pswd_login, ""]
                for index, valor in enumerate(seletores_js):
                    seletor_js = valor
                    replace_valor = replaces_valor[index]
                    query_execute = querys_execute[index]
                    query_execute = query_execute.replace(
                        "seletor_js_path", seletor_js
                    ).replace("valor_esperado", replace_valor)
                    bot.execute_javascript(query_execute)

                elemento = None

                ##resetar senha ou senha expirada:
                if bot.find_element(
                    "ResetPasswordForm",
                    By.ID,
                    ensure_visible=True,
                    ensure_clickable=True,
                ):
                    ###criar rotina para enviar um email
                    raise "É necessário fazer o reset de senha!"

                while elemento == None:
                    elemento = bot.find_element(
                        "ShowLoginForm > div.form-actions > button",
                        By.ID,
                        ensure_visible=True,
                        ensure_clickable=True,
                    )  # substituir para o id do elemento desejado
                    if not elemento:
                        break

                status_portal = "Login realizado com sucesso!"

            except Exception as e:
                status_portal = f"{e}"
                tipo_log = "error"
                attempts += 1
                status_portal = f"Tentativa {attempts}: {e}"
                if attempts == max_attempts:
                    status_portal = f"Falha ao preencher formulário. Número máximo de {max_attempts} tentativas excedido."
                    raise Exception(status_portal)

            finally:
                return status_portal

    # usar em caso de login que usa teclado virtual.

    @staticmethod
    def close_browser():
        bot.stop_browser()  # Finaliza e limpa o navegadorEX
        # gravar_status(Constantes.NOME_AUTOMACAO,mensagem= status_portal, local = local, nivel= tipo_log)


#####outras classes personalizadas abaixo:
class hub_count_dctf:

    @staticmethod
    def acessar_hub_count():
        try:
            local = "Acessar HubCount"
            status_local = "Iniciando o Hubcount da KBL."
            name = Constantes.ASSET_URL_HUBCOUNT
            try:
                url_asset = Orchestrator.get_asset_by_name(name)
                url_portal = url_asset["value_text"]

            except Exception as e:
                status_local = f"Hubcount não iniciado. Motivo: {str(e)}"
                raise Exception(status_local)

            bot.navigate_to(url_portal)
            name = Constantes.ASSET_CREDENTIALS_HUB
            status_local = manipulate_browsers.fazer_login_inputs(name)

            bot.navigate_to(
                "https://web.hubcount.com.br/index.html#!/tenant/hubAlertas/companyNotifications"
            )
            status_local = "Hubcount iniciado com sucesso."
            return status_local
        except Exception as e:
            status_local = f"Erro ao iniciar o Hubcount. Motivo: {str(e)}"
            raise Exception(e)

    @staticmethod
    def hubalertas_dctf_filtrar():
        try:
            status_local = (
                "Iniciando leitura de mensagens: [DCTF] Original Recepcionada "
            )
            elemento = None
            while True:
                if bot.find_element(
                    '//*[@id="vertical-tabpanel-0"]/div/div/div/div[1]/div/div/div[1]/div[2]/h6/b',
                    By.XPATH,
                    ensure_visible=True,
                    ensure_clickable=True,
                ):
                    elemento = bot.find_element(
                        '//*[@id="vertical-tabpanel-0"]/div/div/div/div[1]/div/div/div[1]/div[2]/h6/b',
                        By.XPATH,
                    )

                    try:
                        elemento.click()
                    except Exception as e:
                        elemento = None
                        break

            while True:

                if bot.find_element(
                    "/html/body/div[7]/div[3]/div[4]/div[1]/button[1]",
                    By.XPATH,
                    ensure_clickable=True,
                    ensure_visible=True,
                ):
                    elemento = bot.find_element(
                        "/html/body/div[7]/div[3]/div[4]/div[1]/button[1]", By.XPATH
                    )

                    if "EXPORTAR" in elemento.text:
                        elemento = bot.find_element(
                            '//*[@id="advanced-filter"]/div[1]', By.XPATH
                        )
                        break
                    else:
                        pass
            elemento.click()

            bot.execute_javascript(
                'document.querySelector("#advanced-filter > div > div.MuiGrid-root.MuiGrid-container.MuiGrid-spacing-xs-1.css-x7okg2 > div:nth-child(1) > button").click()'
            )

            elemento = bot.find_element(
                "subject",
                By.ID,
                waiting_time=10000,
                ensure_visible=True,
                ensure_clickable=True,
            )
            elemento.click()
            bot.paste("[DCTF]")
            bot.execute_javascript(
                'document.querySelector("#advanced-filter > div > div.MuiGrid-root.MuiGrid-container.MuiGrid-spacing-xs-1.css-x7okg2 > div:nth-child(2) > button").click()'
            )

            status_local = "Mensagems filtradas com sucesso."
            return status_local
        except Exception as e:
            raise

    @staticmethod
    def buscar_mensagens():
        elemento = bot.find_element(
            '//*[@id="advanced-filter"]/div/div[2]/div[2]/button', By.XPATH
        )

        elemento.click()

        while True:

            if bot.find_element(
                "/html/body/div[7]/div[3]/div[1]/span",
                By.XPATH,
                waiting_time=5000,
                ensure_visible=True,
            ):
                pass
            else:
                break

        paginas = bot.find_elements(
            "/html/body/div[7]/div[3]/div[6]/nav/ul/li", By.XPATH
        ) #find_elements irá procurar todos os itens que contem esta tag acima

        total_paginas = int(paginas[-2].text)
        # total_mensagens = len(mensagens)
        return total_paginas

    @staticmethod
    def ler_mensagens_dctf(arquivo, pag):

        try:

            mensagens_lidas = []
            msgs_pagina = []
            div = 0

            mensagens = bot.find_elements(
                "/html/body/div[7]/div[3]/div[5]/div[1]/div/div",
                By.XPATH,
                ensure_visible=True,
            )

            for msg in mensagens:

                div += 1

                dados_mensagem = msg.text.split("\n")
                hora_atual = datetime.now()
                bot.execute_javascript(
                    f'document.querySelector("body > div.MuiModal-root.css-8ndowl > div.hub-modal.modal-dialog.MuiBox-root.css-1imvgps > div:nth-child(6) > div.MuiGrid-root.MuiGrid-item.MuiGrid-grid-xs-6.css-1s50f5r > div > div:nth-child({div}) > div > div > div > div:nth-child(1) > span > input").click()'
                )

                msgs_pagina.append(
                    {
                        "ASSUNTO": dados_mensagem[0],
                        "CNPJ_CPF": dados_mensagem[1],
                        "NOME": dados_mensagem[2],
                        "RECEBIDO": dados_mensagem[3],
                        "CRIADO": dados_mensagem[4],
                        "ATUALIZADO": dados_mensagem[4],
                        "STATUS": "SUCESSO",
                        "LEITURA": hora_atual.strftime("%d/%m/%Y %H:%M:%S"),
                    }
                )

            bot.execute_javascript('document.querySelector("#bashActions").click()')
            # bot.execute_javascript('//*[@id="actions-menu"]/div[3]/ul/li[2].click()')
            bot.execute_javascript('document.querySelector("#bashActions").click()')
            bot.execute_javascript('document.querySelector("#actions-menu > div.MuiPaper-root.MuiMenu-paper.MuiPaper-elevation.MuiPaper-rounded.MuiPaper-elevation8.MuiPopover-paper.css-oapmtd > ul > li:nth-child(3)").click()')
            FileHandler.gravar_em_csv_append(msgs_pagina, arquivo)
            mensagens_lidas.extend(msgs_pagina)

            msg_success = sum(1 for item in msgs_pagina if item["STATUS"] == "SUCESSO")

            msg_falha = sum(1 for item in msgs_pagina if item["STATUS"] == "FALHA")
            local = ("Ler Mensagem Hub Count",)
            status_portal = f"Mensagens da página {pag}, gravadas no arquivo. Sucesso: {msg_success}. Falha: {msg_falha}."
            log_status(
                bot_name=Constantes.NOME_AUTOMACAO,
                status_exec="in_progress",
                status_message=status_portal,
                local=local,
                level=logging.INFO,
                access_token=Orchestrator.access_token,
            )

            total_msg_success = sum(
                1 for item in mensagens_lidas if item["STATUS"] == "SUCESSO"
            )

            total_msg_falha = sum(
                1 for item in mensagens_lidas if item["STATUS"] == "FALHA"
            )

            status_local = f"Mensagens: {mensagens_lidas} gravada no arquivo. SUCESSO: {total_msg_success}, FALHA: {total_msg_falha}"

        except Exception as e:
            status_local = str(e)

        finally:
            total_mensagens = len(mensagens_lidas)
            return status_local, total_mensagens

    @staticmethod
    def arquivar_mensagens():
        try:
            checkbox_state = bot.find_element('body > div.MuiModal-root.css-8ndowl > div.hub-modal.modal-dialog.MuiBox-root.css-1imvgps > div.MuiGrid-root.MuiGrid-container.css-ty5q8l > div.MuiGrid-root.MuiGrid-item.MuiGrid-grid-xs-6.css-1s50f5r > label > span.MuiButtonBase-root.MuiCheckbox-root.MuiCheckbox-colorPrimary.PrivateSwitchBase-root.MuiCheckbox-root.MuiCheckbox-colorPrimary.Mui-checked.MuiCheckbox-root.MuiCheckbox-colorPrimary.css-zun73v > input',By.CSS_SELECTOR)
            if not checkbox_state:
                bot.execute_javascript(
                    'document.querySelector("body > div.MuiModal-root.css-8ndowl > div.hub-modal.modal-dialog.MuiBox-root.css-1imvgps > div.MuiGrid-root.MuiGrid-container.css-ty5q8l > div.MuiGrid-root.MuiGrid-item.MuiGrid-grid-xs-6.css-1s50f5r > label > span.MuiTypography-root.MuiTypography-body1.MuiFormControlLabel-label.css-ogpucm").click()'
                )
            else:
                bot.execute_javascript(
                    'document.querySelector("body > div.MuiModal-root.css-8ndowl > div.hub-modal.modal-dialog.MuiBox-root.css-1imvgps > div.MuiGrid-root.MuiGrid-container.css-ty5q8l > div.MuiGrid-root.MuiGrid-item.MuiGrid-grid-xs-6.css-1s50f5r > label > span.MuiButtonBase-root.MuiCheckbox-root.MuiCheckbox-colorPrimary.PrivateSwitchBase-root.MuiCheckbox-root.MuiCheckbox-colorPrimary.Mui-checked.MuiCheckbox-root.MuiCheckbox-colorPrimary.css-zun73v > input").click()'
                )
                bot.sleep(1000)
                bot.execute_javascript(
                    'document.querySelector("body > div.MuiModal-root.css-8ndowl > div.hub-modal.modal-dialog.MuiBox-root.css-1imvgps > div.MuiGrid-root.MuiGrid-container.css-ty5q8l > div.MuiGrid-root.MuiGrid-item.MuiGrid-grid-xs-6.css-1s50f5r > label > span.MuiTypography-root.MuiTypography-body1.MuiFormControlLabel-label.css-ogpucm").click()'
                )
            bot.execute_javascript(
                'document.querySelector("#bashActions").click()'
            )
            bot.execute_javascript(
                'document.querySelector("#actions-menu > div.MuiPaper-root.MuiMenu-paper.MuiPaper-elevation.MuiPaper-rounded.MuiPaper-elevation8.MuiPopover-paper.css-oapmtd > ul > li:nth-child(3)").click()'
            )
            bot.execute_javascript(
                'document.querySelector("#actions-menu > div:nth-child(4)").click()'
            )
            bot.sleep(2000)
            bot.execute_javascript(
            'document.querySelector("body > div.MuiModal-root.css-8ndowl > div.hub-modal.modal-dialog.MuiBox-root.css-1imvgps > div.MuiGrid-root.MuiGrid-container.css-t7lb4m > nav > ul > li:nth-child(2) > button").click()'
            )
            
            return
        except Exception as e:
            raise
    
    @staticmethod
    def acoes_em_lote(acoes_lote):
        try:
           bot.execute_javascript(
                'document.querySelector("#bashActions").click()'
                
            )
 

        except Exception as e:
            raise
    @staticmethod
    def acoes_em_lote(acoes_lote):
        try:
           bot.execute_javascript(
                'document.querySelector("#actions-menu > div.MuiPaper-root.MuiMenu-paper.MuiPaper-elevation.MuiPaper-rounded.MuiPaper-elevation8.MuiPopover-paper.css-oapmtd > ul > li:nth-child(3)").click()'
           )        
        except Exception as e:
            raise
    def proxima_pagina(num_pag):
        next_pagina = bot.find_element(
            f"/html/body/div[7]/div[3]/div[6]/nav/ul/li[{num_pag}]",
            By.XPATH,
        )
        next_pagina.click()
