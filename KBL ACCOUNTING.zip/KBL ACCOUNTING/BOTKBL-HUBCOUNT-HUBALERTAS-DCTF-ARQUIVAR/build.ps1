$exclude = @("venv", "BOTKBL-HUBCOUNT-HUBALERTAS-DCTF-ARQUIVAR.zip")
$files = Get-ChildItem -Path . -Exclude $exclude
Compress-Archive -Path $files -DestinationPath "BOTKBL-HUBCOUNT-HUBALERTAS-DCTF-ARQUIVAR.zip" -Force