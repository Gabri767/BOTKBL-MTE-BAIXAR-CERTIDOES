"""
Este robô tem por objetivo acessar o portal do HUB Count da KBL, acessar
a opção e-Cac, filtrar as mensagens não lidas, com o assunto
[DCTF - ] e que estão arquivadas e fazer a leitura destas mensagens.

VERSÃO ATUAL: 1.0.0
DATA DA VERSÃO: 17/10/2024
IDEALIZADO POR: BRUNO PRADO
DESENVOLVIDO POR: ERISTON SANTOS
"""

# KBL ACCOUNTING\BOTKBL-HUBCOUNT-HUBALERTAS-DCTF\bot.py
from botcity.maestro import *
from config import *
from uteis.browsers_bot import manipulate_browsers, hub_count_dctf


def main():
    # Configura os handlers de sinal para lidar com SIGTERM e SIGINT
    Signals.setup_signal_handlers()
    start_time = Constantes.HORA_INICIO
    start_time_str = start_time.strftime("%d/%b/%Y %H:%M:%S.%f")[:-3]
    bot_name = Constantes.NOME_AUTOMACAO
    status_exec = "in_progress"
    status_message = f"Iniciando automação {bot_name} em {start_time_str}."
    local = "Início"
    level_log = logging.INFO
    arquivo = rf"{Constantes.PATH_ARQUIVO_SAIDA}\MENSAGENS_DCTF_{start_time.strftime('%d%m%Y')}.csv"
    FileHandler.create_file_if_not_exists(arquivo)

    try:
        log_status(
            bot_name,
            status_exec,
            status_message,
            local,
            level=level_log,
            access_token=Orchestrator.access_token,
        )
        ### Bloco iniciando as dependências do bot
        try:
            status_message, bot = manipulate_browsers.open_browser()
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )

            status_message = f"Status do processamento: {status_message}"
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )

            status_message = hub_count_dctf.acessar_hub_count()
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )

            status_message = hub_count_dctf.hubalertas_dctf_filtrar()
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )

        except Exception as e:
            status_message = f"Erro ao iniciar o bot: {str(e)}"
            raise Exception(status_message)

        ### Bloco de processamento do robô
        try:
            total_paginas = 1
            paginas = 1
            local = "Bloco de processamento das informações do robô"
            status_message = "Iniciando processamento"
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )

            
            tempo_leitura = datetime.now()
            while True:
                status_message = hub_count_dctf.arquivar_mensagens()
                total_paginas = hub_count_dctf.buscar_mensagens()
                if total_paginas > 1:
                    paginas += 1
                else:
                    break
            tempo_final = Utils.tempo_decorrido(tempo_leitura)
            
            status_message = f"Leitura de mensagens concluído. Foram lidas: {paginas} mensagens em: {tempo_final[1]} ({tempo_final[0]:.2f} segundos)."
            level_log = logging.INFO
            status_exec = "success"

        except Exception as e:
            status_message = f"Erro durante o processamento: {str(e)}"
            level_log = logging.ERROR
            status_exec = "failure"

    except Exception as e:
        status_message = f"Erro ao obter token JWT: {str(e)}"
        level_log = logging.ERROR
        status_exec = "failure"

    finally:
        log_status(
            bot_name,
            status_exec,
            status_message,
            local,
            level=level_log,
            access_token=Orchestrator.access_token,
        )

        # Bloco de finalização do robô
        try:
            if "bot" in locals():
                status_message = "Finalizando processamento dos dados."
                bot.wait(3000)
                status_message = manipulate_browsers.close_browser()
                status_message = f"Status do processamento: {status_message}"

            status_message += f" | Finalizando automação {bot_name}."
            level_log = logging.INFO
            status_exec = "success"

        except Exception as e:
            status_message += (
                f" | Erro ao finalizar o bot {bot_name}, erro identificado: {str(e)}."
            )
            level_log = logging.ERROR
            status_exec = "failure"

        finally:
            tempo_final = Utils.tempo_decorrido(start_time)
            status_message += f" | Tempo total de execução: {tempo_final[1]} ({tempo_final[0]:.2f} segundos)."
            local = "Finalização do robô"
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )

    return status_message


if __name__ == "__main__":
    try:
        status_bot = main()

    except Exception as e:
        from datetime import datetime

        now = datetime.now().strftime("%d/%b/%Y %H:%M:%S")
        log_status(
            bot_name=Constantes.NOME_AUTOMACAO,
            status_exec="failure",
            status_message=f"Erro na execução do bot: {str(e)} em {now}",
            local="final",
            level=logging.ERROR,
            access_token=Orchestrator.access_token,
        )
