# C:\Desenvolvimento\KBL-RPA\PYTHON\KBL ACCOUNTING\BOTKBL-HUBCOUNT-HUBALERTAS-DCTF\config.py

import os
import sys
import signal
import time
from datetime import datetime, timedelta
from pathlib import Path

# Adiciona o diretório bot_core ao sys.path para permitir importações de módulos dentro dele
sys_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.append(sys_path)
print(sys.path)

from bot_core.utils import Utils, Desencriptador, FileHandler
from bot_core.orchestrator import (
    get_jwt_token,
    get_asset_by_name,
    refresh_jwt_token,
    get_valid_access_token,
)
from bot_core.config_loader import ConfigLoader
from bot_core.log_manager import Logger, logging

config_loader = ConfigLoader()
logger = Logger.for_robot(config_loader)


class Constantes:
    """
    Classe que armazena constantes utilizadas em todo o projeto.
    """

    HORA_INICIO = datetime.now()
    NOME_AUTOMACAO = "BOTKBL-HUBCOUNT-HUBALERTAS-DCTF-ARQUIVAR"
    PATH_PROJETO = Path(__file__).parent.absolute()
    PATH_ARQUIVO_ENTR = PATH_PROJETO / "arquivos/entrada"
    PATH_ARQUIVO_SAIDA = PATH_PROJETO / "arquivos/saida"
    URL_CONFIG = "chrome://settings/content/automaticDownloads"
    URL_CONFIG2 = "chrome://settings/content/insecureContent"
    URL_CONFIG3 = ""  # somente quando necessário mais ajustes no navegador
    QUERY_JS_CLICK = 'document.querySelector("seletor_js_path").click()'
    QUERY_JS_TYPE = 'document.querySelector("seletor_js_path").value = "valor_esperado"'
    DIA_BASE = 20
    ASSET_URL_HUBCOUNT = "HUBCOUNT-URL"
    ASSET_CREDENTIALS_HUB = "HUB-COUNT-LOGIN"
    ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY")
    ENVIRONMENT = 'PRD'

    @classmethod
    def get_path_raiz(cls):
        return Path(f"C:/Automacao/UNIDADE-CONTABIL/{cls.NOME_AUTOMACAO}")

    @classmethod
    def get_log_geral(cls):
        return cls.LOG_GERAL

    @classmethod
    def get_encryption_key(cls):
        return cls.ENCRYPTION_KEY


class Orchestrator:
    """
    Classe responsável por interações com o Orquestrador.
    """

    # Inicializa tokens e define expiração inicial
    access_token, refresh_token, token_expiration_time = get_jwt_token(logger)
    expiration_buffer = timedelta(minutes=10)
    token_expiration_time = datetime.now() + timedelta(hours=1)

    @classmethod
    def get_valid_access_token(cls):
        """Retorna um token válido, renovando se necessário."""
        if datetime.now() >= (cls.token_expiration_time - cls.expiration_buffer):
            cls.access_token, cls.refresh_token, cls.token_expiration_time = (
                get_valid_access_token(
                    cls.access_token,
                    cls.refresh_token,
                    cls.token_expiration_time,
                    logger,
                )
            )
            cls.token_expiration_time = datetime.now() + timedelta(hours=1)
        return cls.access_token

    @classmethod
    def verificar_token(cls):
        # Renova o token se estiver perto de expirar
        if datetime.now() >= (cls.token_expiration_time - cls.expiration_buffer):
            if cls.refresh_token:
                try:
                    cls.access_token, cls.refresh_token, cls.token_expiration_time = (
                        refresh_jwt_token(cls.refresh_token, logger)
                    )
                    cls.token_expiration_time = datetime.now() + timedelta(hours=1)
                    logger.info("Token renovado com sucesso.")
                except Exception as e:
                    logger.error(f"Erro ao renovar o token: {e}")
            else:
                cls.access_token, cls.refresh_token, cls.token_expiration_time = (
                    get_jwt_token(logger)
                )
        return cls.access_token

    @classmethod
    def get_asset_by_name(cls, asset_name):
        print(f"Buscando asset: {asset_name}")
        cls.verificar_token()  # Verifica e renova o token antes de buscar o asset
        return get_asset_by_name(
            asset_name=asset_name,
            access_token=cls.access_token,
            refresh_token=cls.refresh_token,
            logger=logger,
        )


class RoboDesencriptador:
    def obter_credenciais(self, asset):
        desencriptador = Desencriptador()
        return desencriptador.obter_credenciais(asset)


class Signals:
    @staticmethod
    def signal_handler(signum, frame):
        from uteis.browsers_bot import manipulate_browsers

        # Função para lidar com sinais SIGTERM e SIGINT
        status_message = "Sinal recebido, finalizando o robô de forma controlada."
        print(status_message)
        try:
            if "bot" in locals():
                status_message = manipulate_browsers.close_browser(
                    Orchestrator.access_token
                )
                status_message = f"Status do processamento: {status_message}"
            status_message += f" | Finalizando automação {Constantes.NOME_AUTOMACAO}."
            log_status(
                Constantes.NOME_AUTOMACAO,
                "terminated",
                status_message,
                "final",
                nivel="warning",
            )
        except Exception as e:
            print(f"Erro ao finalizar o robô após sinal: {str(e)}")
        sys.exit(0)

    @staticmethod
    def setup_signal_handlers():
        """Função para registrar os sinais SIGTERM e SIGINT"""
        signal.signal(signal.SIGTERM, Signals.signal_handler)
        signal.signal(signal.SIGINT, Signals.signal_handler)


def log_status(bot_name, status_exec, status_message, local, level, access_token):
    logger.gravar_status(
        bot_name,
        status_exec,
        status_message,
        local,
        nivel=level,
        access_token=access_token,
        environment=Constantes.ENVIRONMENT
    )
