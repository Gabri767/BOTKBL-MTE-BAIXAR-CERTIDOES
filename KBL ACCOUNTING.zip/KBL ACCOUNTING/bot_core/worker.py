# bot_core/worker.py
import os
import requests
import time
import pytz
import threading
import subprocess
import signal

from .utils import Utils, FileHandler
from .orchestrator import (
    get_jwt_token,
    refresh_jwt_token,
    get_scheduled_tasks,
    update_task_status,
)
from datetime import datetime, timedelta

worker_directory = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


class Worker:
    def __init__(self, name, ip, orchestrator_url):
        from .log_manager import Logger, logging
        from .config_loader import ConfigLoader

        self.name = name
        self.ip = ip
        self.orchestrator_url = f"{orchestrator_url}api/workers/status/"
        self.token_expiration_time = None
        self.running = True
        self.paused = False
        self.stop_robot_execution = (
            False  # Variável de controle para parar a execução do robô
        )
        self.vinculated_robots = FileHandler.get_vinculated_robots(worker_directory)
        self.running_robots = {}
        self.app = None
        self.config_loader = ConfigLoader()
        self.logger = Logger.for_agent(self.config_loader)
        self.logging = logging
        self.access_token, self.refresh_token, self.token_expiration_time = (
            get_jwt_token(self.logger)
        )

    def set_app(self, app):
        """Define a instância do App."""
        self.app = app

    def atualizar_status(self, status):
        """Atualiza o status do worker no Orchestrator."""
        try:
            self.verificar_token()  # Verifique o token antes de usar
            system_details = Utils.coletar_informacoes_do_sistema()
            data = {
                "name": self.name,
                "ip": self.ip,
                "status": status,
                "system_details": system_details,
            }
            headers = {"Authorization": f"Bearer {self.access_token}"}
            response = requests.post(self.orchestrator_url, json=data, headers=headers)
            self._handle_response(response)

        except requests.exceptions.RequestException as e:
            self.logger.log(
                f"Erro ao atualizar status do worker: {e}", level=self.logging.ERROR
            )

    def _handle_response(self, response):
        """Trata a resposta da atualização de status."""
        if response.status_code in (200, 201):
            self.logger.log(
                "Status do worker atualizado com sucesso.", level=self.logging.INFO
            )
        elif response.status_code == 500:
            self.logger.log(
                "Falha de comunicação com o banco de dados.", level=self.logging.ERROR
            )
        elif response.status_code == 404:
            self.logger.log(
                "Não existem tarefas para o worker.", level=self.logging.INFO
            )
        else:
            self.logger.log(
                f"Erro inesperado: {response.text}", level=self.logging.WARNING
            )

    def verificar_token(self):
        """Verifica e renova o token JWT, se necessário."""
        time_to_expire = self.token_expiration_time - time.time()
        if time_to_expire <= 900:  # Se o token expira em 15 minutos ou menos
            if self.refresh_token:
                try:
                    (
                        self.access_token,
                        self.refresh_token,
                        self.token_expiration_time,
                    ) = refresh_jwt_token(self.refresh_token, self.logger)
                    self.logger.log(
                        "Token renovado com sucesso.", level=self.logging.INFO
                    )
                except Exception as e:
                    self.logger.log(
                        f"Erro ao renovar o token: {e}", level=self.logging.ERROR
                    )
            else:
                self.access_token, self.refresh_token, self.token_expiration_time = (
                    get_jwt_token(self.logger)
                )
        return self.access_token

    def stop(self):
        """Para o worker."""
        if self.running:
            self.running = False
            self.logger.log("Worker parado.", level=self.logging.INFO)
        else:
            self.logger.log("O worker já está parado.", level=self.logging.INFO)

    def pausar(self):
        """Pausa o worker."""
        self.paused = True
        self.logger.log("Worker pausado.", level=self.logging.INFO)

    def retomar(self):
        """Retoma a execução do worker."""
        self.paused = False
        self.logger.log("Worker retomado.", level=self.logging.INFO)

    def parar_execucao_robo(self):
        """Define a flag para parar a execução do robô."""
        self.stop_robot_execution = True
        self.logger.log(
            "Sinal para parar a execução do robô enviado.", level=self.logging.INFO
        )

    def start_monitoring(self, intervalo=60):
        """Inicia o monitoramento em uma nova thread."""
        self.running = True
        monitoring_thread = threading.Thread(
            target=self.monitorar_worker, args=(intervalo,)
        )
        monitoring_thread.start()

    def monitorar_worker(self, intervalo=60):
        """Monitora o worker em loop, atualizando o status e processando tarefas."""
        try:
            while self.running:
                if self.paused:
                    time.sleep(5)
                    continue
                self.verificar_token()
                self.atualizar_status("online")
                self.processar_tarefas()
                time.sleep(intervalo)

        except Exception as e:
            self.logger.log(str(e), level=self.logging.ERROR)

    def processar_tarefas(self):
        """Busca e processa as tarefas agendadas."""
        try:
            print("Processar Tarefa")
            self.verificar_token()
            scheduled_tasks = get_scheduled_tasks(
                self.name, self.access_token, self.refresh_token, self.logger
            )
            self.app.update_scheduled_tasks(scheduled_tasks)
            self.logger.log(
                f"Processar tarefas: {scheduled_tasks}", level=self.logging.INFO
            )
            if scheduled_tasks:
                for task in scheduled_tasks:
                    self.verificar_e_executar_tarefa(task)
            else:
                self.logger.log(
                    "Não há tarefas agendadas para este worker.",
                    level=self.logging.INFO,
                )
        except requests.exceptions.HTTPError as http_err:
            if http_err.response.status_code == 404:
                self.logger.log(
                    f"Nenhuma tarefa associada ao worker {self.name}.",
                    level=self.logging.INFO,
                )
            else:
                self.logger.log(
                    f"Erro ao buscar tarefas: {http_err}", level=self.logging.ERROR
                )
    
    def verificar_e_executar_tarefa(self, task):
        now = datetime.now(pytz.timezone("America/Sao_Paulo"))
        self.logger.log(f"Verificando tarefa {task['id']} - Hora atual: {now}", level=self.logging.DEBUG)

        try:
            next_execution_time = datetime.fromisoformat(
                task["next_execution_time"]
            ).astimezone(pytz.timezone("America/Sao_Paulo"))
            self.logger.log(f"Próxima execução da tarefa {task['id']}: {next_execution_time}", level=self.logging.DEBUG)
        except ValueError as e:
            self.logger.log(
                f"Erro ao converter next_execution_time para datetime para tarefa {task['id']}: {e}",
                level=self.logging.ERROR,
            )
            return

        self.logger.log(f"Tarefa {task['id']} is_active: {task['is_active']}", level=self.logging.DEBUG)
        self.logger.log(f"Comparação de tempo para tarefa {task['id']}: {now >= next_execution_time}", level=self.logging.DEBUG)

        if task["is_active"] and now >= next_execution_time:
            last_execution_time = task["last_execution_time"]
            if last_execution_time:
                last_execution_time = datetime.fromisoformat(last_execution_time).astimezone(pytz.timezone("America/Sao_Paulo"))
                self.logger.log(f"Última execução da tarefa {task['id']}: {last_execution_time}", level=self.logging.DEBUG)

            if last_execution_time is None or (now - last_execution_time) > timedelta(minutes=5):
                self.logger.log(f"Tarefa {task['id']} encontrada e será executada: {task}", level=self.logging.INFO)
                self.executar_tarefa(task)
            else:
                self.logger.log(
                    f'Tarefa {task["id"]} já foi executada recentemente.',
                    level=self.logging.INFO,
                )
        else:
            self.logger.log(
                f'Tarefa {task["id"]} não está ativa ou não é o momento para execução.',
                level=self.logging.INFO,
            )



    '''
    def verificar_e_executar_tarefa(self, task):
        now = datetime.now(pytz.timezone("America/Sao_Paulo"))
        self.logger.log(f"Hora atual: {now}", level=self.logging.DEBUG)

        try:
            next_execution_time = datetime.fromisoformat(
                task["next_execution_time"]
            ).astimezone(pytz.timezone("America/Sao_Paulo"))
            self.logger.log(f"Próxima execução: {next_execution_time}", level=self.logging.DEBUG)
        except ValueError as e:
            self.logger.log(
                f"Erro ao converter next_execution_time para datetime: {e}",
                level=self.logging.ERROR,
            )
            return

        # Adiciona uma margem de 1 minuto para a comparação
        if task["is_active"] and now >= (next_execution_time - timedelta(minutes=1)):
            last_execution_time = task["last_execution_time"]
            if last_execution_time:
                last_execution_time = datetime.fromisoformat(last_execution_time).astimezone(pytz.timezone("America/Sao_Paulo"))
                self.logger.log(f"Última execução: {last_execution_time}", level=self.logging.DEBUG)

            if last_execution_time is None or (now - last_execution_time) > timedelta(minutes=5):
                self.logger.log(f"Tarefa encontrada e será executada: {task}", level=self.logging.INFO)
                self.executar_tarefa(task)
            else:
                self.logger.log(
                    f'Tarefa {task["id"]} já foi executada recentemente.',
                    level=self.logging.INFO,
                )
        else:
            self.logger.log(
                f'Tarefa {task["id"]} não está ativa ou não é o momento para execução.',
                level=self.logging.INFO,
            )
    '''
    def executar_tarefa(self, task):
        """Executa a tarefa associada a um robô."""
        robot = task.get("robot", {})
        robot_name = robot.get("name", None)  # None se 'name' não existir

        if robot_name in self.vinculated_robots:
            self.logger.log(
                f"Executando o robô: {robot_name} para a tarefa: {task['id']}",
                level=self.logging.INFO,
            )
            resultado = self.chamar_robo(robot_name)

            state_result = "COMPLETED" if resultado else "FAILED"
            self.logger.log(
                f"Worker - Executar Tarefa: O Robô {robot_name} foi concluído com resultado: {state_result}. Chamando update_task_status."
            )

            update_task_status(
                task["id"],
                state_result,
                self.access_token,
                self.refresh_token,
                self.logger,
            )
        else:
            self.logger.log(
                f"Worker - Executar Tarefa: O robô {robot_name} não está vinculado a este worker.",
                level=self.logging.WARNING,
            )
            update_task_status(
                task["id"], "FAILED", self.access_token, self.refresh_token, self.logger
            )

    def chamar_robo(self, robot_name):
        """Chama o robô associado à tarefa baseado no nome da pasta."""
        robot_path = os.path.join(worker_directory, robot_name)
        if os.path.exists(robot_path):
            self.logger.log(
                f"Iniciando o robô: {robot_name} no caminho {robot_path}",
                level=self.logging.INFO,
            )
            try:
                if self.stop_robot_execution:
                    self.logger.log(
                        f"Execução do robô {robot_name} interrompida antes de iniciar.",
                        level=self.logging.INFO,
                    )
                    return False
                path_robo = os.path.join(robot_path, "bot.py")
                self.logger.log(
                    f"Worker - Chamar Robô - Path do Robo: {path_robo}",
                    level=self.logging.INFO,
                )
                # Use Popen para ter controle sobre o processo e obter o PID
                process = subprocess.Popen(["python", path_robo])

                # Armazena o PID do processo em execução
                self.running_robots[robot_name] = process.pid

                self.logger.log(
                    f"Robô {robot_name} iniciado com PID {process.pid}",
                    level=self.logging.INFO,
                )

                # Espera o processo terminar
                process.wait()

                if self.stop_robot_execution:
                    self.logger.log(
                        f"Execução do robô {robot_name} interrompida.",
                        level=self.logging.INFO,
                    )
                    return False

                return True
            except subprocess.CalledProcessError as e:
                self.logger.log(
                    f"Erro ao executar o robô {robot_name}: {e}",
                    level=self.logging.ERROR,
                )
                return False
        else:
            self.logger.log(
                f"O caminho para o robô {robot_name} não foi encontrado.",
                level=self.logging.ERROR,
            )
            return False

    def parar_robo(self, robot_name):
        """Para o robô em execução."""
        if robot_name in self.running_robots:
            pid = self.running_robots[robot_name]
            try:
                os.kill(pid, signal.SIGTERM)
                self.logger.log(
                    f"O robô {robot_name} com PID {pid} foi interrompido.",
                    level=self.logging.INFO,
                )
            except OSError as e:
                self.logger.log(
                    f"Erro ao parar o robô {robot_name}: {e}", level=self.logging.ERROR
                )
        else:
            self.logger.log(
                f"O robô {robot_name} não está em execução.", level=self.logging.WARNING
            )

'''
    def verificar_e_executar_tarefa(self, task):
        """Verifica se a tarefa está ativa e no horário para execução."""
        now = datetime.now(pytz.timezone("America/Sao_Paulo"))

        try:
            next_execution_time = datetime.fromisoformat(
                task["next_execution_time"]
            ).astimezone(pytz.timezone("America/Sao_Paulo"))
        except ValueError as e:
            self.logger.log(
                f"Erro ao converter next_execution_time para datetime: {e}",
                level=self.logging.ERROR,
            )
            return

        if task["is_active"] and now >= next_execution_time:
            last_execution_time = task["last_execution_time"]
            if last_execution_time is None or (now - last_execution_time) > timedelta(
                minutes=5
            ):
                self.logger.log(f"Tarefa encontrada: {task}", level=self.logging.INFO)
                self.executar_tarefa(task)
            else:
                self.logger.log(
                    f'Tarefa {task["id"]} já foi executada recentemente.',
                    level=self.logging.INFO,
                )
        else:
            self.logger.log(
                f'Tarefa {task["id"]} não está ativa ou não é o momento para execução.',
                level=self.logging.INFO,
            )
'''