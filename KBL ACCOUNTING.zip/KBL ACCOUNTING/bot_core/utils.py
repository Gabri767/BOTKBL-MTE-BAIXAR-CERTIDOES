# C:\Desenvolvimento\KBL-RPA\PYTHON\KBL ACCOUNTING\bot_core\utils.py
import os
import re
import psutil
import platform
import csv
import json
import shutil
import openpyxl
import pandas as pd
import numpy as np
import warnings
import zipfile
import win32com.client as win32
from pathlib import Path
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
from dotenv import load_dotenv

# Carregar o arquivo .env
dotenv_path = "C:\\Desenvolvimento\\KBL-RPA\\PYTHON\\env\\.env"
load_dotenv(dotenv_path)


###################################################################################################################################################
class FileHandler:
    """Classe para manipulação de arquivos."""

    @staticmethod
    def verificar_criar_pasta(path):
        """Verifica se o caminho existe e cria a pasta, se necessário."""
        if not os.path.exists(path):
            os.makedirs(path)

    @staticmethod
    def create_file_if_not_exists(file_path):
        file_path = Path(file_path)
        """Cria um arquivo vazio se ele não existir."""
        if not os.path.isfile(file_path):
            open(file_path, "w").close()

    @staticmethod
    def gravar_em_csv_write(dados, nome_arquivo):
        """Grava um dicionário em um arquivo CSV via metodo write."""
        try:
            if len(dados) > 0:
                with open(
                    nome_arquivo, mode="w", newline="", encoding="utf-8"
                ) as arquivo_csv:
                    # Pega as chaves do primeiro dicionário como cabeçalho
                    writer = csv.DictWriter(
                        arquivo_csv, fieldnames=dados[0].keys(), delimiter=";"
                    )
                    writer.writeheader()

                    # Grava cada dicionário na lista como uma linha no CSV
                    for dado in dados:
                        writer.writerow(dado)
            else:
                print("Nenhum dado disponível para gravar no CSV.")
        except Exception as e:
            print(f"Erro ao gravar no CSV: {e}")

    def gravar_em_csv_append(dados, nome_arquivo):
        """Grava uma lista de dicionários em um arquivo CSV, via metodo append."""
        try:
            if len(dados) > 0:
                with open(
                    nome_arquivo, mode="a", newline="", encoding="utf-8"
                ) as arquivo_csv:
                    # Verifica se o arquivo está vazio para escrever o cabeçalho
                    arquivo_vazio = arquivo_csv.tell() == 0
                    writer = csv.DictWriter(
                        arquivo_csv, fieldnames=dados[0].keys(), delimiter=";"
                    )

                    # Escreve o cabeçalho somente se o arquivo estiver vazio
                    if arquivo_vazio:
                        writer.writeheader()

                    # Grava cada dicionário na lista como uma linha no CSV
                    for dado in dados:
                        writer.writerow(dado)
            else:
                print("Nenhum dado disponível para gravar no CSV.")
        except Exception as e:
            print(f"Erro ao gravar no CSV: {e}")

    @staticmethod
    def ler_de_csv(nome_arquivo):
        """Lê dados de um arquivo CSV e retorna uma lista de dicionários."""
        try:
            with open(nome_arquivo, mode="r", encoding="utf-8") as arquivo_csv:
                reader = csv.DictReader(arquivo_csv)
                return [linha for linha in reader]
        except FileNotFoundError:
            print(f"O arquivo {nome_arquivo} não foi encontrado.")
        except Exception as e:
            print(f"Erro ao ler o CSV: {e}")

    @staticmethod
    def gravar_em_json(dados, nome_arquivo):
        """Grava dados em um arquivo JSON."""
        try:
            with open(nome_arquivo, mode="w", encoding="utf-8") as arquivo_json:
                json.dump(dados, arquivo_json, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f"Erro ao gravar o JSON: {e}")

    @staticmethod
    def ler_de_json(nome_arquivo):
        """Lê dados de um arquivo JSON e retorna o conteúdo."""
        try:
            with open(nome_arquivo, mode="r", encoding="utf-8") as arquivo_json:
                return json.load(arquivo_json)
        except FileNotFoundError:
            print(f"O arquivo {nome_arquivo} não foi encontrado.")
        except json.JSONDecodeError:
            print(f"Erro ao decodificar o JSON.")
        except Exception as e:
            print(f"Erro ao ler o JSON: {e}")

    @staticmethod
    def verificar_existencia_arquivo(nome_arquivo):
        """Verifica se um arquivo existe."""
        return os.path.isfile(nome_arquivo)

    @staticmethod
    def deletar_arquivo(nome_arquivo):
        """Deleta um arquivo se ele existir."""
        try:
            os.remove(nome_arquivo)
            print(f"Arquivo {nome_arquivo} deletado.")
        except FileNotFoundError:
            print(f"Arquivo {nome_arquivo} não existe.")
        except Exception as e:
            print(f"Erro ao deletar o arquivo: {e}")

    @staticmethod
    def mover_e_renomear_arquivo(origem, destino, novo_nome):
        try:
            # Garantir que a extensão esteja no novo_nome
            nome_base, extensao = os.path.splitext(origem)
            if not os.path.splitext(novo_nome)[1]:  # Se não tiver extensão
                novo_nome = f"{novo_nome}{extensao}"

            if not os.path.exists(destino):
                os.makedirs(destino)

            caminho_destino = os.path.join(destino, novo_nome)
            shutil.copy2(origem, caminho_destino)  # Usar copy2 preserva metadados
            os.remove(origem)  # Remove o original após cópia bem-sucedida

            return f"Arquivo movido e renomeado para {caminho_destino}"
        except FileNotFoundError:
            return "Arquivo de origem não encontrado"
        except PermissionError:
            return "Erro de permissão ao mover arquivo"
        except OSError as e:
            return f"Erro ao mover arquivo: {e}"

    @staticmethod
    def mover_arquivos(origem, destino):
        """Move arquivos ou diretórios de uma origem para um destino, preservando arquivos com o mesmo nome."""
        try:
            origem_path = Path(origem)
            destino_path = Path(destino)

            if not destino_path.exists():
                destino_path.mkdir(parents=True, exist_ok=True)

            def criar_nome_unico(caminho_arquivo):
                """Cria um nome único para o arquivo caso já exista no destino."""
                arquivo_original = caminho_arquivo.stem
                extensao = caminho_arquivo.suffix
                contador = 1
                novo_arquivo = caminho_arquivo

                while novo_arquivo.exists():
                    novo_nome = f"{arquivo_original}_{contador}{extensao}"
                    novo_arquivo = novo_arquivo.parent / novo_nome
                    contador += 1

                return novo_arquivo

            if origem_path.is_file():
                destino_arquivo = destino_path / origem_path.name

                # Verifica se já existe um arquivo com esse nome no destino
                if destino_arquivo.exists():
                    destino_arquivo = criar_nome_unico(destino_arquivo)

                shutil.move(str(origem_path), str(destino_arquivo))
                print(f"Arquivo {origem_path.name} movido para {destino_arquivo}.")

            elif origem_path.is_dir():
                for item in origem_path.iterdir():
                    destino_item = destino_path / item.name

                    if item.is_file():
                        if destino_item.exists():
                            destino_item = criar_nome_unico(destino_item)
                        shutil.move(str(item), str(destino_item))
                    else:  # é um diretório
                        if destino_item.exists():
                            destino_item = criar_nome_unico(destino_item)
                        shutil.move(str(item), str(destino_item))

                print(
                    f"Conteúdo do diretório {origem_path} movido para {destino_path}."
                )
            else:
                print(
                    f"O caminho de origem {origem_path} não é um arquivo nem um diretório válido."
                )

        except Exception as e:
            print(f"Erro ao mover: {e}")

    @staticmethod
    def mover_diretorio_pai(caminho_arquivo, destino):
        """
        Move o diretório pai de um arquivo para um novo destino.

        Args:
            caminho_arquivo (str): Caminho completo para o arquivo
            destino (str): Diretório de destino onde o diretório pai será movido

        Returns:
            str: Mensagem indicando o resultado da operação
        """
        try:
            # Obtém o diretório pai do arquivo
            arquivo_path = Path(caminho_arquivo)
            diretorio_pai = arquivo_path.parent

            # Cria o diretório de destino se não existir
            destino_path = Path(destino)
            if not destino_path.exists():
                destino_path.mkdir(parents=True, exist_ok=True)

            # Determina o caminho de destino final (destino + nome do diretório pai)
            destino_final = destino_path / diretorio_pai.name

            # Verifica se já existe um diretório com esse nome no destino
            if destino_final.exists():
                # Cria um nome único adicionando um contador
                contador = 1
                while destino_final.exists():
                    novo_nome = f"{diretorio_pai.name}_{contador}"
                    destino_final = destino_path / novo_nome
                    contador += 1

            # Move o diretório pai inteiro para o destino
            shutil.move(str(diretorio_pai), str(destino_final))

            return f"Diretório pai '{diretorio_pai}' movido para '{destino_final}'"

        except FileNotFoundError:
            return f"Arquivo ou diretório pai não encontrado: {caminho_arquivo}"
        except PermissionError:
            return "Erro de permissão ao mover o diretório"
        except OSError as e:
            return f"Erro ao mover o diretório pai: {e}"

    @staticmethod
    def obter_dados_planilha(file_name):
        """
        Obtém dados de uma planilha Excel, removendo linhas vazias e realizando limpeza básica.
        Também verifica se já existem registros duplicados na planilha "Notas Processadas" e os remove.

        Args:
            file_name (str): Caminho do arquivo Excel

        Returns:
            pandas.DataFrame: DataFrame limpo sem linhas vazias e sem registros duplicados

        Raises:
            FileNotFoundError: Se o arquivo não existir
            ValueError: Se o arquivo estiver vazio ou se todas as linhas forem vazias após limpeza
        """
        if not Path(file_name).exists():
            raise FileNotFoundError(f"O arquivo {file_name} não foi encontrado.")

        # Usar openpyxl para leitura mais confiável
        wb = openpyxl.load_workbook(file_name, data_only=True)
        if "Plan1" in wb.sheetnames or "Planilha1" in wb.sheetnames:
            if "Plan1" in wb.sheetnames:
                sheet = wb["Plan1"]
            else:
                sheet = wb["Planilha1"]
        else:
            raise ValueError("O arquivo não contém a planilha esperada.")

        # Converter para DataFrame
        data = sheet.values
        cols = next(data)
        data = list(data)
        df = pd.DataFrame(data, columns=cols)

        # Verifica se há dados antes da limpeza
        if df.empty:
            raise ValueError(f"O arquivo {file_name} está vazio.")

        # Verifica se existe a planilha "Notas Processadas" para comparação
        sheet_names = wb.sheetnames

        if "Notas Processadas" in sheet_names:
            # Lê a planilha "Notas Processadas"
            sheet_processadas = wb["Notas Processadas"]
            data_processadas = sheet_processadas.values
            cols_processadas = next(data_processadas)
            data_processadas = list(data_processadas)
            df_processadas = pd.DataFrame(data_processadas, columns=cols_processadas)

            if not df_processadas.empty:
                # Define as colunas para comparação (índices 0-based)
                colunas_comparacao = [3, 4, 6, 8, 9, 10, 12, 14]

                # Filtra linhas duplicadas (mantém apenas as que não existem nas processadas)
                linhas_para_manter = []
                registros_duplicados = 0

                # Realiza a comparação linha por linha
                for idx, row_novo in df.iterrows():
                    duplicado = False

                    # Compara com cada linha em df_processadas
                    for _, row_proc in df_processadas.iterrows():
                        match = True

                        # Compara cada coluna relevante
                        for col_idx in colunas_comparacao:
                            # Verifica se o índice está dentro dos limites
                            if col_idx < len(df.columns) and col_idx < len(
                                df_processadas.columns
                            ):
                                val_novo = row_novo.iloc[col_idx] if idx > 0 else None
                                val_proc = row_proc.iloc[col_idx]

                                # Compara os valores, tratando None e NaN
                                if pd.isna(val_novo) and pd.isna(val_proc):
                                    continue
                                elif pd.isna(val_novo) or pd.isna(val_proc):
                                    match = False
                                    break
                                elif str(val_novo).strip() != str(val_proc).strip():
                                    match = False
                                    break

                        if match:
                            duplicado = True
                            registros_duplicados += 1
                            break

                    if not duplicado:
                        linhas_para_manter.append(idx)

                # Filtra o DataFrame para manter apenas as linhas não duplicadas
                if linhas_para_manter:
                    df = df.iloc[linhas_para_manter]
                    print(f"Removidos {registros_duplicados} registros duplicados.")
                else:
                    df = pd.DataFrame(columns=df.columns)
                    print("Todos os registros são duplicados.")

        # Limpeza adicional de dados
        # Remove linhas onde todas as colunas são NaN, None ou strings vazias
        df = df.dropna(how="all")

        # Converte todas as células vazias para string vazia em vez de NaN
        df = df.fillna("")

        # Verifica se ainda há dados após a limpeza
        if df.empty:
            raise ValueError(
                f"Não há dados válidos no arquivo {file_name} após limpeza."
            )

        return df

    @staticmethod
    def obter_dados_excel(file_name):
        """Obtém dados de uma planilha Excel."""
        if not Path(file_name).exists():
            raise FileNotFoundError(f"O arquivo {file_name} não foi encontrado.")

        df = pd.read_excel(file_name, dtype=str)
        if df.empty:
            raise ValueError(f"O arquivo {file_name} está vazio.")

        # Corrigido o uso de inplace para evitar futuros avisos
        df["0 Referencia"] = df["0 Referencia"].replace("", np.nan)

        return df

    @staticmethod
    def apagar_arquivos_e_pastas(diretorio):
        status_func = ""
        # Remover todo o conteúdo do diretório
        for root, dirs, files in os.walk(diretorio):
            for file in files:
                os.remove(os.path.join(root, file))
            for dir in dirs:
                shutil.rmtree(os.path.join(root, dir))
        status_func = f"Pastas e arquivos do diretório {diretorio} removidos."
        print(status_func)

        return status_func

    @staticmethod
    def listar_arquivos(diretorio, constantes):

        diretorio_path = Path(diretorio)
        if not diretorio_path.exists():
            raise FileNotFoundError(f"O diretório {diretorio_path} não existe.")

        arquivos = []

        if str(constantes.PATH_ARQUIVO_ENTR) in str(diretorio_path):
            arquivos = list(
                diretorio_path.rglob("*.xls*")
            )  #### Adequar para obter quaquer tipo de arquivo como pdf, doc*, xlx* e outros e fazer o tratamento na execução
        else:
            arquivos = list(diretorio_path.rglob("*.txt"))

        if len(arquivos) == 0:
            raise FileNotFoundError(
                f"Não existem arquivos para processar no diretório: {diretorio_path}."
            )
        arquivos = [arq for arq in arquivos if arq.is_file()]

        return arquivos

    @staticmethod
    def fazer_download_docs(bot, extensao_arq, query_js):
        try:
            bot.execute_javascript(query_js)
            path_download = Path(bot.download_folder_path)
            filepath = bot.wait_for_new_file(
                path=path_download, file_extension=extensao_arq, timeout=60000
            )
            if filepath is None:
                raise FileNotFoundError("Arquivo não encontrado")
            status_portal = f"New created file => {filepath}"
            return (status_portal, filepath)

        except FileNotFoundError:
            print("Arquivo não encontrado.")
        except TimeoutError:
            print("Tempo de expera excedido.")
        except Exception as e:
            print(f"Ocorreu um erro não experado: {e}")

    @staticmethod
    def convert_xls_to_xlsx(xls_file, xlsx_file):
        print("convert_xls_to_xlsx")
        try:
            FileHandler.close_excel()
            warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")
            print("converter excel")

            excel = win32.gencache.EnsureDispatch("Excel.Application")
            print("abrir xls")
            wb = excel.Workbooks.Open(xls_file)
            wb.SaveAs(
                str(xlsx_file), FileFormat=51
            )  # FileFormat=51 is for .xlsx extension
            wb.Close()
            excel.Application.Quit()
            # apagar_arquivos_e_pastas(xls_file)
        except Exception as e:
            print(e)
            raise

    @staticmethod
    def close_excel():
        print("close excel")
        # Itera por todos os processos atualmente em execução
        for process in psutil.process_iter(attrs=["pid", "name"]):
            # Verifica se o nome do processo é "EXCEL.EXE"
            if process.info["name"] == "EXCEL.EXE":
                # Termina o processo
                process.kill()
                print(
                    f'Excel process with PID {process.info["pid"]} has been terminated.'
                )

    @staticmethod
    def alterar_build(caminho_projeto, nome_projeto):
        # Caminho do projeto
        arquivo_botproj = "BOTBKL_TEMPLATE_BOT.botproj"
        file_path_botproj = os.path.join(caminho_projeto, arquivo_botproj)
        novo_nome_botproj = os.path.join(caminho_projeto, f"{nome_projeto}.botproj")

        # Verifica se o arquivo .botproj ainda tem o nome do template
        if os.path.exists(file_path_botproj):
            # Ler o conteúdo do arquivo .botproj
            with open(file_path_botproj, "r") as file:
                conteudo = file.read()

            # Parse o conteúdo JSON
            dados = json.loads(conteudo)

            # Alterar o valor do campo "name"
            dados["name"] = nome_projeto

            # Escrever o conteúdo editado de volta no arquivo .botproj
            with open(file_path_botproj, "w") as file:
                json.dump(dados, file, indent=4)

            # Renomear o arquivo .botproj para o nome do projeto
            os.rename(file_path_botproj, novo_nome_botproj)
            print(f"Arquivo .botproj renomeado e atualizado para {novo_nome_botproj}")

            # Prosseguir com a alteração dos outros arquivos
            arquivos_build_restantes = ["build.ps1", "build.sh"]

            for arquivo in arquivos_build_restantes:
                file_path = os.path.join(caminho_projeto, arquivo)

                # Verifica se o arquivo existe antes de tentar modificá-lo
                if os.path.exists(file_path):
                    # Para arquivos .ps1 e .sh, fazer a substituição
                    with open(file_path, "r") as file:
                        conteudo = file.read()

                    conteudo_editado = conteudo.replace(
                        "BOTBKL_TEMPLATE_BOT.zip", f"{nome_projeto}.zip"
                    )

                    # Escrever o conteúdo editado de volta no arquivo
                    with open(file_path, "w") as file:
                        file.write(conteudo_editado)

                    print(
                        f"Arquivo {arquivo} atualizado com sucesso para o projeto {nome_projeto}"
                    )
                else:
                    print(
                        f"Arquivo {arquivo} não encontrado no diretório {caminho_projeto}"
                    )

        else:
            print(f"O arquivo .botproj já foi renomeado ou não existe.")

    @staticmethod
    def verificar_existencia_arquivo(nome_arquivo):
        """Verifica se o arquivo existe."""
        return os.path.exists(nome_arquivo)

    @staticmethod
    def deletar_arquivo(nome_arquivo):
        """Deleta o arquivo."""
        if FileHandler.verificar_existencia_arquivo(nome_arquivo):
            os.remove(nome_arquivo)

    @staticmethod
    def get_vinculated_robots(worker_directory):
        """Obtém os nomes dos robôs a partir dos diretórios existentes no diretório do worker."""
        try:
            # Filtra e retorna apenas os nomes dos diretórios
            robos = [
                name
                for name in os.listdir(worker_directory)
                if os.path.isdir(os.path.join(worker_directory, name))
            ]
            return robos
        except Exception as e:
            Exception(f"Erro ao obter robôs vinculados: {e}")
            return []

    @staticmethod
    def listar_arquivos_extensao(
        diretorio,
        extensao=[
            "*.xls*",
            "*.doc*",
            "*.pdf",
            "*.txt",
            "*.xml",
            "*.crdownload",
            "*.png",
            "*.jpg",
        ],
    ):
        # Se `extensao` for uma string, transforme em uma lista
        if isinstance(extensao, str):
            extensao = [extensao]

        diretorio_path = Path(diretorio)
        if not diretorio_path.exists():
            raise FileNotFoundError(f"O diretório {diretorio_path} não existe.")

        # Formata as extensões corretamente
        extensao = [ext if ext.startswith("*") else f"*.{ext}" for ext in extensao]

        arquivos = []
        # Primeiro tenta no diretório raiz
        for ext in extensao:
            arquivos.extend([arq for arq in diretorio_path.glob(ext) if arq.is_file()])

        # Se não encontrou nada no diretório raiz, busca no primeiro nível de subdiretórios
        if not arquivos:
            for ext in extensao:
                arquivos.extend(
                    [arq for arq in diretorio_path.glob(f"*/{ext}") if arq.is_file()]
                )

        """
        if not arquivos:
            raise FileNotFoundError(
                f"Não existem arquivos para processar no diretório: {diretorio_path}."
            )
        """
        return arquivos

    @staticmethod
    def is_file_modified_today(file_path):
        file = Path(file_path)
        if not file.exists():
            raise FileNotFoundError(f"O arquivo {file_path} não existe.")

        # Tenta obter a data de criação do arquivo
        try:
            data_modificacao = datetime.fromtimestamp(file.stat().st_birthtime)
        except AttributeError:
            # Caso st_birthtime não esteja disponível, usa st_mtime
            data_modificacao = datetime.fromtimestamp(file.stat().st_mtime)

        # Obtém a data atual
        data_atual = datetime.now()

        # Verifica se a data de modificação é igual à data de hoje
        return data_modificacao.date() == data_atual.date()

    @staticmethod
    def copiar_arquivo(origem, destino, criar_pasta=True):
        """
        Copia um arquivo de uma origem para um destino.

        Parâmetros:
        origem (str): Caminho do arquivo de origem
        destino (str): Caminho onde o arquivo será copiado
        criar_pasta (bool): Se True, cria a pasta de destino se não existir

        Retorna:
        bool: True se a cópia foi bem sucedida, False caso contrário
        """
        try:
            # Verifica se o arquivo de origem existe
            if not os.path.exists(origem):
                print(f"Erro: Arquivo de origem '{origem}' não encontrado.")
                return False

            # Obtém o diretório do caminho de destino
            pasta_destino = os.path.dirname(destino)

            # Cria a pasta de destino se não existir e criar_pasta=True
            if criar_pasta and pasta_destino and not os.path.exists(pasta_destino):
                os.makedirs(pasta_destino)

            # Copia o arquivo
            shutil.copy2(origem, destino)
            print(f"Arquivo copiado com sucesso: '{origem}' -> '{destino}'")
            return True

        except Exception as e:
            print(f"Erro ao copiar arquivo: {str(e)}")
            return False

    @staticmethod
    def obter_extensao(arquivo):
        # Retorna a extensão do arquivo
        _, extensao = os.path.splitext(arquivo)
        return extensao

    @staticmethod
    def extrair_arquivo_zip(caminho_zip, diretorio_destino=None):
        """
        Extrai o conteúdo de um arquivo ZIP para um diretório específico.

        Args:
            caminho_zip: Caminho completo para o arquivo ZIP
            diretorio_destino: Diretório onde os arquivos serão extraídos.
                            Se None, extrai no diretório atual.

        Returns:
            list: Lista de arquivos extraídos
        """
        # Se o diretório de destino não for fornecido, usa o mesmo diretório do arquivo ZIP
        if diretorio_destino is None:
            diretorio_destino = os.path.dirname(caminho_zip)

        # Garante que o diretório de destino exista
        os.makedirs(diretorio_destino, exist_ok=True)

        arquivos_extraidos = []

        try:
            with zipfile.ZipFile(caminho_zip, "r") as zip_ref:
                # Lista todos os arquivos no ZIP
                lista_arquivos = zip_ref.namelist()

                # Extrai todos os arquivos
                zip_ref.extractall(diretorio_destino)

                # Constrói o caminho completo para cada arquivo extraído
                for arquivo in lista_arquivos:
                    caminho_completo = os.path.join(diretorio_destino, arquivo)
                    arquivos_extraidos.append(caminho_completo)

                print(f"Arquivo ZIP extraído com sucesso em: {diretorio_destino}")
                return arquivos_extraidos

        except zipfile.BadZipFile:
            print(f"Erro: O arquivo {caminho_zip} não é um arquivo ZIP válido.")
            return []
        except Exception as e:
            print(f"Erro ao extrair o arquivo ZIP: {str(e)}")
            return []


###################################################################################################################################################
class Utils:
    """Classe utilitária com métodos estáticos para operações comuns."""

    @staticmethod
    def calculo_datas(dia_base):
        """Calcula datas com base em um dia base."""
        status_func = ""
        data_atual = datetime.now()

        if data_atual.day < dia_base:
            status_func = f"Dia atual menor que {dia_base}."
            mes_competencia = data_atual
        else:
            status_func = f"Dia atual maior ou igual a {dia_base}."
            mes_competencia = data_atual.replace(day=28) + timedelta(days=4)
            mes_competencia = mes_competencia.replace(day=1)

        return data_atual, status_func, mes_competencia

    @staticmethod
    def tempo_decorrido(tempo_inicial):
        """Calcula o tempo decorrido desde um tempo inicial."""
        end_time = datetime.now()
        tempo_decorrido = end_time - tempo_inicial
        segundos_totais = tempo_decorrido.total_seconds()
        horas = int(segundos_totais // 3600)
        minutos = int((segundos_totais % 3600) // 60)
        segundos = int(segundos_totais % 60)
        tempo_formatado = "{:02d}:{:02d}:{:02d}".format(horas, minutos, segundos)
        end_time_str = end_time.strftime("%d/%b/%Y %H:%M:%S.%f")[:-3]
        return segundos_totais, tempo_formatado, end_time_str

    @staticmethod
    def funcao_regex(pattern, string):
        """Aplica uma expressão regular a uma string."""
        retorno_regex = re.search(pattern, string, re.DOTALL)
        print(retorno_regex)
        return retorno_regex

    @staticmethod
    def maestro_alert(maestro, execution, AlertType):
        """Envia um alerta para o maestro."""
        maestro.alert(
            task_id=execution.task_id,
            title="Info Alert",
            message="This is an info alert",
            alert_type=AlertType.INFO,
        )

    @staticmethod
    def find_and_kill_process_by_name(process_name):
        """Encontra e encerra um processo pelo nome."""
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                if proc.info["name"] == process_name:
                    pid = proc.info["pid"]
                    os.kill(pid, 9)
                    print(f"Processo {process_name} (PID: {pid}) foi encerrado.")
                    return True
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass
        print(f"Nenhum processo com o nome '{process_name}' foi encontrado.")
        return False

    @staticmethod
    def coletar_informacoes_do_sistema():
        """Coleta informações do sistema operacional."""
        return {
            "sistema_operacional": platform.system(),
            "versao_python": platform.python_version(),
            "uso_cpu": psutil.cpu_percent(interval=1),
            "uso_memoria": psutil.virtual_memory().percent,
            "espaco_disco": psutil.disk_usage("/").percent,
        }

    @staticmethod
    def get_encryption_key():
        """Carrega a chave de encriptação do arquivo .env."""
        return os.getenv("ENCRYPTION_KEY")

    @staticmethod
    def convert_df_to_queue_items(df, queue_id):
        """
        Converte um DataFrame em uma lista de dicionários no formato esperado para inserção na fila.

        Parâmetros:
        df (pd.DataFrame): O DataFrame contendo os dados a serem convertidos.
        queue_id (int): O ID da fila para a qual os itens serão adicionados.

        Retorna:
        list: Lista de dicionários no formato esperado para a API.
        """
        items = []

        # Substituir valores NaN por None antes da conversão para JSON
        df = df.replace({np.nan: None})

        for _, row in df.iterrows():
            item = {
                "queue": queue_id,
                "reference": row.get(
                    "Referencia", ""
                ),  # Ajuste o nome da coluna aqui, se necessário
                "data": row.to_dict(),  # Converte a linha do DataFrame em um dicionário
            }
            items.append(item)

        return items


###################################################################################################################################################
class Desencriptador:
    """Classe para desencriptar dados usando a chave de encriptação."""

    @staticmethod
    def desencriptar(dados):
        """Desencripta dados usando a chave fornecida."""
        key = Fernet(Utils.get_encryption_key())
        return key.decrypt(dados).decode()

    def obter_credenciais(self, asset):
        """
        Desencripta as credenciais do asset.

        :param asset: Dicionário contendo 'encrypted_username' e 'encrypted_password'.
        :return: Dicionário com 'username' e 'password' desencriptados.
        """
        encrypted_username = asset["encrypted_username"]
        encrypted_password = asset["encrypted_password"]

        username = self.desencriptar(encrypted_username)
        password = self.desencriptar(encrypted_password)

        return {"username": username, "password": password}

    ###################################################################################################################################################

    '''
     def obter_dados_planilha(file_name):
        """
        Obtém dados de uma planilha Excel, removendo linhas vazias e realizando limpeza básica.

        Args:
            file_name (str): Caminho do arquivo Excel

        Returns:
            pandas.DataFrame: DataFrame limpo sem linhas vazias

        Raises:
            FileNotFoundError: Se o arquivo não existir
            ValueError: Se o arquivo estiver vazio ou se todas as linhas forem vazias após limpeza
        """
        if not Path(file_name).exists():
            raise FileNotFoundError(f"O arquivo {file_name} não foi encontrado.")

        # Lê o arquivo Excel
        # df = pd.read_excel(file_name, dtype=str)
        """
        df = pd.read_excel(
            file_name,
            dtype=str,
            na_filter=False,  # Não converte valores "NA" em None
            keep_default_na=False,  # Não usa a lista padrão de valores NA
        )
        """

        # df = pd.read_excel(file_name, engine="openpyxl", data_only=True)

        wb = openpyxl.load_workbook(file_name, data_only=True)
        sheet = wb.active

        # Converter para DataFrame depois
        data = sheet.values
        cols = next(data)
        data = list(data)
        df = pd.DataFrame(data, columns=cols)

        # Verifica se há dados antes da limpeza
        if df.empty:
            raise ValueError(f"O arquivo {file_name} está vazio.")

        # Remove linhas onde todas as colunas são vazias ou contêm apenas espaços
        df = df.replace(
            r"^\s*$", pd.NA, regex=True
        )  # Converte espaços em branco para NA
        df = df.dropna(how="all")  # Remove linhas onde todas as colunas são NA

        # Remove espaços em branco no início e fim de todas as células
        df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)

        # Verifica se ainda existem dados após a limpeza
        if df.empty:
            raise ValueError(
                f"O arquivo {file_name} contém apenas linhas vazias após limpeza."
            )

        # Reset do índice após remoção das linhas
        df = df.reset_index(drop=True)

        return df
    '''
