# kbl-rpa-core
Biblioteca principal com componentes reutilizáveis para RPA
