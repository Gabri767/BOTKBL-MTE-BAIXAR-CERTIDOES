"""
Gerenciador de contexto para logging centralizado
"""

from typing import Optional
from bot_core.log_manager import Logger
from contextlib import contextmanager


class LogContext:
    _instance = None
    _logger: Optional[Logger] = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def set_logger(cls, logger: Logger):
        cls._logger = logger

    @classmethod
    def get_logger(cls) -> Logger:
        if cls._logger is None:
            raise RuntimeError("Logger não foi inicializado")
        return cls._logger

    @classmethod
    def initialize(cls, config_loader):
        """Inicializa o logger com as configurações padrão"""
        if cls._logger is None:
            cls._logger = Logger.for_robot(config_loader)
        return cls._logger
