"""
Contextos operacionais para o bot
"""

from contextlib import contextmanager
import logging
from bot_core.contexts.log_context import LogContext


@contextmanager
def bot_operation_context(
    operation_name: str,
    bot_name: str,
    access_token: str = None,
    environment: str = "DEV",
):
    """
    Contexto para operações do bot com logging automático

    Args:
        operation_name: Nome da operação
        bot_name: Nome do bot
        access_token: Token de acesso para o orchestrator
        environment: Ambiente de execução
    """
    logger = LogContext.get_logger()
    context = {
        "operation": operation_name,
        "bot_name": bot_name,
        "environment": environment,
    }

    try:
        logger.log_with_context(f"Iniciando {operation_name}", context)
        yield
        logger.gravar_status(
            bot_name,
            "success",
            f"Operação {operation_name} concluída com sucesso",
            operation_name,
            nivel=logging.INFO,
            access_token=access_token,
            environment=environment,
        )
    except Exception as e:
        logger.gravar_status(
            bot_name,
            "failure",
            f"Erro em {operation_name}: {str(e)}",
            operation_name,
            nivel=logging.ERROR,
            access_token=access_token,
            environment=environment,
        )
        raise


@contextmanager
def browser_operation_context(
    browser,
    operation_name: str,
    bot_name: str,
    access_token: str = None,
    environment: str = "DEV",
):
    """
    Contexto específico para operações do navegador

    Args:
        browser: Instância do navegador
        operation_name: Nome da operação
        bot_name: Nome do bot
        access_token: Token de acesso para o orchestrator
        environment: Ambiente de execução
    """
    logger = LogContext.get_logger()
    context = {
        "operation": operation_name,
        "bot_name": bot_name,
        "environment": environment,
    }

    try:
        logger.log_with_context(
            f"Iniciando operação do navegador: {operation_name}", context
        )
        yield browser
        logger.gravar_status(
            bot_name,
            "success",
            f"Operação do navegador {operation_name} concluída com sucesso",
            operation_name,
            nivel=logging.INFO,
            access_token=access_token,
            environment=environment,
        )
    except Exception as e:
        logger.gravar_status(
            bot_name,
            "failure",
            f"Erro na operação do navegador {operation_name}: {str(e)}",
            operation_name,
            nivel=logging.ERROR,
            access_token=access_token,
            environment=environment,
        )
        try:
            browser.refresh()  # Tenta recuperar o navegador
        except:
            pass  # Ignora erros na tentativa de recuperação
        raise
