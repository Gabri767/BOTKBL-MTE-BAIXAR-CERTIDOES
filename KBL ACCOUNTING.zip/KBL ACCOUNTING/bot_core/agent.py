# bot_core\agent.py
import os
import sys
import tkinter as tk
from .gui import AgentGUI
from .app import App  # Certifique-se de que o caminho para App está correto
from .log_manager import Logger, logging  # Importa a classe Logger
from .config_loader import ConfigLoader

# Redireciona stdout e stderr para um arquivo de log
log_file = open("agent_log.txt", "a")
sys.stdout = log_file
sys.stderr = log_file


def main():

    try:
        # Cria a janela principal do Tkinter
        root = tk.Tk()

        # Cria uma instância do ConfigLoader (você deve ter isso configurado)
        config_loader = (
            ConfigLoader()
        )  # Substitua isso pela instância correta do ConfigLoader

        # Cria a instância do Logger para o agente
        logger = Logger.for_agent(config_loader)
        logger.log("Iniciando o agente...", level=logging.INFO)  # Log de inicialização

        agent_app = App()  # Cria a instância do App
        app = AgentGUI(root, agent_app)  # Passa a instância do agente para a GUI

        # Inicia o loop principal da interface gráfica
        root.mainloop()

        logger.log(
            "Agente finalizado com sucesso.", level=logging.INFO
        )  # Log de finalização

    except Exception as e:
        # Em caso de erro, o programa exibe uma mensagem e sai
        logger.log(f"Erro ao iniciar o agente: {e}", level=logging.ERROR)  # Log do erro

        sys.exit(1)


if __name__ == "__main__":
    if __name__ == "__main__":
        try:
            # Desativa a janela do console
            if sys.platform.startswith("win"):
                import win32gui
                import win32con

                hwnd = win32gui.GetForegroundWindow()
                win32gui.ShowWindow(hwnd, win32con.SW_HIDE)

            main()
        finally:
            log_file.close()
