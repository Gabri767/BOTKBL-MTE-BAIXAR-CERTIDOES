# C:\Desenvolvimento\KBL-RPA\PYTHON\KBL ACCOUNTING\bot_core\orchestrator.py
####Códigos responsáveis por realizar a comunicação entre agentes e robôs com o orchestrador via os endpoints da API
import json
import requests
import time
from .config_loader import ConfigLoader
from typing import Any, Dict

# Carrega o ConfigLoader
config_loader = ConfigLoader()
BASE_URL = config_loader.get_orchestrator_url()
API_USERNAME, API_PASSWORD = config_loader.get_api_credentials()


# Autenticação (JWT)
def get_jwt_token(logger):
    url = f"{BASE_URL}api/token/"
    try:
        response = requests.post(
            url, data={"username": API_USERNAME, "password": API_PASSWORD}
        )
        response.raise_for_status()
        tokens = response.json()
        expiration = time.time() + 3600  # Define 1 hora como tempo de expiração
        logger.logger.info("Token JWT obtido com sucesso.")
        return tokens["access"], tokens["refresh"], expiration
    except requests.exceptions.RequestException as e:
        logger.logger.error(f"Erro ao obter o token JWT: {str(e)}")
        raise


def refresh_jwt_token(refresh_token, logger):
    url = f"{BASE_URL}api/token/refresh/"
    try:
        response = requests.post(url, data={"refresh": refresh_token})
        response.raise_for_status()
        tokens = response.json()
        expiration = time.time() + 3600
        logger.logger.info("Token JWT atualizado com sucesso.")
        return tokens["access"], tokens["refresh"], expiration
    except requests.exceptions.RequestException as e:
        logger.logger.error(f"Erro ao atualizar token JWT: {str(e)}")
        raise


def get_valid_access_token(access_token, refresh_token, expiration, logger):
    """Verifica a validade do token e o renova automaticamente se necessário."""
    if time.time() >= expiration:
        logger.logger.info("Token JWT expirado. Tentando renovar.")
        access_token, refresh_token, expiration = refresh_jwt_token(
            refresh_token, logger
        )
    else:
        logger.logger.info("Token JWT ainda válido.")
    return access_token, refresh_token, expiration


def make_authenticated_request(
    url, access_token, refresh_token, logger, method="GET", data=None
):
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    try:
        response = _execute_request(method, url, headers, data)

        if response.status_code == 401:  # Token expirado
            logger.logger.info("Token expirado. Tentando renovar o token.")
            access_token, refresh_token, expiration = get_valid_access_token(
                refresh_token, logger
            )
            headers["Authorization"] = f"Bearer {access_token}"
            response = _execute_request(method, url, headers, data)

        response.raise_for_status()
        return response.json()

    except requests.exceptions.RequestException as e:
        logger.logger.error(f"Erro em requisição autenticada: {str(e)}")
        raise


def _execute_request(method, url, headers, data):
    """Executa uma requisição HTTP com base no método especificado."""
    if method == "GET":
        return requests.get(url, headers=headers)
    elif method == "POST":
        return requests.post(url, headers=headers, json=data)
    elif method == "PATCH":
        return requests.patch(url, headers=headers, json=data)
    elif method == "PUT":
        return requests.patch(url, headers=headers, json=data)
    elif method == "DELETE":
        return requests.delete(url, headers=headers)
    else:
        raise ValueError(f"Método HTTP não suportado: {method}")


def get_tasks(agent_id, access_token, refresh_token, logger):
    try:
        url = f"{BASE_URL}api/agent/tasks/{agent_id}/"
        access_token, refresh_token = make_authenticated_request(
            url, access_token, refresh_token, logger
        )
        return make_authenticated_request(url, access_token, refresh_token, logger)
    except Exception as e:
        logger.logger.error(
            f"Get Tasks: Erro ao buscar tarefas para o Agente: {agent_id}, motivo: {e}."
        )


def execute_task(task, access_token, refresh_token, logger):
    try:
        logger.logger.info(
            f"Executando tarefa: {task['task_id']} - {task['task_name']}"
        )
        # Aqui você implementa a lógica para executar a tarefa
        update_task_status(
            task["task_id"], "COMPLETED", access_token, refresh_token, logger
        )
    except Exception as e:
        logger.logger.error(f"Erro ao executar tarefa {task['task_id']}: {str(e)}")
        update_task_status(
            task["task_id"], "FAILED", access_token, refresh_token, logger
        )


def update_task_status(task_id, status, access_token, refresh_token, logger):
    try:
        url = f"{BASE_URL}api/tasks/status/update/"
        data = {"task_id": task_id, "status": status}
        logger.logger.info(type(task_id))
        logger.logger.info(
            f" Atualizando o status da tarefa: {task_id} com status {status}. Dados enviados {data}"
        )
        status = make_authenticated_request(
            url,
            access_token,
            refresh_token,
            logger,
            method="POST",
            data=json.dumps(data),
        )
        logger.logger.info(status)
    except Exception as e:
        logger.logger.error(
            f"Erro ao atualizar o status da tarefa: {task_id} com status {status} pelo motivo {e}."
        )


def check_pending_tasks(agent_id, access_token, refresh_token, logger):
    url = f"{BASE_URL}api/agent/tasks/{agent_id}/"
    return make_authenticated_request(url, access_token, refresh_token, logger=logger)


def get_scheduled_tasks(agent_name, access_token, refresh_token, logger):
    url = f"{BASE_URL}api/agent/scheduled-tasks/{agent_name}/"
    return make_authenticated_request(url, access_token, refresh_token, logger)


### Manipulação de Filas (Queues)
def get_queue(access_token, refresh_token, logger):
    url = f"{BASE_URL}api/queue/"
    return make_authenticated_request(url, access_token, refresh_token, logger=logger)


def get_queue_by_id(queue_id, access_token, refresh_token, logger):
    url = f"{BASE_URL}api/queues/{queue_id}/"
    return make_authenticated_request(url, access_token, refresh_token, logger=logger)


def get_queue_items(queue_id, access_token, refresh_token, logger, status=None):
    base_url = f"{BASE_URL}api/queues/{queue_id}/items/"

    # Adiciona o filtro de status se fornecido
    if status:
        base_url += f"?status={status}"

    try:
        items = make_authenticated_request(
            base_url, access_token, refresh_token, logger=logger
        )

        logger.logger.info(
            f"Retrieved {len(items)} queue items for queue {queue_id}"
            + (f" with status '{status}'" if status else "")
        )
        return items
    except Exception as e:
        logger.logger.error(f"Failed to retrieve queue items: {str(e)}")
        return None


def add_queue_item(
    queue_id: int, data: dict, access_token: str, refresh_token: str, logger: Any
) -> dict:
    try:
        url = f"{BASE_URL}api/queue-items/"

        # Estrutura o payload conforme esperado pelo QueueItemSerializer
        payload = {
            "queue": queue_id,
            "reference": data.get("reference", ""),  # Campo opcional
            "data": data,  # Dados extras
            "status": data.get("status", "new"),  # Status padrão se não fornecido
        }

        logger.logger.debug(f"Enviando payload para a API: {payload}")

        response = make_authenticated_request(
            url,
            access_token,
            refresh_token,
            logger=logger,
            method="POST",
            data=payload,  # Não precisa do json.dumps() aqui
        )

        logger.logger.info(f"Item adicionado com sucesso à fila {queue_id}")
        return response

    except Exception as e:
        logger.logger.error(f"Falha ao enviar item para a fila: {str(e)}")
        raise


def get_queue_item(queue_item_id, access_token, refresh_token, logger, status=None):
    url = f"{BASE_URL}api/queue-items/{queue_item_id}/"
    response = make_authenticated_request(
        url, access_token, refresh_token, logger=logger
    )
    if response.status_code == 200:
        item = response.json()
        logger.logger.info(
            f"Retrieved item {item['id']}."
            + (f" with status '{status}'" if status else "")
        )
        return item
    else:
        logger.logger.error(
            f"Failed to retrieve queue item. Status code: {response.status_code}"
        )
        return None


def update_queue_item_status(
    queue_id, queue_item_id, new_status, access_token, refresh_token, logger
):
    url = f"{BASE_URL}api/queue-items/{queue_item_id}/"
    data = {"queue": queue_id, "status": new_status}
    try:
        response = make_authenticated_request(
            url,
            access_token,
            refresh_token,
            logger=logger,
            method="PATCH",
            data=data,
        )
        return response
    except Exception as e:
        logger.logger.error(f"Failed to retrieve queue item. Status code: {str(e)}")
        return None


def delete_queue_item(queue_item_id, access_token, refresh_token, logger):
    url = f"{BASE_URL}api/queue-items/{queue_item_id}/"
    return make_authenticated_request(
        url, access_token, refresh_token, logger=logger, method="DELETE"
    )


def retry_queue_item(queue_item_id, access_token):
    item = get_queue_item(queue_item_id, access_token)
    if item and item["status"] == "failed":
        update_queue_item_status(queue_item_id, "pending", access_token)
        data = item
        data["retries"] += 1
        return add_queue_item(data["queue"], data, access_token)
    else:
        return {"error": "Item não pode ser reprocessado."}


def get_queue_item_statuses(queue_id, access_token):
    items = get_queue_items(queue_id, access_token)
    statuses = {item["id"]: item["status"] for item in items}
    return statuses


def add_multiple_to_queue(dataframe, access_token, refresh_token, logger):
    data_list = dataframe.to_dict(orient="records")
    url = f"{BASE_URL}api/queue-items/bulk/"
    return make_authenticated_request(
        url,
        access_token,
        refresh_token,
        logger=logger,
        method="POST",
        data=json.dumps(data_list),
    )


def add_queue_items_bulk(queue_id, items, access_token):
    url = f"{BASE_URL}api/queue-items/bulk/"
    data = {"queue_id": queue_id, "items": items}  # Lista de dicionários
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }
    response = requests.post(url, headers=headers, data=json.dumps(data))
    return response.json()  # Retorna a resposta em JSON


### Manipulação de Assets
def get_assets(access_token, refresh_token, logger):
    url = f"{BASE_URL}api/assets/"
    return make_authenticated_request(url, access_token, refresh_token, logger=logger)


def get_asset_by_name(asset_name, access_token, refresh_token, logger):
    url = f"{BASE_URL}api/assets/{asset_name}/"
    return make_authenticated_request(url, access_token, refresh_token, logger=logger)


def get_asset_value(name, access_token, refresh_token, logger):

    asset = get_asset_by_name(name, access_token, refresh_token, logger=logger)
    if not isinstance(asset, dict):
        logger.logger.error(f"Erro: o asset '{name}' não é um dicionário válido.")
        return None

    asset_type = asset.get("asset_type")
    if asset_type is None:
        logger.logger.error(f"Erro: o asset '{name}' não contém a chave 'asset_type'.")
        return None

    if asset_type in ["text", "boolean", "integer", "float"]:
        return asset.get("value")
    elif asset_type == "credential":
        return {"username": asset.get("username"), "password": asset.get("password")}
    else:
        logger.logger.error(f"Tipo de asset desconhecido: {asset_type}")
        return None


### Logs de Execução
def gravar_log_orquestrador(
    bot_name, status_exec, nivel, local, mensagem, access_token, refresh_token, logger
):
    url = f"{BASE_URL}api/execution-logs/"
    data = {
        "robot_name": bot_name,
        "execution_status": status_exec,
        "log_message": mensagem,
        "level": nivel.upper(),
        "log_location": local,
    }
    make_authenticated_request(
        url,
        access_token,
        refresh_token,
        logger=logger,
        method="POST",
        data=json.dumps(data),
    )


def get_robot_name(self, robot_id):
    response = requests.get(
        f"{self.api_url}/robots/{robot_id}/"
    )  # Ajuste o endpoint conforme necessário
    if response.status_code == 200:
        return response.json().get(
            "name"
        )  # Supondo que o nome do robô está na chave 'name'
    else:
        raise Exception("Failed to fetch robot name from orchestrator API.")
