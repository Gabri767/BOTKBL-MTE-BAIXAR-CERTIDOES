"""
Decoradores para tratamento de erros e operações do bot
"""

from functools import wraps
import logging
import traceback
from time import sleep
from bot_core.exceptions import *
from bot_core.contexts.log_context import LogContext


def handle_bot_operation(max_retries=3, retry_delay=1000):
    """
    Decorator para manipulação de operações do bot com retry e logging

    Args:
        max_retries (int): Número máximo de tentativas
        retry_delay (int): Delay entre tentativas em milissegundos
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            logger = LogContext.get_logger()
            attempt = 0
            last_exception = None

            context = {"operation": func.__name__, "max_retries": max_retries}

            while attempt < max_retries:
                try:
                    logger.log_with_context(f"Executando {func.__name__}", context)
                    result = func(*args, **kwargs)
                    logger.log_with_context(
                        f"{func.__name__} executado com sucesso", context
                    )
                    return result

                except BotException as e:
                    last_exception = e
                    error_context = {
                        **context,
                        "attempt": attempt + 1,
                        "error_type": e.__class__.__name__,
                    }
                    logger.log_with_context(
                        f"Erro em {func.__name__}: {str(e)}",
                        error_context,
                        logging.ERROR,
                    )

                except Exception as e:
                    last_exception = e
                    error_context = {
                        **context,
                        "attempt": attempt + 1,
                        "error_type": "UnexpectedError",
                    }
                    logger.log_with_context(
                        f"Erro não esperado em {func.__name__}: {str(e)}",
                        error_context,
                        logging.ERROR,
                    )
                    logger.log_with_context(
                        f"Stacktrace: {traceback.format_exc()}",
                        error_context,
                        logging.DEBUG,
                    )

                attempt += 1
                if attempt < max_retries:
                    sleep(retry_delay / 1000)
                    logger.log_with_context(
                        f"Tentando novamente {func.__name__}",
                        {**context, "attempt": attempt + 1},
                    )

            raise last_exception

        return wrapper

    return decorator


def ensure_element_present(timeout=10000, ensure_visible=True, ensure_clickable=True):
    """
    Decorator para garantir que um elemento está presente antes de executar uma operação

    Args:
        timeout (int): Tempo máximo de espera em milissegundos
        ensure_visible (bool): Garantir que o elemento está visível
        ensure_clickable (bool): Garantir que o elemento está clicável
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            logger = LogContext.get_logger()
            element_selector = kwargs.get("selector", None)
            by = kwargs.get("by", None)

            if not element_selector or not by:
                raise ValueError("selector e by são obrigatórios")

            context = {
                "operation": func.__name__,
                "selector": element_selector,
                "timeout": timeout,
            }

            try:
                bot = args[0] if args else kwargs.get("bot")
                if not bot:
                    raise ValueError("bot é obrigatório")

                logger.log_with_context(
                    f"Procurando elemento: {element_selector}", context
                )

                element = bot.find_element(
                    element_selector,
                    by,
                    ensure_visible=ensure_visible,
                    ensure_clickable=ensure_clickable,
                    waiting_time=timeout,
                )

                if not element:
                    raise ElementNotFoundException(
                        f"Elemento não encontrado: {element_selector}"
                    )

                logger.log_with_context(
                    f"Elemento encontrado: {element_selector}", context
                )

                return func(*args, **kwargs)

            except Exception as e:
                logger.log_with_context(
                    f"Erro ao procurar elemento: {str(e)}", context, logging.ERROR
                )
                if isinstance(e, ElementNotFoundException):
                    raise
                raise ElementNotFoundException(
                    f"Erro ao verificar elemento: {element_selector}", str(e)
                )

        return wrapper

    return decorator


def log_operation(operation_name: str = None):
    """
    Decorator para logging de operações simples

    Args:
        operation_name (str): Nome da operação (opcional, usa o nome da função se não fornecido)
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            logger = LogContext.get_logger()
            op_name = operation_name or func.__name__

            context = {"operation": op_name, "function": func.__name__}

            try:
                logger.log_with_context(f"Iniciando {op_name}", context)
                result = func(*args, **kwargs)
                logger.log_with_context(f"Concluído {op_name}", context)
                return result
            except Exception as e:
                logger.log_with_context(
                    f"Erro em {op_name}: {str(e)}", context, logging.ERROR
                )
                raise

        return wrapper

    return decorator
