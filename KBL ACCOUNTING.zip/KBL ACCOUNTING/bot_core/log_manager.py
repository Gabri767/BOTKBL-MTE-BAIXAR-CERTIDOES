import logging
from pathlib import Path
import json
import time
import os
import requests


class Logger:
    """
    Classe responsável por gerenciar o logging da aplicação.
    """

    def __init__(self, config_loader, log_file_path=None):
        """
        Inicializa o Logger.

        :param config_loader: Instância da classe ConfigLoader que fornece
                              informações de configuração.
        :param log_file_path: Caminho do arquivo de log (opcional).
        """
        self.config_loader = config_loader

        if log_file_path is None:
            log_file_path = self._get_log_file_path(config_loader.get_log_path())

        self.logger = logging.getLogger("RPA Logger")
        self.logger.setLevel(logging.DEBUG)

        if not self.logger.hasHandlers():
            self._setup_file_handler(log_file_path)
            self._setup_console_handler()

    def _setup_file_handler(self, log_file_path):
        """
        Configura o manipulador de arquivos para o logger.
        """
        os.makedirs(os.path.dirname(log_file_path), exist_ok=True)
        file_handler = logging.FileHandler(log_file_path)
        file_handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)

    def _setup_console_handler(self):
        """
        Configura o manipulador de console para o logger.
        """
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)

    def _get_log_file_path(self, base_path):
        """
        Gera o caminho do arquivo de log, incluindo o nome do worker.

        :param base_path: Caminho base para o arquivo de log.
        :return: Caminho completo do arquivo de log.
        """
        return f"{base_path}_{self.config_loader.get_worker_name()}.log"

    def log(self, message, level=logging.INFO):
        """
        Registra uma mensagem de log com o nível especificado.
        """
        full_message = f"[{self.config_loader.get_worker_name()}] {message}"
        if level == logging.DEBUG:
            self.logger.debug(full_message)
        elif level == logging.INFO:
            self.logger.info(full_message)
        elif level == logging.WARNING:
            self.logger.warning(full_message)
        elif level == logging.ERROR:
            self.logger.error(full_message)
        elif level == logging.CRITICAL:
            self.logger.critical(full_message)

    def map_logging_level(level):
        """
        Mapeia os níveis numéricos de logging para os níveis esperados pela API.
        """
        if level == logging.DEBUG:
            return "DEBUG"
        elif level == logging.INFO:
            return "INFO"
        elif level == logging.WARNING:
            return "WARNING"
        elif level == logging.ERROR:
            return "ERROR"
        elif level == logging.CRITICAL:
            return "CRITICAL"
        else:
            return "INFO"  # Valor padrão caso o nível não seja reconhecido

    def log_with_context(self, message: str, context: dict, level: int = logging.INFO):
        """
        Registra uma mensagem de log com informações de contexto.
        """
        context_str = " ".join(f"{key}: {value}" for key, value in context.items())
        full_message = f"{context_str} - {message}"
        self.log(full_message, level)

    def gravar_status(
        self,
        nome_automacao,
        status,
        mensagem,
        etapa,
        nivel=logging.INFO,
        access_token=None,
        environment="DEV",
    ):
        """
        Grava o status da automação no log e o envia ao Orchestrator.
        """
        # 1. Grava o log no arquivo local
        log_message = f"Automação: {nome_automacao}, Status: {status}, Mensagem: {mensagem}, Etapa: {etapa}"
        self.log(log_message, nivel)  # Isso grava no arquivo de log

        # 2. Envia o log ao Orchestrator se o token de acesso for fornecido
        if access_token:
            self.enviar_log_ao_orquestrador(
                nome_automacao,
                status,
                nivel,
                etapa,
                mensagem,
                access_token,
                environment,
            )

    def enviar_log_ao_orquestrador(
        self, bot_name, status_exec, nivel, local, mensagem, access_token, environment
    ):
        """
        Envia o log ao Orchestrator via requisição HTTP autenticada.
        """
        # Verifica e renova o token se necessário
        # access_token = self.verificar_token()

        url = f"{self.config_loader.get_orchestrator_url()}api/execution-logs/"
        level_str = Logger.map_logging_level(nivel)

        data = {
            "robot_name": bot_name,
            "execution_status": status_exec,
            "log_message": mensagem,
            "level": level_str,
            "log_location": local,
            "environment": environment,
        }
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }

        try:
            response = requests.post(url, headers=headers, json=data)
            if response.status_code == 201:
                self.logger.info(f"Log enviado ao Orchestrator: {response.json()}")
            else:
                self.logger.error(
                    f"Erro ao enviar log ao Orchestrator: {response.status_code} - {response.text}"
                )
        except Exception as e:
            self.logger.error(f"Erro ao conectar ao Orchestrator: {str(e)}")

    def cleanup_logs(self, log_directory, retention_days=30):
        """
        Remove logs antigos com base em um período de retenção.
        """
        for log_file in Path(log_directory).glob("*.log"):
            if Path(log_file).stat().st_mtime < time.time() - retention_days * 86400:
                try:
                    log_file.unlink()
                    self.logger.info(f"Log removido: {log_file.name}")
                except Exception as e:
                    self.logger.error(f"Erro ao remover log: {e}")

    @classmethod
    def for_robot(cls, config_loader):
        log_file_path = config_loader.log_robot
        return cls(config_loader, log_file_path)

    @classmethod
    def for_agent(cls, config_loader):
        log_file_path = config_loader.log_agent
        return cls(config_loader, log_file_path)
