# bot_core/gui.py
#'chama aqui 2: gui.py'
import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk
import threading
from .log_manager import Logger, logging  # Importa a classe Logger


class AgentController:
    def __init__(self, agent_app):
        self.agent_app = agent_app

    def start_agent(self):
        if not self.agent_app.is_running:
            threading.Thread(target=self.agent_app.run, daemon=True).start()
            self.agent_app.worker.retomar()

    def pause_agent(self):
        if self.agent_app.is_running:
            self.agent_app.worker.pausar()

    def stop_agent(self):
        if self.agent_app.is_running:
            self.agent_app.stop()

    def stop_robot(self, robot_name):
        """Chama o método para parar o robô."""
        self.agent_app.stop_robot(robot_name)


class AgentGUI:
    def __init__(self, master, agent_app):
        self.master = master
        self.master.title("Agente RPA")
        self.master.geometry("400x400")  # Ajuste a altura para acomodar mais elementos
        self.master.resizable(False, False)
        self.agent_app = agent_app
        self.controller = AgentController(agent_app)

        # Criação do Logger
        self.logger = Logger.for_agent(
            self.agent_app.config_loader
        )  # Supondo que a agent_app tenha config_loader
        self.logger.log(
            "Interface gráfica iniciada.", level=logging.INFO
        )  # Log de inicialização

        # Notebook para abas
        self.notebook = ttk.Notebook(master)
        self.notebook.pack(pady=10, expand=True, fill="both")

        # Aba de Controles
        self.control_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.control_frame, text="Controles")

        self.start_button = tk.Button(
            self.control_frame, text="Iniciar Agente", command=self.start_agent
        )
        self.start_button.pack(pady=10)

        self.pause_button = tk.Button(
            self.control_frame,
            text="Pausar Agente",
            command=self.pause_agent,
            state=tk.DISABLED,
        )
        self.pause_button.pack(pady=10)

        self.stop_button = tk.Button(
            self.control_frame,
            text="Parar Agente",
            command=self.stop_agent,
            state=tk.DISABLED,
        )
        self.stop_button.pack(pady=10)

        self.quit_button = tk.Button(
            self.control_frame, text="Fechar Agente", command=self.master.destroy
        )
        self.quit_button.pack(pady=10)

        self.status_label = tk.Label(
            self.control_frame, text="Status: Desconhecido", fg="red"
        )
        self.status_label.pack(pady=10)

        # Aba de Agendamentos
        self.schedules_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.schedules_frame, text="Agendamentos")

        self.schedules_listbox = tk.Listbox(
            self.schedules_frame, height=12, width=50, state=tk.DISABLED
        )
        self.schedules_listbox.pack(pady=10)

        # Aba de Logs
        self.logs_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.logs_frame, text="Logs")

        self.log_text = scrolledtext.ScrolledText(
            self.logs_frame, height=12, width=40, state=tk.DISABLED
        )
        self.log_text.pack(pady=10)

        # Aba de Robots
        self.robots_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.robots_frame, text="Robôs Disponíveis")

        self.robot_frame = tk.Frame(self.robots_frame)  # Frame para os robôs
        self.robot_frame.pack(pady=10)

        # Atualizações periódicas
        self.update_status()
        self.update_schedules()

        # Adiciona os robôs na interface
        self.robots_vinculated()

    def robots_vinculated(self):
        # Limpa o Frame atual
        for widget in self.robot_frame.winfo_children():
            widget.destroy()

        # Obtém os robôs vinculados ao worker e cria botões para cada um
        for robot in self.agent_app.get_robots():
            robot_row = tk.Frame(self.robot_frame)  # Cria um Frame para cada robô
            robot_row.pack(fill="x", pady=5)

            robot_label = tk.Label(robot_row, text=robot, width=30, anchor="w")
            robot_label.pack(side="left", padx=5)

            play_button = tk.Button(
                robot_row, text="Play", command=lambda r=robot: self.execute_robot(r)
            )
            play_button.pack(side="left", padx=5)

            stop_button = tk.Button(
                robot_row, text="Stop", command=lambda r=robot: self.stop_robot(r)
            )
            stop_button.pack(side="left", padx=5)

    def update_schedules(self):
        self.schedules_listbox.config(state=tk.NORMAL)  # Permite modificar a listbox
        self.schedules_listbox.delete(0, tk.END)  # Limpa a lista atual
        agendamentos = self.agent_app.get_agendamentos()
        for agendamento in agendamentos:
            self.schedules_listbox.insert(tk.END, agendamento)
        self.schedules_listbox.config(
            state=tk.DISABLED
        )  # Desabilita a listbox novamente

    def update_status(self):
        current_status = "online" if self.agent_app.is_running else "offline"
        self.update_status_label(
            f"Status: {current_status.capitalize()}",
            "green" if self.agent_app.is_running else "red",
        )
        self.master.after(10000, self.update_status)

    def update_status_label(self, status_text, color):
        self.status_label.config(text=status_text, fg=color)

    def log(self, message):
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.config(state=tk.DISABLED)
        self.log_text.see(tk.END)

    def start_agent(self):
        if not self.agent_app.is_running:
            self.controller.start_agent()
            self.update_status_label("Agente Iniciado", "green")
            self.log("Agente Iniciado.")
            self.logger.log("Agente Iniciado.", level=logging.INFO)  # Log de início
            self.pause_button.config(state=tk.NORMAL)
            self.stop_button.config(state=tk.NORMAL)
            self.quit_button.config(state=tk.DISABLED)
            self.start_button.config(state=tk.DISABLED)
            self.schedule_update()
            # Atualiza a lista de robôs vinculados
            self.robots_vinculated()
        else:
            messagebox.showinfo("Atenção", "O agente já está em execução.")

    def pause_agent(self):
        if self.agent_app.is_running:
            self.controller.pause_agent()
            self.update_status_label("Agente Pausado", "orange")
            self.log("Agente Pausado.")
            self.logger.log("Agente Pausado.", level=logging.INFO)  # Log de pausa
            self.start_button.config(state=tk.NORMAL)
            self.pause_button.config(state=tk.DISABLED)
        else:
            messagebox.showinfo("Atenção", "O agente não está em execução.")

    def stop_agent(self):
        if self.agent_app.is_running:
            threading.Thread(target=self._stop_agent, daemon=True).start()

    def _stop_agent(self):
        try:
            self.logger.log(
                "Solicitando parada do agente...", level=logging.INFO
            )  # Log de parada
            self.controller.stop_agent()
            self.update_status_label("Agente Parado", "red")
            self.log("Agente Parado.")
            self.logger.log("Agente Parado.", level=logging.INFO)  # Log de parada
            self.pause_button.config(state=tk.DISABLED)
            self.stop_button.config(state=tk.DISABLED)
            self.quit_button.config(state=tk.NORMAL)
            self.start_button.config(state=tk.NORMAL)
            messagebox.showinfo("Sucesso", "Agente parado com sucesso.")
        except Exception as e:
            self.logger.log(
                f"Erro ao parar o agente: {e}", level=logging.ERROR
            )  # Log de erro
            messagebox.showerror("Erro", f"Ocorreu um erro ao parar o agente: {e}")

    def schedule_update(self):
        """Método para atualizar agendamentos periodicamente."""
        self.update_schedules()
        self.master.after(10000, self.schedule_update)  # Atualiza a cada 10 segundos

    def stop_robot(self, robot_name):
        if robot_name:
            confirmation = messagebox.askyesno(
                "Confirmação", f"Tem certeza que deseja parar o robô {robot_name}?"
            )
            if confirmation:
                try:
                    self.controller.stop_robot(robot_name)
                    self.log(f"Robô {robot_name} parado.")
                    self.logger.log(
                        f"Robô {robot_name} parado.", level=logging.INFO
                    )  # Log de parada do robô
                except Exception as e:
                    self.logger.log(
                        f"Erro ao parar o robô {robot_name}: {e}", level=logging.ERROR
                    )  # Log de erro
                    messagebox.showerror("Erro", f"Erro ao parar o robô: {e}")
        else:
            messagebox.showinfo("Atenção", "Nenhum robô selecionado.")

    def execute_robot(self, robot_name):

        try:
            print(self.agent_app)
            self.agent_app.execute_robot(
                robot_name
            )  # Substitua pelo método real para executar o robô
            self.log(f"Executando robô: {robot_name}.")
            self.logger.log(
                f"Robô {robot_name} em execução.", level=logging.INFO
            )  # Log de execução do robô
        except Exception as e:
            self.logger.log(
                f"Erro ao executar o robô {robot_name}: {e}", level=logging.ERROR
            )  # Log de erro
            messagebox.showerror("Erro", f"Erro ao executar o robô: {e}")
