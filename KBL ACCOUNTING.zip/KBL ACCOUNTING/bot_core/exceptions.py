"""
Módulo de exceções customizadas para o bot
"""


class BotException(Exception):
    """Classe base para exceções do bot"""

    def __init__(self, message, details=None):
        self.message = message
        self.details = details
        super().__init__(f"{message} - Detalhes: {details}" if details else message)


class BrowserException(BotException):
    """Exceção para erros relacionados ao navegador"""

    pass


class LoginException(BotException):
    """Exceção para erros relacionados ao login"""

    pass


class NavigationException(BotException):
    """Exceção para erros relacionados à navegação"""

    pass


class FormException(BotException):
    """Exceção para erros relacionados a formulários"""

    pass


class ProcessingException(BotException):
    """Exceção para erros relacionados ao processamento de dados"""

    pass


class TimeoutException(BotException):
    """Exceção para erros relacionados a timeout"""

    pass


class ElementNotFoundException(BotException):
    """Exceção para elementos não encontrados"""

    pass
