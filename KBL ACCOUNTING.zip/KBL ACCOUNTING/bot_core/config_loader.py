# bot_core/config_loader.py
import os
import socket
from dotenv import load_dotenv
from datetime import datetime
from pathlib import Path


class ConfigLoader:
    """
    Classe responsável por carregar configurações dos agentes.
    """

    def __init__(self, dotenv_path=None):
        if dotenv_path is None:

            # Pega o diretório do arquivo atual
            current_dir = Path(__file__).parent
            # Navega até o arquivo .env
            dotenv_path = current_dir.parent.parent / "env" / ".env"

            # dotenv_path = Path("../../env/.env")
            # dotenv_path = Path("C:/Desenvolvimento/KBL-RPA/PYTHON/env/.env")
            # dotenv_path = Path("C:/KBL-APPSBOTS/env/.env")

        load_dotenv(dotenv_path)
        self.dotenv_path = dotenv_path
        self.encryption_key = os.getenv("ENCRYPTION_KEY")
        self.api_username = os.getenv("API_USERNAME")
        self.api_password = os.getenv("API_PASSWORD")
        self.url_orquestrador = os.getenv("ORQUESTRADOR_API_URL")
        self.email_password = os.getenv("EMAIL_PASSWORD")

        # Novas variáveis
        self.unidade_padrao = "COTABILIDADE-FISCAL"
        self.hora_inicio = datetime.now()

        self.path_so = rf"C:\Automacao"
        self.path_logs = os.path.join(self.path_so, "Logs")

        self.path_raiz = os.path.join(self.path_so, self.unidade_padrao.upper())
        self.log_agent = os.path.join(
            self.path_logs, f"Log_Agente_{self.hora_inicio.strftime('%d_%m_%Y')}.log"
        )
        self.log_robot = os.path.join(
            self.path_logs, f"Log_Robos_{self.hora_inicio.strftime('%d_%m_%Y')}.log"
        )

        # Variáveis de configuração do Worker
        self.worker_name = socket.gethostname()
        self.worker_ip = self.get_local_ip()

    def get_encryption_key(self):
        return self.encryption_key

    def get_api_credentials(self):
        return self.api_username, self.api_password

    def get_orchestrator_url(self):
        return self.url_orquestrador

    def get_path_raiz(self):
        return self.path_raiz

    def get_log_geral(self):
        return str(self.log_geral)

    def get_worker_name(self):
        return self.worker_name

    def get_worker_ip(self):
        return self.worker_ip

    def mail_password(self):
        return self.mail_password

    @staticmethod
    def get_local_ip():
        """
        Retorna o endereço IP local da máquina.
        """
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"
