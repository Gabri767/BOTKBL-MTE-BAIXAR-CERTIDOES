# bot_core/app.py
#'chama aqui 3 app.py'
from .config_loader import ConfigLoader
from .worker import Worker
from .log_manager import Logger, logging  # Importando o LogManager


class App:
    def __init__(self):
        self.config_loader = ConfigLoader()  # Carrega a configuração do arquivo .env
        self.orchestrator_url = self.config_loader.get_orchestrator_url()
        self.worker = Worker(
            name=self.config_loader.get_worker_name(),
            ip=self.config_loader.get_worker_ip(),
            orchestrator_url=self.orchestrator_url,
        )
        self.worker.set_app(self)  # Define a instância do App no Worker
        self.is_running = False  # Inicialização da variável
        self.scheduled_tasks = []  # Armazena os agendamentos

        self.logger = Logger.for_agent(self.config_loader)  # Instanciando o LogManager

    def run(self):
        """Inicia o monitoramento do worker."""
        if not self.is_running:
            self.is_running = True
            self.worker.start_monitoring(intervalo=60)  # Alterado para start_monitoring
            self.logger.log(
                "Agente iniciado", level="INFO"
            )  # Usando LogManager para log
        else:
            self.logger.log(
                "Agente já está em execução.", level="WARNING"
            )  # Usando LogManager

    def stop(self):
        """Para o worker."""
        if self.is_running:
            self.worker.stop()  # Chama o método stop do worker
            self.is_running = False
            self.logger.log("Agente parado", level="INFO")  # Usando LogManager
        else:
            self.logger.log(
                "Agente não está em execução.", level="WARNING"
            )  # Usando LogManager

    def get_robots(self):
        """Retorna os robôs vinculados ao worker."""
        return self.worker.vinculated_robots

    def get_agendamentos(self):
        """Retorna a lista de agendamentos em um formato legível."""
        return [
            f"Tarefa: {task['id']} - Próxima Execução: {task['next_execution_time']}"
            for task in self.scheduled_tasks
        ]

    def update_scheduled_tasks(self, tasks):
        """Atualiza a lista de agendamentos do worker."""
        self.scheduled_tasks = tasks

    def execute_robot(self, robot_name):
        """Inicia o robô com base no ID fornecido."""
        robot = self.get_robot_by_name(robot_name)
        if robot:
            robot.run()  # Chama o método para executar o robô
            self.logger.log(
                f"Robô {robot_name} executado.", level="INFO"
            )  # Usando LogManager
        else:
            self.logger.log(
                f"Robô {robot_name} não encontrado.", level="ERROR"
            )  # Usando LogManager

    def get_robot_by_name(self, robot_name):
        """Obtém o robô correspondente ao ID."""
        return self.worker.chamar_robo(
            robot_name
        )  # Exemplo: assumindo que Worker tem essa função

    def stop_robot(self, robot_name):
        """Para a execução do robô com o nome fornecido."""
        try:
            result = self.worker.parar_robo(robot_name)
            if result:
                self.logger.log(
                    f"Robô {robot_name} parado com sucesso.", level="INFO"
                )  # Usando LogManager
            else:
                self.logger.log(
                    f"Falha ao parar o robô {robot_name}.", level="ERROR"
                )  # Usando LogManager
        except Exception as e:
            self.logger.log(
                f"Erro ao tentar parar o robô {robot_name}: {e}", level="ERROR"
            )  # Usando LogManager
