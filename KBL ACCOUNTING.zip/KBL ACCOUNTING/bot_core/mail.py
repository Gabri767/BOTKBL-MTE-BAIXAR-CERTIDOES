import smtplib
import imaplib
import email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import decode_header
import os
import re
import uuid
from typing import List, Dict, Optional


class EmailHandler:
    def __init__(
        self,
        username: str,
        password: str,
        smtp_server: Optional[str] = None,
        smtp_port: Optional[int] = None,
        imap_server: Optional[str] = None,
        imap_port: Optional[int] = None,
    ):
        """
        Inicializa o EmailHandler com configurações flexíveis.

        Args:
            username: Nome de usuário para autenticação
            password: Senha para autenticação
            smtp_server: Servidor SMTP (opcional, necessário apenas para envio)
            smtp_port: Porta SMTP (opcional, necessário apenas para envio)
            imap_server: Servidor IMAP (opcional, necessário apenas para leitura)
            imap_port: Porta IMAP (opcional, necessário apenas para leitura)
        """
        self.username = username
        self.password = password
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.imap_server = imap_server
        self.imap_port = imap_port

    @staticmethod
    def is_valid_email(email_address: str) -> bool:
        """Valida formato do email."""
        return bool(re.match(r"[^@]+@[^@]+\.[^@]+", email_address))

    def send_email(
        self,
        to_email: str,
        subject: str,
        body: str,
        body_html: Optional[str] = None,
        attachments: Optional[List[str]] = None,
    ):
        """Envia um email."""
        if not self.smtp_server or not self.smtp_port:
            raise ValueError(
                "Configurações SMTP não fornecidas. Impossível enviar email."
            )

        if not self.is_valid_email(to_email):
            raise ValueError(f"Endereço de email inválido: {to_email}")

        msg = MIMEMultipart("alternative")
        msg["From"] = self.username
        msg["To"] = to_email
        msg["Subject"] = subject

        msg.attach(MIMEText(body, "plain"))
        if body_html:
            msg.attach(MIMEText(body_html, "html"))

        if attachments:
            for file_path in attachments:
                if os.path.isfile(file_path):
                    with open(file_path, "rb") as file:
                        part = email.mime.base.MIMEBase("application", "octet-stream")
                        part.set_payload(file.read())
                    email.encoders.encode_base64(part)
                    part.add_header(
                        "Content-Disposition",
                        f"attachment; filename={os.path.basename(file_path)}",
                    )
                    msg.attach(part)
                else:
                    raise FileNotFoundError(f"Anexo não encontrado: {file_path}")

        try:
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.username, self.password)
                server.send_message(msg)
        except smtplib.SMTPException as e:
            raise ConnectionError(f"Erro ao enviar email: {e}")

    def get_emails(
        self, folder: str = "inbox", search_criteria: str = "ALL"
    ) -> List[email.message.Message]:
        """Recupera emails baseado em critérios de busca e mantém a conexão IMAP ativa."""
        if not self.imap_server:
            raise ValueError(
                "Configurações IMAP não fornecidas. Impossível ler emails."
            )

        try:
            # Se imap_port não foi fornecido, usa a porta padrão 993
            port = self.imap_port or 993
            # Conexão IMAP é mantida como atributo da classe
            self.mail = imaplib.IMAP4_SSL(self.imap_server, port)
            self.mail.login(self.username, self.password)
            self.mail.select(folder)
            result, data = self.mail.search(None, search_criteria)
            if result != "OK":
                raise ValueError("Nenhum email encontrado!")

            email_ids = data[0].split()
            emails = []
            for e_id in email_ids:
                result, msg_data = self.mail.fetch(e_id, "(RFC822)")
                if result != "OK":
                    continue
                raw_email = msg_data[0][1]
                emails.append(email.message_from_bytes(raw_email))
            return emails
        except imaplib.IMAP4.error as e:
            raise ConnectionError(f"Erro ao recuperar emails: {e}")

    def close_mail_connection(self):
        """Fecha a conexão IMAP de forma segura."""
        if hasattr(self, "mail") and self.mail:
            try:
                self.mail.close()
                self.mail.logout()
                self.mail = None
                return True
            except Exception:
                return False
        return False

    '''
    def read_email(self, email_message: email.message.Message) -> Dict[str, str]:
        """Extract the plain text, HTML content, and headers from an email."""
        content = {"subject": "", "plain_text": "", "html": ""}
        if "subject" in email_message:
            decoded_header = decode_header(email_message["subject"])[0]
            content["subject"] = (
                decoded_header[0].decode(decoded_header[1])
                if isinstance(decoded_header[0], bytes)
                else decoded_header[0]
            )

        if email_message.is_multipart():
            for part in email_message.walk():
                content_type = part.get_content_type()
                if content_type == "text/plain":
                    content["plain_text"] = part.get_payload(decode=True).decode()
                elif content_type == "text/html":
                    content["html"] = part.get_payload(decode=True).decode()
        else:
            content["plain_text"] = email_message.get_payload(decode=True).decode()

        return content
    '''

    def read_email(self, email_message: email.message.Message) -> Dict[str, str]:
        """Extract the plain text, HTML content, and headers from an email."""
        content = {"subject": "", "plain_text": "", "html": ""}
        if "subject" in email_message:
            decoded_header = decode_header(email_message["subject"])[0]
            content["subject"] = (
                decoded_header[0].decode(decoded_header[1])
                if isinstance(decoded_header[0], bytes) and decoded_header[1]
                else (
                    decoded_header[0].decode("utf-8", errors="replace")
                    if isinstance(decoded_header[0], bytes)
                    else decoded_header[0]
                )
            )

        if email_message.is_multipart():
            for part in email_message.walk():
                content_type = part.get_content_type()
                if content_type == "text/plain":
                    try:
                        payload = part.get_payload(decode=True)
                        charset = part.get_content_charset() or "utf-8"
                        content["plain_text"] = payload.decode(
                            charset, errors="replace"
                        )
                    except Exception as e:
                        # Tenta decodificar com diferentes codificações comuns
                        for encoding in ["utf-8", "latin1", "iso-8859-1", "cp1252"]:
                            try:
                                content["plain_text"] = payload.decode(
                                    encoding, errors="replace"
                                )
                                break
                            except:
                                continue
                        if not content["plain_text"]:
                            content["plain_text"] = (
                                f"[Erro ao decodificar o conteúdo: {str(e)}]"
                            )
                elif content_type == "text/html":
                    try:
                        payload = part.get_payload(decode=True)
                        charset = part.get_content_charset() or "utf-8"
                        content["html"] = payload.decode(charset, errors="replace")
                    except Exception as e:
                        # Tenta decodificar com diferentes codificações comuns
                        for encoding in ["utf-8", "latin1", "iso-8859-1", "cp1252"]:
                            try:
                                content["html"] = payload.decode(
                                    encoding, errors="replace"
                                )
                                break
                            except:
                                continue
                        if not content["html"]:
                            content["html"] = (
                                f"[Erro ao decodificar o conteúdo HTML: {str(e)}]"
                            )
        else:
            try:
                payload = email_message.get_payload(decode=True)
                charset = email_message.get_content_charset() or "utf-8"
                content["plain_text"] = payload.decode(charset, errors="replace")
            except Exception as e:
                # Tenta decodificar com diferentes codificações comuns
                for encoding in ["utf-8", "latin1", "iso-8859-1", "cp1252"]:
                    try:
                        content["plain_text"] = payload.decode(
                            encoding, errors="replace"
                        )
                        break
                    except:
                        continue
                if not content["plain_text"]:
                    content["plain_text"] = (
                        f"[Erro ao decodificar o conteúdo: {str(e)}]"
                    )

        return content

    def save_attachments(
        self, email_message: email.message.Message, save_dir: str = "attachments"
    ) -> List[str]:
        """Save all attachments from an email to a specified directory."""
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)

        saved_files = []
        for part in email_message.walk():
            if part.get_content_disposition() == "attachment":
                filename = part.get_filename()
                if filename:
                    unique_filename = f"{uuid.uuid4()}_{filename}"
                    file_path = os.path.join(save_dir, unique_filename)
                    with open(file_path, "wb") as file:
                        file.write(part.get_payload(decode=True))
                    saved_files.append(file_path)

        return saved_files

    def delete_email(self, email_id: str, folder: str = "inbox"):
        """Mark an email for deletion."""
        try:
            with imaplib.IMAP4_SSL(self.imap_server) as mail:
                mail.login(self.username, self.password)
                mail.select(folder)
                mail.store(email_id, "+FLAGS", "\\Deleted")
                mail.expunge()
        except imaplib.IMAP4.error as e:
            raise ConnectionError(f"Error deleting email: {e}")

    def move_email(
        self, email_id: str, destination_folder: str, source_folder: str = "inbox"
    ):
        """Move an email to a different folder."""
        try:
            with imaplib.IMAP4_SSL(self.imap_server) as mail:
                mail.login(self.username, self.password)
                mail.select(source_folder)
                mail.copy(email_id, destination_folder)
                mail.store(email_id, "+FLAGS", "\\Deleted")
                mail.expunge()
        except imaplib.IMAP4.error as e:
            raise ConnectionError(f"Error moving email: {e}")


# Example usage
"""
    email_handler = EmailHandler(
    smtp_server=smtp_server,
    smtp_port=smtp_porta,
    imap_server=imap_server,
    username=user_name,
    password=password,
)
email_handler.send_email(
    "eriston.santos@kblcontabilidade.com.br",
    "Subject: Teste",
    "Body text",
    body_html="<b>HTML Body</b>",
)

emails = email_handler.get_emails()
for email_msg in emails:
    print(email_handler.read_email(email_msg))
"""
