# Código do process_bot.py atualizado
import os
from botcity.web import WebBot, Browser, By
from botcity.web.util import element_as_select
from webdriver_manager.chrome import ChromeDriverManager
from botcity.web.browsers.chrome import default_options
from config import (
    Orchestrator,
    Constantes,
    Utils,
    Desencriptador,
    log_status,
    logging,
    FileHandler,
    ensure_valid_token,
    EmailManager,
)
from datetime import datetime

bot = WebBot()


####Classe padrão para o início do bot
class Initiate_Browsers:

    @staticmethod
    def open_browser():
        try:
            bot.driver_path = (
                ChromeDriverManager()
                .install()
                .replace(f"/THIRD_PARTY_NOTICES.chromedriver", r"\chromedriver.exe")
            )
            # Configure whether or not to run on headless mode
            bot.headless = False
 
            # Caminho do perfil
            profile_path = os.path.join(
                "C:\\",
                "Users",
                f"{os.getlogin()}.KBL",  #### AO IR PARA PRODUÇÃO PRECISA ALTERAR, TIRAR O .KBL
                "AppData",
                "Local",
                "Google",
                "Chrome",
                "User Data",
            )
            bot.execute_javascript("document.querySelector('#ctl00_body_btAcesso').click();")
            bot.execute_javascript("document.querySelector('#ctl00_body_btVoltar').click();")
            # Caminho para a extensão já instalada
            # Observe que podemos usar um padrão para garantir que funcione mesmo se a versão mudar
 
            # Fetch the default options for my preferred browser
            def_options = default_options(
                headless=bot.headless,
                user_data_dir=profile_path,  # Inform the profile path that wants to start the browser
            )
 
            def_options.add_argument("--password-store=basic")
            def_options.add_argument("--use-mock-keychain")
            def_options.add_argument("--disable-sync")
 
            # Desativar recursos de segurança que podem causar problemas
            def_options.add_argument("--disable-encryption")
            def_options.add_argument("--disable-features=EncryptionMigration")
            bot.options = def_options
 
            # Opens the browser on the BotCity website with an existing profile
            # bot.start_browser()
            
            bot.browse("https://nfe.prefeitura.sp.gov.br/login.aspx")
            bot.maximize_window()
            status_process = "Navegador aberto com sucesso."
            return status_process, bot
        except Exception as e:
            raise f"Erro ao abrir o navegador: {str(e)}"

    @staticmethod
    def fazer_login_inputs(name):
        # Como melhorar a situação da REST referente a guarda de credenciais?
        #################
        print("fazer login")
        print("Obtendo credenciais encriptadas")
        credenciais_encriptadas = Orchestrator.get_asset_by_name(name)

        # Verifique se as credenciais_encriptadas estão corretas
        print("Credenciais encriptadas obtidas:", credenciais_encriptadas)

        # Instancia o Desencriptador
        desencriptador = Desencriptador()

        try:
            # Obtem as credenciais desencriptadas, passando o dicionário correto
            credenciais = desencriptador.obter_credenciais(credenciais_encriptadas)

            # Usa as credenciais desencriptadas para login
            user_login = credenciais["username"]
            pswd_login = credenciais["password"]

            print(f"Fazendo login com o usuário: {user_login}")

        except Exception as e:
            print("Erro ao desencriptar credenciais:", e)

        max_attempts = 3
        attempts = 0
        status_portal = "Fução Login iniciado."
        tipo_log = "info"
        local = "Executando"
        # Orchestrator.logger.gravar_status(Constantes.NOME_AUTOMACAO,mensagem= status_portal, local=local,nivel= tipo_log)

        #################

        while attempts < max_attempts:
            try:
                status_portal = ""
                input_usuario = ""
                input_senha = "#"
                botao_entrar = ""
                seletores_js = [
                    input_usuario,
                    input_senha,
                    botao_entrar,
                ]  # alterar para os Ids dos campos
                querys_execute = [
                    Constantes.QUERY_JS_TYPE,
                    Constantes.QUERY_JS_TYPE,
                    Constantes.QUERY_JS_CLICK,
                ]

                ###Logins com inputs de usuario e senha padrão
                replaces_valor = [user_login, pswd_login, ""]
                for index, valor in enumerate(seletores_js):
                    seletor_js = valor
                    replace_valor = replaces_valor[index]
                    query_execute = querys_execute[index]
                    query_execute = query_execute.replace(
                        "seletor_js_path", seletor_js
                    ).replace("valor_esperado", replace_valor)
                    bot.execute_javascript(query_execute)
                    print(
                        f"Infomrando os valores: Index: {index}, valor: {replace_valor}"
                    )

                elemento = None
                while elemento == None:

                    id_do_elemento = ""
                    elemento = bot.find_element(
                        id_do_elemento,
                        By.ID,
                        ensure_visible=True,
                        ensure_clickable=True,
                    )  # substituir para o id do elemento desejado

                status_portal = "Login realizado com sucesso!"

            except Exception as e:
                status_portal = f"{e}"
                tipo_log = "error"
                attempts += 1
                status_portal = f"Tentativa {attempts}: {e}"
                if attempts == max_attempts:
                    status_portal = f"Falha ao preencher formulário. Número máximo de {max_attempts} tentativas excedido."
                    raise Exception()

            finally:
                print(status_portal)
                # Orchestrator.logger.gravar_status(Constantes.NOME_AUTOMACAO,mensagem= status_portal, local = local, nivel= tipo_log)
                return status_portal

    @staticmethod
    def close_browser():
        bot.stop_browser()  # Finaliza e limpa o navegadorEX
        # gravar_status(Constantes.NOME_AUTOMACAO,mensagem= status_portal, local = local, nivel= tipo_log)


#####outras classes personalizadas abaixo:
class Rest_Sao_Paulo:
    @staticmethod
    def acessar_rest_sao_paulo(credencial):
        try:

            name = Constantes.ASSET_URL_PORTAL_PREFEITURA
            try:
                url_asset = Orchestrator.get_asset_by_name(name)
                url_portal = url_asset["value_text"]
                print(url_portal)

            except Exception as e:
                status_local = (
                    f"REST Prefeitura de São Paulo não iniciado. Motivo: {str(e)}"
                )
                return status_local

            bot.navigate_to(url_portal)
            name = credencial
            status_local = Initiate_Browsers.fazer_login_inputs(name)
            print(status_local[0])

            status_local = "Portal Prefeitura de São Paulo iniciado com sucesso."

        except Exception as e:
            status_local = f"Erro ao iniciar o portal da REST da Prefeitura de Goiânia. Motivo: {str(e)}"

        finally:
            return status_local

    @staticmethod
    def verificar_elemento(elemento):
        try:
            existe = bot.wait_for_stale_element(
                bot.find_element(elemento, By.XPATH, ensure_clickable=True)
            )
        except Exception as e:
            existe = False
            pass
        if not existe:
            status = "Elemento não existe."
            return status
        status = "Elemento encontado."
        return status

    @staticmethod
    def alterar_perfil_usuario(perfil):
        try:

            satus_local = f"Selecionando o perfil {perfil}."
            bot.execute_javascript("")
            elemento = bot.find_element("", By.ID)
            elemento.click()

            bot.paste(perfil)
            bot.enter()

        except Exception as e:
            satus_local = str(e)

        finally:
            print(satus_local)
            return satus_local

    @staticmethod
    def selecionar_rest():
        local = "Selecionando portal REST"
        level_log = logging.INFO

        try:
            tentativas = 0
            max_tentativas = 5

            while tentativas < max_tentativas:
                try:
                    try:
                        bot.execute_javascript("")
                        bot.find_element(
                            "",
                            By.CSS_SELECTOR,
                            ensure_visible=True,
                        )
                        bot.execute_javascript("")
                    except Exception as e:
                        pass

                    portal_tabs = []

                    while len(portal_tabs) <= 1:
                        portal_tabs = bot.get_tabs()

                        if len(portal_tabs) == 1:

                            bot.execute_javascript("")
                            status_portal = "Portal da Rest Selecionado"

                        else:
                            new_tab = portal_tabs[1]
                            # Activating the tab as the current context.
                            print(f"Tab {new_tab} localizada")
                            break

                    bot.activate_tab(new_tab)
                    if not bot.page_title() == "":
                        bot.close_page()
                        raise
                    else:
                        break
                except Exception as e:
                    tentativas += 1
                    status_portal = f"Erro na tentativa {tentativas}: {str(e)}"

                    if tentativas < max_tentativas:

                        status_portal = (
                            f"Tentando novamente... ({tentativas}/{max_tentativas})"
                        )
                        bot.sleep(3)  # Aguarda 3 segundos antes de tentar novamente
                    else:
                        status_portal = f"Falha após {max_tentativas} tentativas. Último erro: {str(e)}"
                        raise Exception(status_portal)

            tentativas = 0
            max_tentativas = 3

        except Exception as e:
            status_portal = f"{e}"

        finally:

            return status_portal

    @staticmethod
    @ensure_valid_token(interval_seconds=1800)
    def preencher_form_rest_sp(arquivo_rest, check_token=None):

        status_portal = ""
        try:
            pass
        except Exception as e:
            raise

        finally:
            return status_portal
