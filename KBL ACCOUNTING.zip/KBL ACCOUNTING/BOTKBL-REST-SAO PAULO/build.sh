#!/bin/bash

zip -r "BOTKBL-REST-TESTE.zip" * -x "BOTKBL-REST-TESTE.zip"