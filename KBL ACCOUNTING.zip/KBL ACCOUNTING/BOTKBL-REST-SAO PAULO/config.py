# C:\Desenvolvimento\KBL-RPA\PYTHON\KBL ACCOUNTING\BOTKBL-REST-GOIANIA\config.py
import os
import sys
import signal
import time
from datetime import datetime, timedelta
from pathlib import Path
from functools import wraps
from typing import Optional, Callable


# Adiciona o diretório bot_core ao sys.path para permitir importações de módulos dentro dele
sys_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.append(sys_path)
print(sys.path)

from bot_core.utils import Utils, Desencriptador, FileHandler
from bot_core.orchestrator import (
    get_jwt_token,
    get_asset_by_name,
    refresh_jwt_token,
    get_valid_access_token,
    add_queue_items_bulk,
    update_queue_item_status,
    get_queue_item,
    get_queue_items,
    add_queue_item,
)
from bot_core.config_loader import ConfigLoader
from bot_core.log_manager import Logger, logging
from bot_core.mail import EmailHandler


config_loader = ConfigLoader()
logger = Logger.for_robot(config_loader)


class Constantes:
    """
    Classe que armazena constantes utilizadas em todo o projeto.
    """

    # Armazena a hora de início da execução
    HORA_INICIO = datetime.now()

    # Nome da automação em execução
    NOME_AUTOMACAO = "BOTKBL-REST-SAO PAULO"
    # Uncomment and properly define this constant
    ASSET_URL_PORTAL_PREFEITURA = "REST-SAO PAULO-URL"
    # Caminho do log geral, com a data da execução
    LOG_GERAL = Path(
        rf"C:\Automacao\Log_Execucao_{HORA_INICIO.strftime('%d_%m_%Y')}.txt"
    )

    # Caminho absoluto do projeto
    PATH_PROJETO = os.path.abspath(os.path.join(os.path.dirname(__file__)))

    # Caminho para o diretório de arquivos de entrada
    PATH_ARQUIVO_ENTR = Path(rf"{PATH_PROJETO}\arquivos\entrada")

    # Caminho para o diretório de arquivos de saída
    PATH_ARQUIVO_SAIDA = Path(rf"{PATH_PROJETO}\arquivos\saida")

    PATH_REDE = r"\\srv-fs01\AUTOMACAO\GOIANIA\REST SAO PAULO"

    # URLs de configuração para o navegador
    URL_CONFIG = "chrome://settings/content/automaticDownloads"
    URL_CONFIG2 = "chrome://settings/content/insecureContent"
    URL_CONFIG3 = "só usar quando for necessário mais ajustes no navegador para fins de desbloqueio de funções"
    # Uncomment and properly define this constant
    ASSET_URL_PORTAL_PREFEITURA = "REST-SAO PAULO-URL"
    # Consultas JavaScript para interações com a página
    QUERY_JS_CLICK = 'document.querySelector("seletor_js_path").click()'
    QUERY_JS_TYPE = 'document.querySelector("seletor_js_path").value = "valor_esperado"'

    # Define o dia base para cálculos que necessitam de um dia específico
    DIA_BASE = 20  # Pode ser substituído para buscar de assets

    #ASSET_URL_PORTAL_PREFEITURA = "REST-SAO PAULO-URL"

    ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY")

    ENVIRONMENT = "DEV"  # DEV ou "HML" ou "PRD" dependendo do ambiente
    
    
    @classmethod
    def get_path_raiz(cls):
        return Path(f"C:/Automacao/{cls.UNIDADE_PADRAO}/{cls.NOME_AUTOMACAO}")

    @classmethod
    def get_log_geral(cls):
        return cls.LOG_GERAL

    @classmethod
    def get_encryption_key(cls):
        return cls.ENCRYPTION_KEY


class Orchestrator:
    """
    Classe responsável por interações com o Orquestrador.
    """

    # Inicializa tokens e define expiração inicial
    access_token, refresh_token, token_expiration_time = get_jwt_token(logger)
    expiration_buffer = timedelta(minutes=10)
    token_expiration_time = time.time() + 3600

    @classmethod
    def ensure_valid_token_during_process(cls):
        """Garante que o token está válido durante o processo."""
        try:
            cls.get_valid_access_token()
        except Exception as e:
            error_msg = f"Erro ao renovar token: {str(e)}"
            logger.log(error_msg, level="ERROR")
            raise

    @classmethod
    def get_valid_access_token(cls):
        """Retorna um token válido, renovando se necessário."""
        if time.time() >= (
            cls.token_expiration_time - cls.expiration_buffer.total_seconds()
        ):
            cls.access_token, cls.refresh_token, cls.token_expiration_time = (
                get_valid_access_token(
                    cls.access_token,
                    cls.refresh_token,
                    cls.token_expiration_time,
                    logger,
                )
            )
        return cls.access_token

    @classmethod
    def get_asset_by_name(cls, asset_name):
        print(f"Buscando asset: {asset_name}")
        cls.get_valid_access_token()  # Verifica e renova o token antes de buscar o asset
        return get_asset_by_name(
            asset_name=asset_name,
            access_token=cls.access_token,
            refresh_token=cls.refresh_token,
            logger=logger,
        )

    @classmethod
    def get_queue_items(cls, queue_id, status):
        cls.get_valid_access_token()
        queue_items = get_queue_items(
            queue_id=queue_id,
            access_token=cls.access_token,
            refresh_token=cls.refresh_token,
            logger=logger,
            status=status,
        )
        return queue_items

    @classmethod
    def get_queue_item(cls, item_id, status):
        cls.get_valid_access_token()
        return get_queue_items(
            queue_item_id=item_id,
            access_token=cls.access_token,
            refresh_token=cls.refresh_token,
            logger=logger,
            status=status,
        )

    @classmethod
    def update_queue_item_status(cls, queue_id, item_id, status):
        cls.get_valid_access_token()
        return update_queue_item_status(
            queue_id=queue_id,
            queue_item_id=item_id,
            new_status=status,
            access_token=cls.access_token,
            refresh_token=cls.refresh_token,
            logger=logger,
        )

    @classmethod
    def add_queue_item(cls, queue_id, item):
        cls.get_valid_access_token()
        return add_queue_item(
            queue_id=queue_id,
            data=item,
            access_token=cls.access_token,
            refresh_token=cls.refresh_token,
            logger=logger,
        )


class RoboDesencriptador:
    def obter_credenciais(self, asset):
        desencriptador = Desencriptador()
        return desencriptador.obter_credenciais(asset)


class Signals:
    @staticmethod
    def signal_handler(signum, frame):
        from uteis.browsers_bot import manipulate_browsers

        # Função para lidar com sinais SIGTERM e SIGINT
        status_message = "Sinal recebido, finalizando o robô de forma controlada."
        print(status_message)
        try:
            if "bot" in locals():
                status_message = manipulate_browsers.close_browser(
                    Orchestrator.access_token
                )
                status_message = f"Status do processamento: {status_message}"
            status_message += f" | Finalizando automação {Constantes.NOME_AUTOMACAO}."
            log_status(
                Constantes.NOME_AUTOMACAO,
                "terminated",
                status_message,
                "final",
                nivel="warning",
            )
        except Exception as e:
            print(f"Erro ao finalizar o robô após sinal: {str(e)}")
        sys.exit(0)

    @staticmethod
    def setup_signal_handlers():
        """Função para registrar os sinais SIGTERM e SIGINT"""
        signal.signal(signal.SIGTERM, Signals.signal_handler)
        signal.signal(signal.SIGINT, Signals.signal_handler)


def ensure_valid_token(
    interval_seconds: int = 1800,
    log_checks: bool = True,
    retry_on_failure: bool = True,
    max_retries: int = 3,
) -> Callable:
    """
    Decorator que garante que o token permanece válido durante a execução de funções longas.

    Args:
        interval_seconds: Intervalo em segundos para verificar o token
        log_checks: Se True, loga informações sobre as verificações do token
        retry_on_failure: Se True, tenta novamente em caso de falha na renovação do token
        max_retries: Número máximo de tentativas em caso de falha
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> any:
            last_check = time.time()
            retry_count = 0

            def check_token() -> None:
                nonlocal last_check, retry_count
                current_time = time.time()

                if current_time - last_check >= interval_seconds:
                    if log_checks:
                        logger.log(
                            f"Verificando token em {func.__name__}. "
                            f"Tempo desde última verificação: {current_time - last_check:.2f}s",
                            level=logging.INFO,
                        )

                    try:
                        Orchestrator.ensure_valid_token_during_process()
                        last_check = current_time
                        retry_count = 0

                        if log_checks:
                            logger.log(
                                f"Token verificado/renovado com sucesso em {func.__name__}",
                                level=logging.INFO,
                            )

                    except Exception as e:
                        retry_count += 1
                        error_msg = (
                            f"Erro ao renovar token em {func.__name__}: {str(e)}"
                        )

                        if retry_on_failure and retry_count <= max_retries:
                            logger.log(
                                f"{error_msg} Tentativa {retry_count} de {max_retries}",
                                level=logging.WARNING,
                            )
                            if retry_count < max_retries:
                                time.sleep(2**retry_count)  # Exponential backoff
                                check_token()
                        else:
                            logger.log(error_msg, level=logging.ERROR)
                            raise

            # Primeira verificação antes de começar
            check_token()

            try:
                # Executa a função com o verificador de token
                result = func(*args, check_token=check_token, **kwargs)
                return result

            finally:
                # Verificação final para garantir token válido
                try:
                    if log_checks:
                        logger.log(
                            f"Verificação final do token em {func.__name__}",
                            level=logging.INFO,
                        )
                    Orchestrator.ensure_valid_token_during_process()
                except Exception as e:
                    logger.log(
                        f"Erro na verificação final do token em {func.__name__}: {str(e)}",
                        level=logging.ERROR,
                    )

        return wrapper

    return decorator


def log_status(bot_name, status_exec, status_message, local, level, access_token):
    logger.gravar_status(
        bot_name,
        status_exec,
        status_message,
        local,
        nivel=level,
        access_token=access_token,
        environment=Constantes.ENVIRONMENT,
    )


class EmailManager:
    """
    Classe responsável por gerenciar operações de e-mail no sistema.
    """

    def __init__(self, only_smtp=True):
        """
        Inicializa o EmailManager.

        Args:
            only_smtp: Se True, configura apenas SMTP. Se False, configura SMTP e IMAP.
        """

        self.logger = logger

        try:
            # Obtendo configurações SMTP
            email_config_smtp = Orchestrator.get_asset_by_name(
                "CONFIGURACAO_EMAIL_SMTP_HOSTINGER"
            )
            server_smtp = (
                email_config_smtp["value_text"].split(",")[0].split(":")[1].strip()
            )
            porta_smtp = int(
                email_config_smtp["value_text"].split(",")[1].split(":")[1]
            )

            # Obtendo credenciais
            credenciais_encript = Orchestrator.get_asset_by_name("USUARIO_EMAIL_RPA_01")
            desencriptador = Desencriptador()
            credenciais = desencriptador.obter_credenciais(credenciais_encript)

            # Configurações IMAP (opcional)
            server_imap = None
            porta_imap = None

            if not only_smtp:
                email_config_imap = Orchestrator.get_asset_by_name(
                    "CONFIGURACAO_EMAIL_IMAP_HOSTINGER"
                )
                server_imap = (
                    email_config_imap["value_text"].split(",")[0].split(":")[1].strip()
                )
                porta_imap = int(
                    email_config_imap["value_text"].split(",")[1].split(":")[1]
                )

            # Log das configurações (sem senha)
            config_log = f"Configurando email com SMTP: {server_smtp}:{porta_smtp}"
            if not only_smtp:
                config_log += f", IMAP: {server_imap}:{porta_imap}"
            config_log += f", Usuario: {credenciais['username']}"
            self.logger.log(config_log, level="INFO")

            # Inicializando EmailHandler com os parâmetros necessários
            self.email_handler = EmailHandler(
                username=credenciais["username"],
                password=credenciais["password"],
                smtp_server=server_smtp,
                smtp_port=porta_smtp,
                imap_server=server_imap,
                imap_port=porta_imap,
            )

        except Exception as e:
            error_msg = f"Erro ao configurar EmailManager: {str(e)}"
            self.logger.log(error_msg, level="ERROR")
            raise

    def enviar_email(
        self,
        destinatario: str,
        assunto: str,
        corpo: str,
        corpo_html: str = None,
        anexos: list = None,
    ):
        """
        Envia um e-mail usando as configurações definidas.
        """
        try:
            self.logger.log(
                f"Iniciando envio de e-mail para {destinatario}", level="INFO"
            )

            self.email_handler.send_email(
                to_email=destinatario,
                subject=assunto,
                body=corpo,
                body_html=corpo_html,
                attachments=anexos,
            )

            self.logger.log(
                f"E-mail enviado com sucesso para {destinatario}", level="INFO"
            )

        except Exception as e:
            error_msg = f"Erro ao enviar e-mail: {str(e)}"
            self.logger.log(error_msg, level="ERROR")
            raise

    def ler_emails(self, pasta: str = "inbox", criterios: str = "ALL"):
        """
        Lê e-mails de uma pasta específica.

        Args:
            pasta: Nome da pasta a ser lida
            criterios: Critérios de busca
        """
        if not self.email_handler.imap_server:
            raise ValueError("EmailManager não foi configurado com suporte a IMAP")

        try:
            emails = self.email_handler.get_emails(
                folder=pasta, search_criteria=criterios
            )
            for email_msg in emails:
                conteudo = self.email_handler.read_email(email_msg)
                self.logger.log(f"E-mail lido: {conteudo['subject']}", level="INFO")
            return emails

        except Exception as e:
            error_msg = f"Erro ao ler e-mails: {str(e)}"
            self.logger.log(error_msg, level="ERROR")
            raise

    def salvar_anexos(self, email_msg, diretorio: str = None):
        """
        Salva anexos de um e-mail em um diretório específico.
        """
        if not self.email_handler.imap_server:
            raise ValueError("EmailManager não foi configurado com suporte a IMAP")

        if diretorio is None:
            diretorio = str(Constantes.PATH_ARQUIVO_SAIDA / "anexos")

        try:
            arquivos_salvos = self.email_handler.save_attachments(
                email_message=email_msg, save_dir=diretorio
            )
            return arquivos_salvos

        except Exception as e:
            error_msg = f"Erro ao salvar anexos: {str(e)}"
            self.logger.log(error_msg, level="ERROR")
            raise
