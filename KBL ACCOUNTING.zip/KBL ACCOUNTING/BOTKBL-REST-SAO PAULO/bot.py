# KBL ACCOUNTING\KBLBOT-REST-SAO PAULO\bot.py
#################################################ATENÇÃO#####################################################################
"""
Esta automação tem por objetivo realizar o lançamento das notas fiscais de serviço no portal da REST de São Paulo.
PASSOS DO DESENVOLVIMENTO:

1. ACESSAR O PORTAL DA REST DA PREFEITURA DE SAO PAULO
2. ACESSAR A EXTENSÃO DO WHOM (DOC_9) - VER VIDEO
3. INFORMAR O EMAIL automacao@kblcontabilidade1.com.br
4. LER A CAIXA DE EMAIL automacao@kblcontabilidade1.com.br
5. OBTER O ULTIMO EMAIL DO WHOM
6. OBTER A SENHA PROVISORIA DO EMAIL
7. INFORMAR A SENHA PROVISORIA NO WHOM
8. ESCOLHER O CERTIFICADO
9. AUTORIZAR O CERTIFICADO
10. FAZER LOGIN NO PORTAL DA PREFEITURA
11. ACESSAR A PAGINA DA REST
12. OBTER LISTA DE NOTAS DO ARQUIVO EXCEL/TXT
13. PERCORRER A LISTA DE NOTAS
14. INFORMAR OS VALORES NOS RESPECTIVOS CAMPOS DE NOTAS
15. ENCERRAR O NAVEGADOR
16. NOTIFICAR STATUS DA EXECUÇÃO
17. ENCERRAR AUTOMAÇÃO
                                                                                                                  
VERSÃO ATUAL: 2.0.0                                                                                               
IDEALIZADO POR: JACQUELINE GODINHO - IPOG                                                                
DATA DA VERSÃO: 26/02/2025
PUBLICAÇÃO:                                                                                    
"""
#############################################################################################################################

from email import utils
import logging
from urllib.request import FileHandler
from config import *
from uteis.browsers_bot import Initiate_Browsers, Rest_Sao_Paulo

from pathlib import Path
import shutil


@ensure_valid_token(interval_seconds=1800)
def main(email_manager, check_token=None):
    bot = None

    Signals.setup_signal_handlers()
    FileHandler.alterar_build(Constantes.PATH_PROJETO, Constantes.NOME_AUTOMACAO)
    start_time = Constantes.HORA_INICIO
    start_time_str = start_time.strftime("%d/%b/%Y %H:%M:%S.%f")[:-3]

    bot_name = Constantes.NOME_AUTOMACAO

    status_exec = "in_progress"
    status_message = f"Iniciando automação {bot_name} em {start_time_str}. Fase: {Constantes.ENVIRONMENT}"
    print(status_message)

    local = "Início"
    level_log = logging.INFO
    path_rede = Constantes.PATH_REDE
    path_entrada = Constantes.PATH_ARQUIVO_ENTR
    path_saida = Constantes.PATH_ARQUIVO_SAIDA

    try:
        """"""
        log_status(
            bot_name,
            status_exec,
            status_message,
            local,
            level=level_log,
            access_token=Orchestrator.access_token,
        )
        
        # Bloco de inicialização dos robôs
        try:

            status_message, bot = Initiate_Browsers.open_browser()
            status_message = f"Status do processamento: {status_message}"
            
            
        except Exception as e:
            status_message = (
                f"Erro na configuração do bot: Erro ao iniciar o bot: {str(e)}"
            )

        finally:
            """
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )
            """

        # Bloco de processamento do robô
        try:
            status_message = "Iniciando processamento"
            # Implementar aqui a lógica do bot
            """
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )
            """
            # Exemplo: bot.click_button(By.ID, "example-id")
            """
            queue_items = Orchestrator.get_queue_items(queue_id=1, status="new")
            
            for item in queue_items:
                if check_token:
                    check_token()
                update_queue_item_status(
                    queue_id=queue_id,
                    queue_item_id=item["id"],
                    new_status="in_progress",
                )
                credencial = item["data"]["data"]["Usuario"]
                cae = item["data"]["data"]["CAE"].split("CAE")[1]
                arquivo_rest = item["data"]["data"]["Arquivo"]
                status_message = rest_goiania.acessar_rest_goiania(
                    credencial=credencial
                )

                log_status(
                    bot_name,
                    status_exec,
                    status_message,
                    local,
                    level=level_log,
                    access_token=Orchestrator.access_token,
                )

                status_message = rest_goiania.alterar_perfil_usuario(cae)
                elemento = '//*[@id="GoianiaTheme_wtTelaPrincipal_block_wtMainContent_WebPatterns_wt218_block_wtContent1_wt5_WebPatterns_wt381_block_wtContent_wtRed"]/div'

                status_message = rest_goiania.selecionar_rest()
                status_message = f"Status do processamento: {status_message}"
                log_status(
                    bot_name,
                    status_exec,
                    status_message,
                    local,
                    level=level_log,
                    access_token=Orchestrator.access_token,
                )

                status_message = rest_goiania.preencher_form_rest_gyn(arquivo_rest)

                log_status(
                    bot_name,
                    status_exec,
                    status_message,
                    local,
                    level=level_log,
                    access_token=Orchestrator.access_token,
                )
                if "sucesso" in status_message.lower:
                    status_queue = "completed"
                else:
                    status_queue = "failed"
                update_queue_item_status(
                    queue_id=queue_id, queue_item_id=item["id"], new_status=status_queue
                )

                asset = Orchestrator.get_asset_by_name(credencial)["description"]
                empresa = asset.split(":")[1].split(";")[0].strip()
                destinatario = asset.split(":")[2].strip()
                """

            if "conclúido com sucesso" in status_message:
                level_log = logging.INFO
            else:
                level_log = logging.WARNING

            status_exec = "success"

        except Exception as e:
            status_message = f"Erro durante o processamento: {str(e)}"
            level_log = logging.ERROR
            status_exec = "failure"

    except Exception as e:
        status_message = f"Erro ao obter token JWT: {str(e)}"
        level_log = logging.ERROR
        status_exec = "failure"

    finally:
        status_bot = status_message
        if check_token:
            check_token()
        """
        log_status(
            bot_name,
            status_exec,
            status_message,
            local,
            level=level_log,
            access_token=Orchestrator.access_token,
        )
        """
        # Bloco de finalização do robô
        try:
            if bot:  # Verifica se bot foi inicializado
                status_message = "Finalizando processamento dos dados."
                bot.wait(3000)  # Aguarda 3 segundos antes de fechar
                status_message = Initiate_Browsers.close_browser()
                status_message = f"Status do processamento: {status_message}"

            status_message = f"Finalizando automaçao {bot_name} em: "
            level_log = logging.INFO
            status_exec = "success"

        except Exception as e:
            status_message += f" | Erro ao finalizar o bot {bot_name}, erro identificado: {str(e)}. Em: "
            level_log = logging.ERROR
            status_exec = "failure"

        finally:
            if check_token:
                check_token()
            tempo_final = utils.tempo_decorrido(start_time)

            # Calcula o tempo total de execução
            status_message += f"{tempo_final[2]} | Tempo total de execução: {tempo_final[1]} ({tempo_final[0]:.2f} segundos). Fase: {Constantes.ENVIRONMENT}"
            local = "Finalização do robô."
            """
            log_status(
                bot_name,
                status_exec,
                status_message,
                local,
                level=level_log,
                access_token=Orchestrator.access_token,
            )
            """
            '''
            email_manager.enviar_email(
                destinatario="eriston.santos@kblcontabilidade.com.br",
                assunto=f"[{bot_name}] Finalização",
                corpo=f"""
                Automação finalizada.
                Data/Hora Início: {start_time_str}
                Data/Hora Fim: {tempo_final[2]}
                Tempo de Execução: {tempo_final[1]}
                Status da Execução: {status_exec}
                """,
                corpo_html=f"""
                <h2>Automação Finalizada</h2>
                <p><strong>Bot:</strong> {bot_name}</p>
                <p><strong>Data/Hora Início:</strong> {start_time_str}</p>
                <p><strong>Data/Hora Fim:</strong> {tempo_final[2]}</p>
                <p><strong>Tempo de Execução:</strong> {tempo_final[1]}</p>
                <p><strong>Status da Execução:</strong> {status_exec}</p>
                <p><strong>{status_bot}</strong></p>
                """,
            )
            '''
    return


@ensure_valid_token(interval_seconds=1800)
def not_found(label, check_token):
    if check_token:
        check_token()
    """
    log_status(
        bot_name=Constantes.NOME_AUTOMACAO,
        status_exec="faiule",
        status_message=f"Elemento não encontrado: {label}",
        local="in_progress",
        level=logging.ERROR,
        access_token=Orchestrator.access_token,
    )
    """


if __name__ == "__main__":
    try:
        email_manager = EmailManager(only_smtp=True)
        main(email_manager)

    except Exception as e:
        from datetime import datetime

        now = datetime.now().strftime("%d/%b/%Y %H:%M:%S")
        """
        log_status(
            bot_name=Constantes.NOME_AUTOMACAO,
            status_exec="failure",
            status_message=f"Erro na execução do bot: {str(e)} em {now}. Fase: {Constantes.ENVIRONMENT}.",
            local="Execução",
            level=logging.ERROR,
            access_token=Orchestrator.access_token,
        )
        """
        '''
        email_manager.enviar_email(
            destinatario="eriston.santos@kblcontabilidade.com.br",
            assunto=f"[{Constantes.NOME_AUTOMACAO}] Erro de Execução",
            corpo=f"""
            Erro na execução do bot.
            Data/Hora: {datetime.now().strftime("%d/%b/%Y %H:%M:%S")}
            Ambiente: {Constantes.ENVIRONMENT}
            """,
            corpo_html=f"""
            <h2>Erro na execução do bot</h2>
            <p><strong>Bot:</strong> {Constantes.NOME_AUTOMACAO}</p>
            <p><strong>Data/Hora:</strong> {datetime.now().strftime("%d/%b/%Y %H:%M:%S")}</p>
            <p><strong>Ambiente:</strong> {Constantes.ENVIRONMENT}</p>
            
            """,
        )
        '''

