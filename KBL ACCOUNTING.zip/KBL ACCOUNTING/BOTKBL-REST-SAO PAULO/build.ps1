$exclude = @("venv", "BOTKBL-REST-GOIANIA.zip")
$files = Get-ChildItem -Path . -Exclude $exclude
Compress-Archive -Path $files -DestinationPath "BOTKBL-REST-GOIANIA.zip" -Force